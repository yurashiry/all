# Neux OS — macOS edition (build configuration only — NOT built)

Requires a Mac (DMG creation and code signing cannot be done elsewhere). Electron 33 supports macOS 11+; `minimumSystemVersion` is set to 12.0.
1. `node scripts/build-web.mjs`
2. `cd macos && npm install && npm run dist` → `dist/Neux OS-0.1.0.dmg` (unsigned unless you configure an Apple Developer ID; Gatekeeper will warn).

Not implemented: NSOpenPanel bridge, Application Support SQLite adapter, Network Extension (VPN), Virtualization.framework adapter, Input Method Extension.
