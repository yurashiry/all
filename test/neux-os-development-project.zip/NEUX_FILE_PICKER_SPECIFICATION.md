# Universal file picker

**Status:** implemented

`pickFile({mode:'open'|'save'|'folder', filter, multiple, title, startPath, defaultName})` opens an Explorer window in picker mode and resolves to NeuxFS paths or `null`. Sidebar (Favorites, Recent, Desktop, Documents, Downloads, Music, Videos, Pictures, Projects, Applications, Trash), navigation, search, sorting, filter menu (All, Music, Video, Music & video, Images, Documents, Archives, Applications, .wr/.wrapp, User files, Code & text), Open disabled until the selection is compatible with the **requesting app's** filter, multi-select with Ctrl/Shift, double-click opens folders, Cancel resolves `null`, nothing is copied. Host files: a separate explicit "Import…" button copies chosen device files into NeuxFS (browser file dialog). Native dialogs (Windows, macOS NSOpenPanel, Android SAF) are not implemented.
