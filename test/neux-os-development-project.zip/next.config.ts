import type { NextConfig } from "next";

/** Normal build (platform preview / server): default Next output.
 *  Web release for GitHub Pages: `node scripts/build-web.mjs` sets NEUX_EXPORT=1 → fully static, relative asset paths. */
const exportMode = process.env.NEUX_EXPORT === "1";
const nextConfig: NextConfig = exportMode
  ? { output: "export", distDir: "web-release", assetPrefix: "./", trailingSlash: false, images: { unoptimized: true } }
  : {};

export default nextConfig;
