# File associations

**Status:** implemented

Defaults (editable in Settings → File Associations): audio/video → Media; png/jpg/webp/tiff/avif/gif/bmp → Gallery; pdf → PDF Viewer; txt/md/lrc/csv/json/css/js/nxl → Text Editor; html → Browser's file handler entry; `.wr` → Runtime; `.wrapp`/`.nxe` → Package Installer; `.wrphoto` → Photo; zip → Archive. `openFile()` runs the security check first; executables are never run; unknown types open "Open With" (compatible apps, safe text view, Secure Center inspection) and are not executed. Context menu in Explorer: Open, Open with, Open file location, Add to playlist (media), Properties, plus clipboard/rename/archive/trash/favorites/inspect. Opening a media file launches Media and plays it; the file stays where it is. Note: HTML files open in Text Editor by default instead of rendering inside Browser because the Browser cannot load NeuxFS blobs as pages; use Developer → Preview.
