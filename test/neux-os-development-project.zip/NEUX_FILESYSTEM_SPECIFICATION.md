# NeuxFS

**Status:** implemented

Virtual tree created at first boot: `/System/{Core,Shell,Services,Drivers,Recovery,Quarantine}`, `/Users/{Default/{Desktop,Documents,Downloads,Pictures{Neux Photo Projects,Exports},Music,Videos,Projects},Guest}`, `/Applications`, `/Store`, `/Themes`, `/Temporary`, `/Trash`, `/Configuration`.
Node: `{path,name,parent,type,mime,size,created,modified,data:Blob,meta}` keyed by path in IndexedDB database `neuxfs`.
Operations: mkdir (recursive), writeFile, read, list, stat, rename, copy, move, trash/restore/emptyTrash, remove, search, usage, wipe, JSON helpers; zip archive/unarchive (zip-slip guarded) and whole-FS backup/restore (`backup-format neux-backup/1`).
Access control: `/System` and `/Configuration` need role `root` (internal services pass it); everything else is `user`. Host files are never touched; host data enters only through explicit user-initiated imports (copy).
Limits: whole blobs are read into memory for most operations; very large media files are bound by browser memory/quota. Android SAF / Windows / macOS storage adapters: not implemented.
Tests: `src/tests/neuxfs.test.ts`.
