# Security architecture

**Status:** partial

Implemented: PBKDF2-SHA-256 (210 000 it.) salted password hashes; roles user/admin/root; protected paths enforced in `NeuxFS`; permission store per app; sandboxed package iframes (`sandbox="allow-scripts"`, CSP, no same-origin, postMessage bridge with per-call permission checks); Web Apps with `sandbox` lacking top-navigation; SHA-256 pinned Store packages; manifest validation (id/version/permissions/https URL/path traversal/size); event log (`security.json`), audit log for console; File Isolation + quarantine (see NEUX_SECURITY_CENTRE_SPECIFICATION.md); extension validation (theme variables only, no URLs); VPN subscription URLs encrypted with AES-GCM (non-extractable IndexedDB key).
Not implemented: public-key package signatures, process isolation, per-app network firewalling, malware detection, secure-update signature chain. Anyone with access to the unlocked browser profile can read IndexedDB — the lock screen is an access-control UI, not disk encryption.
