# Setup Assistant

**Status:** implemented

Steps: Welcome (+ local account) → BEECO Network (real reachability check; Wi-Fi listing explained as unavailable on Web; can continue offline) → Region (United States, Ukraine pinned, others A–Z; Ukrainian suggestions optional) → Primary language → Secondary language (16 languages offered) → Shortcuts & gestures → optional VPN note → Ready. Stored in `/Configuration/settings.json` (`setupDone`); not re-shown after updates; reopen via Settings → System → Setup Assistant. The shell UI is translated for English, Ukrainian, Russian, German, French, Spanish, Polish; other languages fall back to English. Downloadable language packs and keyboard layouts are not implemented.
