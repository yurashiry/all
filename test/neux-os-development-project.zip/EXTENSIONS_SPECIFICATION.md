# Extensions (.nxe)

**Status:** theme extensions only

`.nxe` = ZIP with `manifest.json` (`id,name,version,type:"theme",vars{}`), `extension.nxl` (required, currently not executed), optional `assets/ styles/ locales/`. Variables are limited to an allow-list (`--accent`, `--bg`, `--surface…`) and values cannot contain URLs/quotes/semicolons. Install from Settings → Extensions; toggle/remove; applied at boot.
Not implemented: Default/Third-party/Disabled replacement of Hotbar, launcher, Explorer, Browser, Media, notification center; third-party keyboards (Android IME, Windows input services, macOS IME need native shells); scripted NXL extensions.
