# Platforms

**Status:** Web implemented; native editions configured, NOT built

| Edition | State | Notes |
|---|---|---|
| Web/PWA | built (`web-release`) | needs a modern browser with IndexedDB, Web Crypto, `createImageBitmap`; service worker needs HTTPS |
| Android | config only (`android/`) | Capacitor; API 24 target; WebView age on Android 7 must be tested; native bridge not written |
| Windows | config only (`windows/`) | Electron 22.3.27 is the last line supporting Windows 8; unpatched Chromium; not validated |
| macOS | config only (`macos/`) | Electron 33, min macOS 12; needs a Mac to build/sign |
`src/adapters/web/platform.ts` detects the edition (`window.NeuxNative`) and lists capabilities truthfully. Native adapters (SAF, native dialogs, NSOpenPanel, SQLite, TUN/VpnService/Network Extension, hypervisors) are **not implemented**; the Diagnostics app shows them as unavailable.
