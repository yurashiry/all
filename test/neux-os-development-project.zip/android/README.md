# Neux OS — Android edition (build configuration only — NOT built)

Status: **configuration prepared, no APK was compiled** (no Android SDK/JDK in the authoring environment).

Approach: Capacitor (WebView shell) hosting the same Web release in `../web-release`, plus native plugins for the capabilities a WebView lacks.
- Capacitor 6/7 supports minSdk 23–24; Neux targets **API 24 (Android 7.0)**. Verify the WebView on API 24 devices: the system WebView is updatable, but a stock Android 7 image may ship an old Chromium — test `createImageBitmap`, `MediaCapabilities` and `crypto.subtle`.
- Native bridge to implement (not done): `window.NeuxNative = { edition: "android", capabilities: [...] }` exposing Storage Access Framework picker, `VpnService` (single active VPN rule applies), foreground media service, notifications, SQLite-backed NeuxFS adapter.

## Build (requires Android Studio / JDK 17 / Android SDK)
1. `node scripts/build-web.mjs`
2. `cd android && npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android`
3. `npx cap add android && npx cap sync android`
4. Set `minSdkVersion 24` in `android/variables.gradle`, then `npx cap open android` → Build → Build APK(s).
