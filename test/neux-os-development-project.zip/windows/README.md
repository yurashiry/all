# Neux OS — Windows edition (build configuration only — NOT built)

Electron **22.3.27** is the last Electron line that runs on Windows 7/8/8.1 (newer Electron requires Windows 10+). Chromium 108 is old and unpatched — acceptable only as a compatibility build; use a current Electron on Windows 10+.

1. `node scripts/build-web.mjs`
2. `cd windows && npm install && npm run dist` → `dist/Neux OS Setup 0.1.0.exe` (run on Windows or with Wine for NSIS).

Not implemented: native file dialogs, SQLite storage adapter, TUN VPN adapter, hypervisor adapter. Windows 8 compatibility has **not** been validated on a real machine.
