// Minimal bridge: announces the native edition. Native capabilities (TCP sockets, native file dialogs, SQLite storage)
// are NOT implemented yet — the list stays empty so the UI never claims them.
const { contextBridge } = require("electron");
contextBridge.exposeInMainWorld("NeuxNative", { edition: process.platform === "darwin" ? "macos" : "windows", capabilities: [] });
