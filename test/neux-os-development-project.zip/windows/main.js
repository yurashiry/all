// Neux OS — Electron main process (Windows/macOS shells share this file). Loads the static Web release in a sandboxed renderer.
const { app, BrowserWindow, session, shell } = require("electron");
const path = require("path");
function create() {
  const win = new BrowserWindow({ width: 1280, height: 800, backgroundColor: "#0b0e16", webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false, preload: path.join(__dirname, "preload.js") } });
  win.loadFile(path.join(__dirname, "web", "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:/.test(url)) shell.openExternal(url); return { action: "deny" }; });
}
app.whenReady().then(() => { session.defaultSession.setPermissionRequestHandler((_w, _p, cb) => cb(false)); create(); });
app.on("window-all-closed", () => app.quit());
