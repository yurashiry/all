# VPN Manager

**Status:** subscription management only

Implemented: import via URL (fetched client-side, CORS applies), file, QR image (BarcodeDetector where available); parser for vless/vmess/trojan/ss/hysteria2/tuic/wireguard share links (plain or base64); server list; refresh; remove; AES-GCM encrypted source URL. Not implemented / disabled in UI: connect, auto-connect, kill switch, split tunnelling, DNS, statistics, ping (a browser cannot TCP-probe), HAPP integration. Native plan: Android `VpnService`, Windows TUN adapter (e.g. WinTun), macOS Network Extension. BEECO and VPN are separate systems.
