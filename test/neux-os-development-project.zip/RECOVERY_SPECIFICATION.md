# Recovery

**Status:** implemented at application level

App `Recovery`: integrity check (folder tree, config JSON validity + SHA-256, app manifests/icons/entries, 1 KiB storage round trip), repair (recreate folders, remove damaged apps), backup (ZIP) / restore, reinstall program files (clear Neux caches + reload), factory reset (checkbox + typed ERASE + final dialog). Boot-failure emergency screen offers retry / repair / erase without the desktop. Update rollback and host recovery are **not** available on Web (redeploy the previous release).
