# Neux OS — HAORÏK Laboratory (v0.1.0-alpha)

Neux OS is a cross-platform desktop environment that runs **on top of** Web, Android, Windows and macOS. It is not a kernel and does not replace the host OS.

**Honest status: alpha.** The Web edition is implemented and builds. Android/Windows/macOS have *build configuration only* (nothing was compiled). See the lists below and `PLATFORM_SPECIFICATION.md`.

## What works today (Web edition)
Desktop shell (windows with drag/resize/snap, Hotbar, Start menu, notifications, quick settings, virtual desktops, widgets, lock screen, setup assistant) · NeuxFS on IndexedDB · Explorer + universal file picker + file associations · Browser with downloads · Store with 77 real `.wrapp` packages (SHA-256 verified install/uninstall/update) · sandboxed package runtime · Media (audio/video, mixed playlists, EQ, lyrics view) · Photo editor (`.wrphoto`) · Secure Center · Recovery · complete Neux-only reset · Console (real commands) · Developer (editor, preview, NXL) · NXL compiler + VM · BEECO/1 protocol stack · VPN subscription manager (no tunnelling on Web) · Settings with remappable shortcuts · 26 built-in apps.

## Project layout
`src/app` Next.js entry · `src/shell` desktop UI · `src/core` services (filesystem, security, networking, applications …) · `src/apps` built-in apps · `src/nxl` language · `src/protocols/beeco` protocol · `src/adapters` platform detection · `src/tests` unit tests · `public/store` generated catalog/packages · `scripts` build helpers · `docs` + root `*.md` specifications · `android/ windows/ macos/` native build configuration.
The canonical Web entry is the generated **`web-release/index.html`** (Next.js static export; there is no hand-written duplicate entry).

## Deploy to GitHub Pages — no command line required
1. The folder **`web-release`** contains the finished Web edition. (To regenerate it: `node scripts/build-web.mjs`.)
2. Create a repository on github.com → *Add file → Upload files* → drag **everything inside `web-release`** (including the `_next` folder and the hidden `.nojekyll` file if your OS shows it; if you cannot upload `.nojekyll`, create an empty file with that name via *Add file → Create new file*).
3. *Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / root → Save.*
4. Open `https://<user>.github.io/<repository>/`. All paths are relative, so repository sub-directories work.
5. Test: the boot screen should finish, the Setup Assistant should appear, and *Store → Install* should show a real progress ring. Install the PWA from the browser menu.
6. Update: upload the new `web-release` contents over the old ones (commit). Users get it via *Settings → Updates* or by reloading. Deployed files are the only update channel on the Web edition.
Note: data lives in each visitor's own browser (IndexedDB), never on GitHub. All project sites of one GitHub user share one origin, so Neux uses only its own named stores (`neuxfs`, `neux-keys`, `neux:*` keys, `neux-*` caches) and the reset deletes only those.

## Develop / test
`npm run dev` · `npx vitest run` (37 tests) · `npx tsc --noEmit` · `npm run build` · `node scripts/build-store.mjs` regenerates the Store catalog.

## Known limitations
See `PLATFORM_SPECIFICATION.md` and the "not implemented" lists in each specification. Highlights: no native shells built, no device VPN, no hypervisor, no raw TCP, no package-signature PKI, no ratings backend, no scripted extensions, partial translations (7 of 16 languages for the shell strings), UI not exercised in a real browser during authoring (only logic tests were run).
