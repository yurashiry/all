# Neux Web Apps

**Status:** implemented

Each Web App is a real `.wrapp` (manifest, icon, permissions, window config, official URL, version, category, compatibility) that is downloaded, hash-verified and installed. Execution: own window, `iframe` with `sandbox` (scripts, same-origin-to-the-site, forms, popups-to-escape, downloads, modals; **no top-navigation**), Permissions-Policy `allow` derived from granted permissions, per-app permission/site-settings panel, reload, and "Open in browser tab" fallback. Sites that send `X-Frame-Options`/CSP `frame-ancestors` refuse embedding — Neux cannot detect this reliably and does **not** bypass it; the toolbar explains. Embedded third-party cookies may be blocked by the browser, so login persistence is not guaranteed. Packages are labelled "Official Neux package"; manually installed packages are "unverified". Native editions should use a real WebView (not implemented).
