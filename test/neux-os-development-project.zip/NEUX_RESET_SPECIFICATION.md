# Reset All Settings (complete Neux wipe)

**Status:** implemented and unit-tested at the filesystem level

Path: Settings → About Device → Reset All Settings. Flow: warning screen titled "Erase all Neux data?" (exact text from the brief) + required checkbox → "Erase everything…" → final confirmation → progress log → reload into first-run setup. Implementation (`src/core/reset.ts`): write `neux:reset-pending`, close all Neux windows, clear and delete IndexedDB `neuxfs`, delete `neux-keys`, remove `neux:*` local/session storage keys, delete `neux-*` caches, clear the flag. If interrupted, boot finishes the wipe first. Only exact Neux-owned names are touched — never other data of the same origin, never the host OS. No automatic backup. Recovery → Factory reset uses the same service with an additional typed `ERASE` confirmation. Not covered: service-worker unregistration (the worker holds no user data).
