# Neux Architecture

**Status:** implemented (Web edition)

Stack: Next.js (App Router) used as a static single-page host + TypeScript + React. All OS logic runs in the browser; no backend is required. (The Postgres/Drizzle template in the repo only serves `/api/health` for the preview platform and is excluded from the static release.)

Layers: **shell** (React UI: windows, hotbar, panels) → **apps** (`src/apps`) → **core services** (`src/core`: `kernel` NeuxFS instance, `os` window/notification/dialog state, `settings`, `security`, `permissions`, `applications` (registry, `.wrapp`, store service), `file-associations`, `networking` (fetch, downloads, status, vpn), `users`, `updates`, `reset`, `recovery`, `virtualization`, `runtime/console`) → **adapters** (`src/adapters`; Web implemented, native stubs documented) → host.

Storage is behind `KVBackend` (IndexedDB now; memory for tests; SQLite planned for native). Security checks live in services (`NeuxFS.guard`, `security.checkOpen`, console role ranks, permission-checked package bridge), never only in the UI.
State: tiny external stores (`src/core/store.ts`) + `useSyncExternalStore`. Windows stay mounted when minimized/maximized/moved, so apps never reload on state change.
Boot: resume interrupted reset → mount NeuxFS → load settings → users → register apps/downloads/extensions → start services; failures show an emergency recovery screen.
