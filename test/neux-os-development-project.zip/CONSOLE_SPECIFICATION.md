# Console

**Status:** implemented

Parser (quote-aware tokenizer, longest-match command names, `--flag[=value]`), registry (`registerCommand`), executor with role check (`user < admin < root`), privileged-confirmation (`priv`, bypass with `--yes`), history, tab completion, audit log at `/System/Services/audit.log` (view with `audit`, root only).
Commands: help version echo whoami history clear · system info/status/repair · fs pwd/ls/cd/mkdir/touch/cat/write/delete/copy/move/rename/find/stat · user list/create/password/delete · app list/open/install/uninstall · net status · net beeco status · process list/kill · settings list/get/set · wr run/build/serve · vm list/register/start · recovery status/backup · open · notify · audit.
`wr serve` truthfully fails in the Web edition. `settings set` refuses `allowVM` and `isolation` (security-sensitive). Root powers apply only inside Neux. `user create` etc. have no password-prompt flow (use `--password=`).
