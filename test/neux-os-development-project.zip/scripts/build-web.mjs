// Builds the static Web edition into ./web-release (upload its CONTENTS to GitHub Pages).
// Usage: node scripts/build-web.mjs
import { execSync } from "node:child_process";
import { renameSync, existsSync, rmSync, cpSync, writeFileSync } from "node:fs";

const api = "src/app/api", hold = "src/app/__api_disabled__";
if (existsSync(hold)) renameSync(hold, api); // recover from an interrupted run
execSync("node scripts/build-store.mjs", { stdio: "inherit" });
rmSync("web-release", { recursive: true, force: true });
renameSync(api, hold); // the DB-backed health route cannot be exported statically
try {
  execSync("npx next build", { stdio: "inherit", env: { ...process.env, NEUX_EXPORT: "1" } });
} finally { renameSync(hold, api); }
// GitHub Pages: do not run Jekyll (it would hide folders starting with "_", such as _next)
writeFileSync("web-release/.nojekyll", "");
cpSync("web-release/index.html", "web-release/404.html");
console.log("\nWeb release ready in ./web-release — upload everything inside that folder.");
