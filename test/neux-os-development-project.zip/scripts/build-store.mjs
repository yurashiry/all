// Generates the Neux Store catalog and real .wrapp packages into public/store/.
// Run: node scripts/build-store.mjs   (committed output is already included)
import { zipSync, strToU8 } from "fflate";
import { createHash } from "node:crypto";
import { mkdirSync, writeFileSync, rmSync } from "node:fs";

const OUT = new URL("../public/store/", import.meta.url).pathname;
rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT + "packages", { recursive: true });

const W = (id, name, url, category, desc) => ({ id, name, url, category, desc });
const web = [
  ["Communication & Social", [
    W("telegram", "Telegram", "https://web.telegram.org/", "", "Telegram Web messenger."),
    W("whatsapp", "WhatsApp", "https://web.whatsapp.com/", "", "WhatsApp Web messenger."),
    W("discord", "Discord", "https://discord.com/app", "", "Voice, video and text communities."),
    W("instagram", "Instagram", "https://www.instagram.com/", "", "Photos and reels."),
    W("tiktok", "TikTok", "https://www.tiktok.com/", "", "Short-form video."),
    W("reddit", "Reddit", "https://www.reddit.com/", "", "Communities and discussions."),
    W("x", "X", "https://x.com/", "", "Posts and conversations."),
    W("pinterest", "Pinterest", "https://www.pinterest.com/", "", "Visual discovery."),
    W("slack", "Slack", "https://app.slack.com/", "", "Team messaging."),
    W("zoom", "Zoom", "https://app.zoom.us/wc", "", "Video meetings in the browser client."),
  ]],
  ["Google Services", [
    W("gmail", "Gmail", "https://mail.google.com/", "", "Email."),
    W("google-drive", "Google Drive", "https://drive.google.com/", "", "Cloud storage."),
    W("google-docs", "Google Docs", "https://docs.google.com/document/", "", "Documents."),
    W("google-sheets", "Google Sheets", "https://docs.google.com/spreadsheets/", "", "Spreadsheets."),
    W("google-slides", "Google Slides", "https://docs.google.com/presentation/", "", "Presentations."),
    W("google-calendar", "Google Calendar", "https://calendar.google.com/", "", "Calendar."),
    W("google-maps", "Google Maps", "https://www.google.com/maps", "", "Maps and navigation."),
    W("google-translate", "Google Translate", "https://translate.google.com/", "", "Translation."),
    W("google-photos", "Google Photos", "https://photos.google.com/", "", "Photo library."),
    W("google-keep", "Google Keep", "https://keep.google.com/", "", "Notes and lists."),
    W("youtube", "YouTube", "https://www.youtube.com/", "", "Video platform."),
    W("youtube-music", "YouTube Music", "https://music.youtube.com/", "", "Music streaming."),
    W("google-meet", "Google Meet", "https://meet.google.com/", "", "Video meetings."),
  ]],
  ["Work & Productivity", [
    W("notion", "Notion", "https://www.notion.so/", "", "Workspace and notes."),
    W("trello", "Trello", "https://trello.com/", "", "Kanban boards."),
    W("canva", "Canva", "https://www.canva.com/", "", "Design."),
    W("figma", "Figma", "https://www.figma.com/", "", "Interface design."),
    W("miro", "Miro", "https://miro.com/app/", "", "Online whiteboard."),
    W("todoist", "Todoist", "https://app.todoist.com/", "", "Task manager."),
    W("asana", "Asana", "https://app.asana.com/", "", "Work management."),
    W("dropbox", "Dropbox", "https://www.dropbox.com/home", "", "Cloud storage."),
    W("microsoft-365", "Microsoft 365", "https://www.microsoft365.com/", "", "Office apps online."),
    W("onedrive", "OneDrive", "https://onedrive.live.com/", "", "Cloud storage."),
    W("evernote", "Evernote", "https://www.evernote.com/client/web", "", "Notes."),
  ]],
  ["Development", [
    W("github", "GitHub", "https://github.com/", "", "Code hosting."),
    W("gitlab", "GitLab", "https://gitlab.com/", "", "DevOps platform."),
    W("codepen", "CodePen", "https://codepen.io/", "", "Front-end playground."),
    W("replit", "Replit", "https://replit.com/", "", "Online IDE."),
    W("stack-overflow", "Stack Overflow", "https://stackoverflow.com/", "", "Developer Q&A."),
    W("npm", "npm", "https://www.npmjs.com/", "", "JavaScript package registry."),
    W("vercel", "Vercel", "https://vercel.com/dashboard", "", "Deployment dashboard."),
    W("netlify", "Netlify", "https://app.netlify.com/", "", "Deployment dashboard."),
    W("cloudflare", "Cloudflare Dashboard", "https://dash.cloudflare.com/", "", "Cloudflare account dashboard."),
  ]],
  ["Entertainment", [
    W("apple-music", "Apple Music", "https://music.apple.com/", "", "Music streaming."),
    W("spotify", "Spotify", "https://open.spotify.com/", "", "Spotify Web Player."),
    W("soundcloud", "SoundCloud", "https://soundcloud.com/", "", "Audio platform."),
    W("netflix", "Netflix", "https://www.netflix.com/", "", "Streaming video."),
    W("twitch", "Twitch", "https://www.twitch.tv/", "", "Live streaming."),
    W("disney-plus", "Disney+", "https://www.disneyplus.com/", "", "Streaming video."),
    W("prime-video", "Prime Video", "https://www.primevideo.com/", "", "Streaming video."),
    W("crunchyroll", "Crunchyroll", "https://www.crunchyroll.com/", "", "Anime streaming."),
    W("letterboxd", "Letterboxd", "https://letterboxd.com/", "", "Film diary."),
  ]],
  ["Artificial Intelligence", [
    W("chatgpt", "ChatGPT", "https://chatgpt.com/", "", "AI assistant."),
    W("gemini", "Gemini", "https://gemini.google.com/", "", "AI assistant."),
    W("claude", "Claude", "https://claude.ai/", "", "AI assistant."),
    W("perplexity", "Perplexity", "https://www.perplexity.ai/", "", "AI search."),
    W("copilot", "Microsoft Copilot", "https://copilot.microsoft.com/", "", "AI assistant."),
    W("deepseek", "DeepSeek", "https://chat.deepseek.com/", "", "AI assistant."),
    W("poe", "Poe", "https://poe.com/", "", "AI chat aggregator."),
  ]],
  ["Shopping & Travel", [
    W("amazon", "Amazon", "https://www.amazon.com/", "", "Online store."),
    W("ebay", "eBay", "https://www.ebay.com/", "", "Marketplace."),
    W("aliexpress", "AliExpress", "https://www.aliexpress.com/", "", "Marketplace."),
    W("booking", "Booking.com", "https://www.booking.com/", "", "Accommodation."),
    W("airbnb", "Airbnb", "https://www.airbnb.com/", "", "Stays."),
    W("trip-com", "Trip.com", "https://www.trip.com/", "", "Travel booking."),
    W("skyscanner", "Skyscanner", "https://www.skyscanner.net/", "", "Flight search."),
    W("uber", "Uber", "https://m.uber.com/", "", "Rides."),
    W("bolt", "Bolt", "https://bolt.eu/", "", "Rides and mobility."),
  ]],
  ["News & Information", [
    W("bbc-news", "BBC News", "https://www.bbc.com/news", "", "News."),
    W("reuters", "Reuters", "https://www.reuters.com/", "", "News."),
    W("cnn", "CNN", "https://edition.cnn.com/", "", "News."),
    W("guardian", "The Guardian", "https://www.theguardian.com/", "", "News."),
    W("google-news", "Google News", "https://news.google.com/", "", "News aggregator."),
    W("wikipedia", "Wikipedia", "https://www.wikipedia.org/", "", "Encyclopedia."),
    W("medium", "Medium", "https://medium.com/", "", "Articles."),
  ]],
];
const REGIONS = {
  Ukraine: ["telegram", "bolt", "google-maps", "google-translate", "wikipedia", "youtube", "google-news"],
  "United States": ["netflix", "amazon", "uber", "disney-plus", "prime-video", "reddit"],
};
const hue = (s) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
const icon = (name) => {
  const ini = name.replace(/[^\p{L}\p{N} ]/gu, "").split(" ").filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
  const h = hue(name);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h} 75% 58%)"/><stop offset="1" stop-color="hsl(${(h + 40) % 360} 70% 38%)"/></linearGradient></defs><rect width="96" height="96" rx="22" fill="url(#g)"/><text x="48" y="60" font-family="Arial,sans-serif" font-size="${ini.length > 1 ? 38 : 46}" font-weight="700" text-anchor="middle" fill="#fff">${ini}</text></svg>`;
};
const entries = [];
function pack(m, files) {
  const z = { "manifest.json": strToU8(JSON.stringify(m, null, 2)), "assets/icon.svg": strToU8(icon(m.name)) };
  for (const [k, v] of Object.entries(files ?? {})) z[k] = strToU8(v);
  const bytes = zipSync(z, { level: 9 });
  writeFileSync(`${OUT}packages/${m.id}.wrapp`, bytes);
  entries.push({ id: m.id, name: m.name, version: m.version, category: m.category, description: m.description, publisher: m.publisher, type: m.type, url: m.url,
    packageUrl: `store/packages/${m.id}.wrapp`, sha256: createHash("sha256").update(bytes).digest("hex"), size: bytes.length, channel: m.channel, verified: m.verified,
    regions: Object.entries(REGIONS).filter(([, ids]) => ids.includes(m.id)).map(([r]) => r), permissions: m.permissions,
    changelog: m.changelog, compat: m.compat.platforms, icon: "data:image/svg+xml;utf8," + encodeURIComponent(icon(m.name)), screenshots: [], host: m.url ? new URL(m.url).host : undefined });
}
for (const [cat, list] of web) for (const a of list) {
  pack({ id: a.id, name: a.name, version: "1.0.0", category: "Web Apps · " + cat, description: `${a.desc} Opens the official service (${new URL(a.url).host}) in its own Neux window. Not affiliated with the service provider. Some services forbid embedding; Neux then offers an external-browser fallback.`,
    publisher: "HAORÏK Laboratory (packaging only)", type: "web", url: a.url, icon: "assets/icon.svg", permissions: ["notifications", "network"],
    window: { width: 1100, height: 720 }, compat: { platforms: ["web", "android", "windows", "macos"], minNeux: "0.1.0" }, verified: true, channel: "stable",
    changelog: "1.0.0 — Initial Neux Web App package." });
}
// First-party HTML apps that run in the sandboxed Neux runtime.
const timerHtml = `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="style.css"></head><body>
<h1 id="t">25:00</h1><div class="row"><button id="s">Start</button><button id="r">Reset</button></div><p id="m">Focus timer. Sessions are saved in this app's private storage.</p><script src="app.js"></script></body></html>`;
const timerCss = `body{font-family:system-ui,sans-serif;background:#10131a;color:#eef;display:grid;place-content:center;height:100vh;margin:0;text-align:center}h1{font-size:72px;margin:0 0 16px;font-variant-numeric:tabular-nums}button{padding:10px 18px;margin:4px;border:0;border-radius:8px;background:#5b8cff;color:#fff;font-size:15px;cursor:pointer}p{opacity:.7}`;
const timerJs = `let left=25*60,iv=null;const t=document.getElementById('t'),fmt=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
async function load(){const n=await Neux.storage.get('sessions');document.getElementById('m').textContent='Completed sessions: '+(n||0);}load();
document.getElementById('s').onclick=()=>{if(iv){clearInterval(iv);iv=null;return}iv=setInterval(async()=>{left--;t.textContent=fmt(left);if(left<=0){clearInterval(iv);iv=null;left=25*60;const n=((await Neux.storage.get('sessions'))||0)+1;await Neux.storage.set('sessions',n);Neux.notifications.show({title:'Focus session complete',message:'Take a break.'});load();}},1000)};
document.getElementById('r').onclick=()=>{clearInterval(iv);iv=null;left=25*60;t.textContent=fmt(left)};`;
pack({ id: "neux-timer", name: "Neux Timer", version: "1.0.0", category: "Utilities", description: "A focus timer that runs inside the sandboxed Neux runtime and uses the Neux API (notifications and private storage).",
  publisher: "HAORÏK Laboratory", type: "html", entry: "index.html", icon: "assets/icon.svg", permissions: ["notifications", "storage"], window: { width: 420, height: 380 },
  compat: { platforms: ["all"], minNeux: "0.1.0" }, verified: true, channel: "stable", changelog: "1.0.0 — First release." }, { "index.html": timerHtml, "style.css": timerCss, "app.js": timerJs });
const padHtml = `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;height:100%;background:#fff}canvas{width:100%;height:100%;display:block;touch-action:none}</style></head><body><canvas id="c"></canvas><script>
const c=document.getElementById('c'),x=c.getContext('2d');function fit(){c.width=c.clientWidth;c.height=c.clientHeight}fit();addEventListener('resize',fit);let d=false;
c.onpointerdown=e=>{d=true;x.beginPath();x.moveTo(e.offsetX,e.offsetY)};c.onpointermove=e=>{if(!d)return;x.lineWidth=3;x.lineCap='round';x.lineTo(e.offsetX,e.offsetY);x.stroke()};addEventListener('pointerup',()=>d=false);
</script></body></html>`;
pack({ id: "neux-sketchpad", name: "Neux Sketchpad", version: "0.9.0", category: "Utilities", description: "Beta: a minimal drawing surface running in the sandboxed runtime. Demonstrates the Beta channel.",
  publisher: "HAORÏK Laboratory", type: "html", entry: "index.html", icon: "assets/icon.svg", permissions: [], window: { width: 640, height: 480 },
  compat: { platforms: ["all"], minNeux: "0.1.0" }, verified: true, channel: "beta", changelog: "0.9.0 — Beta preview." }, { "index.html": padHtml });
entries.sort((a, b) => a.name.localeCompare(b.name));
writeFileSync(OUT + "catalog.json", JSON.stringify({ generated: new Date().toISOString(), entries }, null, 1));
console.log(`Wrote ${entries.length} packages to public/store/`);
