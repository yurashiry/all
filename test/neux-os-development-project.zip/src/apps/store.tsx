"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useStore } from "@/core/store";
import { jobs, enqueueInstall, cancelJob, retryJob, loadCatalog, updatesAvailable, type CatalogEntry, type Job } from "@/core/applications/store-service";
import { installedStore, uninstallApp, installFromBytes, parseWrapp, refreshInstalled, buildWrapp, type Manifest } from "@/core/applications/wrapp";
import { Ring, Tabs, Empty, useWin } from "@/shell/ui";
import { formatBytes, sha256Hex } from "@/core/util";
import { openApp, pickFile, alertBox, confirmBox, notify, closeWin, setTitle } from "@/core/os";
import { setSetting, useSetting, getSetting } from "@/core/settings";
import { fs } from "@/core/kernel";
import { AppIcon } from "@/shell/icons";
import { ALL_PERMISSIONS, grants, setGrant, type Permission } from "@/core/permissions";
import { isolationOn, trustedHashes, logEvent } from "@/core/security";
import { getSetting as gs } from "@/core/settings";
import { basename } from "@/core/filesystem/neuxfs";
import { pickHostFiles } from "@/shell/ui";

const ACTIVE = ["queued", "downloading", "verifying", "installing", "finishing"];
const rank = { stable: 0, beta: 1, developer: 2 } as const;

function Icon({ e, size = 48 }: { e: CatalogEntry; size?: number }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={e.icon} alt="" width={size} height={size} style={{ borderRadius: size * 0.24, flexShrink: 0 }} />;
}
function JobProgress({ j }: { j: Job }) {
  const label = j.state === "downloading" ? "Downloading" : j.state === "verifying" ? "Verifying" : j.state === "installing" ? "Installing" : j.state === "finishing" ? "Finishing" : "Queued";
  return (
    <div className="row" style={{ gap: 12 }}>
      <Ring percent={j.state === "queued" ? null : j.percent} size={52} />
      <div className="col small" style={{ gap: 1 }}><b>{label}</b><span className="dim">{j.state === "downloading" ? `${formatBytes(j.received)} / ${j.total ? formatBytes(j.total) : "unknown size"}` : j.state === "installing" ? `${j.filesDone}/${j.filesTotal} files` : j.step}</span></div>
      <button className="btn sm" onClick={() => cancelJob(j.id)}>Cancel</button>
    </div>
  );
}
function Actions({ e, big }: { e: CatalogEntry; big?: boolean }) {
  const job = useStore(jobs, (s) => s.list.find((j) => j.appId === e.id));
  const inst = useStore(installedStore, (s) => s.apps.find((a) => a.manifest.id === e.id));
  const upd = inst && inst.manifest.version !== e.version;
  if (job && ACTIVE.includes(job.state)) return <JobProgress j={job} />;
  if (job?.state === "failed") return <div className="col small"><span style={{ color: "var(--danger)" }}>Failed: {job.error}</span><button className="btn sm primary" onClick={() => retryJob(job.id)}>Retry</button></div>;
  if (inst) return <div className="row wrap"><button className={"btn primary" + (big ? "" : " sm")} onClick={() => openApp("pkg", { pkgId: e.id })}>Open</button>{upd && <button className="btn sm" onClick={() => enqueueInstall(e)}>Update to {e.version}</button>}{big && <button className="btn danger" onClick={async () => { if (await confirmBox("Uninstall", `Remove ${e.name} and its data?`, true, "Uninstall")) await uninstallApp(e.id); }}>Uninstall</button>}</div>;
  return <button className={"btn primary" + (big ? "" : " sm")} onClick={() => enqueueInstall(e)}>Install</button>;
}

export default function Store() {
  const cat = useStore(jobs, (s) => s.catalog); const err = useStore(jobs, (s) => s.catalogError); const list = useStore(jobs, (s) => s.list); const history = useStore(jobs, (s) => s.history);
  const installed = useStore(installedStore, (s) => s.apps); const channel = useSetting("channel"); const region = useSetting("region");
  const [section, setSection] = useState("all"); const [q, setQ] = useState(""); const [detail, setDetail] = useState<CatalogEntry | null>(null);
  const { params, rev } = useWin();
  useEffect(() => { if (params.pkg && cat) setDetail(cat.entries.find((e) => e.id === params.pkg) ?? null); }, [rev, cat, params.pkg]);
  const entries = useMemo(() => (cat?.entries ?? []).filter((e) => rank[e.channel] <= rank[channel]), [cat, channel]);
  const categories = useMemo(() => Array.from(new Set(entries.map((e) => e.category))).sort(), [entries]);
  const updates = updatesAvailable();
  const shown = entries.filter((e) => {
    if (q && !(e.name + " " + e.description + " " + e.category).toLowerCase().includes(q.toLowerCase())) return false;
    if (section === "all") return true; if (section === "installed") return installed.some((a) => a.manifest.id === e.id);
    if (section === "updates") return updates.some((u) => u.id === e.id); if (section.startsWith("region:")) return e.regions.includes(section.slice(7));
    return e.category === section;
  });
  const active = list.filter((j) => ACTIVE.includes(j.state));
  const fileInstall = async () => { const p = await pickFile({ filter: "wr", title: "Choose a .wrapp package" }); if (p) openApp("installer", { path: p[0] }); };
  const sideBtn = (id: string, label: string, badge?: number) => <button key={id} className={"side-item" + (section === id && !["queue", "history"].includes(section) ? " active" : "")} onClick={() => { setSection(id); setDetail(null); }}>{label}{badge ? <span className="badge" style={{ marginLeft: "auto" }}>{badge}</span> : null}</button>;
  return (
    <div className="app">
      <div className="sidebar" style={{ width: 210 }}>
        {sideBtn("all", "Discover")}{sideBtn("installed", "Installed", installed.length)}{sideBtn("updates", "Updates", updates.length)}
        <button className={"side-item" + (section === "queue" ? " active" : "")} onClick={() => { setSection("queue"); setDetail(null); }}>Install queue{active.length ? <span className="badge" style={{ marginLeft: "auto" }}>{active.length}</span> : null}</button>
        <button className={"side-item" + (section === "history" ? " active" : "")} onClick={() => { setSection("history"); setDetail(null); }}>History</button>
        <hr className="sep" /><div className="dim small" style={{ padding: "0 10px" }}>Collections</div>
        {["Ukraine", "United States"].map((r) => sideBtn("region:" + r, `${r}${region === r ? " ★" : ""}`))}
        <hr className="sep" /><div className="dim small" style={{ padding: "0 10px" }}>Categories</div>
        {categories.map((c) => sideBtn(c, c.replace("Web Apps · ", "Web · ")))}
      </div>
      <div className="col grow" style={{ gap: 0 }}>
        <div className="toolbar"><input className="input grow" placeholder="Search the Neux Store" value={q} onChange={(e) => { setQ(e.target.value); setDetail(null); if (["queue", "history"].includes(section)) setSection("all"); }} aria-label="Search the store" />
          <select className="input" style={{ width: 120 }} value={channel} onChange={(e) => setSetting("channel", e.target.value as never)} aria-label="Channel"><option value="stable">Stable</option><option value="beta">Beta</option><option value="developer">Developer</option></select>
          <button className="btn" onClick={fileInstall}>Install .wrapp file…</button></div>
        <div className="scroll grow" style={{ padding: 14 }}>
          {err && <div className="card" style={{ borderColor: "var(--danger)" }}>Could not load the catalog: {err}. <button className="btn sm" onClick={loadCatalog}>Retry</button></div>}
          {!cat && !err && <span className="spinner" />}
          {section === "queue" && <div className="col">{list.length === 0 ? <Empty>Nothing in the queue.</Empty> : list.map((j) => <div key={j.id} className="card row"><div className="grow"><b>{j.name}</b><div className="dim small">{j.state}{j.error ? ` — ${j.error}` : ""}</div></div>{ACTIVE.includes(j.state) ? <JobProgress j={j} /> : j.state === "failed" || j.state === "canceled" ? <button className="btn sm" onClick={() => retryJob(j.id)}>Retry</button> : <span className="badge ok">installed</span>}</div>)}</div>}
          {section === "history" && <table className="tbl"><thead><tr><th>When</th><th>App</th><th>Version</th><th>Result</th><th>Detail</th></tr></thead><tbody>{history.map((h, i) => <tr key={i}><td>{new Date(h.ts).toLocaleString()}</td><td>{h.name}</td><td>{h.version}</td><td><span className={"badge " + (h.result === "installed" ? "ok" : "bad")}>{h.result}</span></td><td className="dim small">{h.detail}</td></tr>)}</tbody></table>}
          {detail && !["queue", "history"].includes(section) && (
            <div className="col" style={{ gap: 14 }}>
              <button className="btn sm" style={{ alignSelf: "flex-start" }} onClick={() => setDetail(null)}>← Back</button>
              <div className="row" style={{ gap: 16, alignItems: "flex-start" }}><Icon e={detail} size={84} /><div className="col grow"><h2 style={{ margin: 0 }}>{detail.name}</h2><div className="dim">{detail.publisher} · {detail.category}</div><div className="row wrap">{detail.verified && <span className="badge ok">Official Neux package</span>}<span className="badge">{detail.channel}</span><span className="badge">v{detail.version}</span><span className="badge">{formatBytes(detail.size)} package</span></div><Actions e={detail} big /></div></div>
              <div>{detail.description}</div>
              <div className="card small col"><div><b>Type:</b> {detail.type === "web" ? `Neux Web App → ${detail.url}` : "Sandboxed Neux app"}</div><div><b>Permissions:</b> {detail.permissions.length ? detail.permissions.join(", ") : "none"}</div><div><b>Compatibility:</b> {detail.compat.join(", ")}</div><div><b>Package SHA-256:</b> <span className="mono" style={{ wordBreak: "break-all" }}>{detail.sha256}</span></div><div><b>Changelog:</b> {detail.changelog}</div><div><b>Screenshots:</b> <span className="dim">none published</span> · <b>Ratings & reviews:</b> <span className="dim">unavailable — needs a publishing backend (see STORE_SPECIFICATION.md)</span></div></div>
              {detail.type === "web" && <div className="dim small">Opens the official website in its own Neux window. Neux is not affiliated with the service. Some sites forbid embedding; Neux then offers an external-browser fallback and does not bypass security policies.</div>}
            </div>)}
          {!detail && !["queue", "history"].includes(section) && cat && (shown.length === 0 ? <Empty>{section === "updates" ? "All apps are up to date." : section === "installed" ? "No apps installed yet." : "No apps match."}</Empty> :
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 10 }}>{shown.map((e) => (
              <div key={e.id} className="card col" style={{ gap: 8 }}><div className="row" style={{ cursor: "pointer" }} onClick={() => setDetail(e)}><Icon e={e} /><div className="col grow" style={{ gap: 0, minWidth: 0 }}><b>{e.name}</b><span className="dim small" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.category.replace("Web Apps · ", "")}</span></div></div><div className="row" style={{ justifyContent: "space-between" }}><span className="dim small">{formatBytes(e.size)} · {e.channel}</span><Actions e={e} /></div></div>))}</div>)}
        </div>
      </div>
    </div>
  );
}

export function Installer() {
  const { params, id } = useWin(); const path = String(params.path ?? "");
  const [info, setInfo] = useState<{ m?: Manifest; sha?: string; err?: string; verifiedCatalog?: boolean }>({}); const [busy, setBusy] = useState(false); const [done, setDone] = useState("");
  useEffect(() => { (async () => { try { const b = await fs.readBytes(path); const p = await parseWrapp(b); const cat = jobs.get().catalog?.entries.find((e) => e.id === p.manifest.id && e.sha256 === p.sha256); setInfo({ m: p.manifest, sha: p.sha256, verifiedCatalog: !!cat }); } catch (e) { setInfo({ err: (e as Error).message }); } })(); }, [path]);
  const m = info.m;
  const install = async () => {
    setBusy(true);
    try {
      const mm = await installFromBytes(await fs.readBytes(path), "manual file " + basename(path));
      setDone(`Installed ${mm.name} ${mm.version}`); notify({ title: "App installed", message: mm.name, appId: "pkg" });
    } catch (e) { setInfo({ err: (e as Error).message }); }
    setBusy(false);
  };
  return (
    <div className="col" style={{ padding: 18, height: "100%", overflow: "auto" }}>
      <b style={{ fontSize: 18 }}>Neux Package Installer</b><div className="dim small mono">{path}</div>
      {info.err && <div className="card" role="alert" style={{ borderColor: "var(--danger)" }}>Cannot install: {info.err}</div>}
      {m && <><div className="row"><AppIcon id="installer" size={48} /><div><b>{m.name}</b> {m.version}<div className="dim small">{m.publisher} · {m.category} · {m.type === "web" ? "Web App → " + m.url : "sandboxed HTML app"}</div></div></div>
        <div>{m.description}</div>
        <div className="card small col"><div><b>Requested permissions:</b> {m.permissions.join(", ") || "none"}</div><div className="mono" style={{ wordBreak: "break-all" }}>SHA-256 {info.sha}</div>
          <div>{info.verifiedCatalog ? <span className="badge ok">Matches the official Neux catalog</span> : <span className="badge warn">Third-party / unverified package — no signature available. Install only if you trust the source.</span>}</div>
          <div className="dim">Camera, microphone and clipboard are never granted automatically.</div></div>
        {done ? <div role="status" className="badge ok">{done}</div> : <div className="row"><button className="btn primary" disabled={busy} onClick={install}>{busy ? <span className="spinner" /> : null}Install</button><button className="btn" onClick={() => closeWin(id, true)}>Cancel</button></div>}</>}
    </div>
  );
}

const BRIDGE = `(function(){var p={},n=0;function call(m,a){return new Promise(function(res,rej){var i=++n;p[i]=[res,rej];parent.postMessage({neux:1,id:i,method:m,args:a},'*');});}
addEventListener('message',function(e){var d=e.data;if(!d||!d.neuxReply)return;var h=p[d.id];if(!h)return;delete p[d.id];d.error?h[1](new Error(d.error)):h[0](d.result);});
window.Neux={notifications:{show:function(o){return call('notifications.show',[o])}},settings:{get:function(k){return call('settings.get',[k])}},storage:{get:function(k){return call('storage.get',[k])},set:function(k,v){return call('storage.set',[k,v])},remove:function(k){return call('storage.remove',[k])},list:function(){return call('storage.list',[])}},window:{setTitle:function(t){return call('window.setTitle',[t])}},files:{pickText:function(){return call('files.pickText',[])}}};})();`;

export function PkgApp() {
  const { params, id } = useWin(); const pkgId = String(params.pkgId);
  const app = useStore(installedStore, (s) => s.apps.find((a) => a.manifest.id === pkgId));
  const iso = useSetting("isolation");
  const [perms, setPerms] = useState<Permission[]>([]); const [key, setKey] = useState(0); const [src, setSrc] = useState(""); const [panel, setPanel] = useState(false);
  const [blocked, setBlocked] = useState(""); const frame = useRef<HTMLIFrameElement>(null);
  const m = app?.manifest;
  useEffect(() => { if (m) setTitle(id, m.name); grants(pkgId).then(setPerms); }, [pkgId, m, id, panel]);
  useEffect(() => {
    if (!m || m.type !== "html") return; let on = true;
    (async () => {
      if (iso && !m.verified) { const info = await fs.json<{ sha256: string }>(`/Applications/${pkgId}/install.json`, { sha256: "" }); if (!(await trustedHashes()).includes(info.sha256)) { setBlocked("File Isolation Protection is ON and this third-party package is not trusted. Open Secure Center to review it."); return; } }
      setBlocked("");
      let html = await fs.readText(`/Applications/${pkgId}/${m.entry}`);
      const inline = async (re: RegExp, wrap: (c: string) => string) => { for (const mt of [...html.matchAll(re)]) { try { const c = await fs.readText(`/Applications/${pkgId}/${mt[1]}`); html = html.replace(mt[0], wrap(c.replace(/<\/script/gi, "<\\/script"))); } catch { /* external or missing */ } } };
      await inline(/<link[^>]+href="([^":]+\.css)"[^>]*>/g, (c) => `<style>${c}</style>`);
      await inline(/<script[^>]+src="([^":]+\.js)"[^>]*><\/script>/g, (c) => `<script>${c}</script>`);
      const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:;${perms.includes("network") ? " connect-src https:;" : ""}">`;
      if (on) setSrc(`<!doctype html><html><head>${csp}<script>${BRIDGE}</script></head>` + html.replace(/<!doctype html>/i, "").replace(/<html[^>]*>/i, "").replace(/<head[^>]*>/i, "<head>") + "</html>");
    })();
    return () => { on = false; };
  }, [m, pkgId, key, iso, perms]);
  useEffect(() => {
    if (!m || m.type !== "html") return;
    const h = async (e: MessageEvent) => {
      if (e.source !== frame.current?.contentWindow || !e.data?.neux) return;
      const { id: rid, method, args } = e.data as { id: number; method: string; args: unknown[] };
      const reply = (r: { result?: unknown; error?: string }) => (e.source as Window).postMessage({ neuxReply: 1, id: rid, ...r }, "*");
      const need = async (p: Permission) => { if (!(await grants(pkgId)).includes(p)) throw new Error(`Permission denied: ${p}`); };
      try {
        const safeKey = (k: unknown) => { if (typeof k !== "string" || !/^[\w.-]{1,64}$/.test(k)) throw new Error("Invalid storage key"); return `/Applications/${pkgId}/data/${k}.json`; };
        if (method === "notifications.show") { await need("notifications"); const o = args[0] as { title?: string; message?: string }; notify({ title: String(o?.title ?? m.name).slice(0, 80), message: String(o?.message ?? "").slice(0, 300), appId: "pkg" }); reply({ result: true }); }
        else if (method === "settings.get") { const k = String(args[0]); if (!["theme", "accent", "language"].includes(k)) throw new Error("Setting not readable by apps"); reply({ result: gs(k as "theme") }); }
        else if (method === "storage.get") { await need("storage"); const p = safeKey(args[0]); reply({ result: (await fs.exists(p)) ? JSON.parse(await fs.readText(p)) : null }); }
        else if (method === "storage.set") { await need("storage"); const s = JSON.stringify(args[1] ?? null); if (s.length > 1_000_000) throw new Error("Value too large (1 MB limit)"); await fs.writeFile(safeKey(args[0]), s, { role: "root" }); reply({ result: true }); }
        else if (method === "storage.remove") { await need("storage"); const p = safeKey(args[0]); if (await fs.exists(p)) await fs.remove(p, { role: "root" }); reply({ result: true }); }
        else if (method === "storage.list") { await need("storage"); reply({ result: (await fs.list(`/Applications/${pkgId}/data`)).map((n) => n.name.replace(/\.json$/, "")) }); }
        else if (method === "window.setTitle") { setTitle(id, String(args[0]).slice(0, 80)); reply({ result: true }); }
        else if (method === "files.pickText") { await need("files.read"); const p = await pickFile({ filter: "document", title: `${m.name} wants to open a file` }); reply({ result: p ? await fs.readText(p[0]) : null }); }
        else throw new Error("Unknown API " + method);
      } catch (er) { reply({ error: (er as Error).message }); }
    };
    window.addEventListener("message", h); return () => window.removeEventListener("message", h);
  }, [m, pkgId, id]);
  if (!m) return <Empty>This app is not installed.</Empty>;
  const allow = iso ? "" : [perms.includes("camera") && "camera", perms.includes("microphone") && "microphone", perms.includes("clipboard") && "clipboard-read; clipboard-write", "fullscreen", "autoplay"].filter(Boolean).join("; ");
  return (
    <div className="col" style={{ height: "100%", gap: 0 }}>
      <div className="toolbar">
        <AppIcon id={"pkg:" + pkgId} size={22} /><b>{m.name}</b><span className="dim small">{m.type === "web" ? new URL(m.url!).host : "sandboxed app v" + m.version}</span><span className="grow" />
        <button className="btn sm" onClick={() => setKey((k) => k + 1)}>Reload</button>
        {m.type === "web" && <button className="btn sm" onClick={() => window.open(m.url, "_blank", "noopener,noreferrer")}>Open in browser tab</button>}
        <button className="btn sm" onClick={() => setPanel(!panel)}>Permissions & site settings</button>
      </div>
      {panel && <div className="card col" style={{ margin: 8 }}><b>Permissions for {m.name}</b>{iso && <div className="badge warn">File Isolation Protection is ON: camera, microphone and clipboard are denied regardless of the settings below.</div>}
        <div className="row wrap">{ALL_PERMISSIONS.filter((p) => ["notifications", "storage", "clipboard", "camera", "microphone", "network"].includes(p)).map((p) => <label key={p} className="row small"><input type="checkbox" checked={perms.includes(p)} onChange={async (e) => { await setGrant(pkgId, p, e.target.checked); setPerms(await grants(pkgId)); setKey((k) => k + 1); }} />{p}</label>)}</div>
        <div className="dim small">Session: {m.type === "web" ? "cookies/storage are kept by your browser for the site if it allows third-party storage; Neux cannot guarantee login persistence in an embedded frame." : "app data is stored in NeuxFS/Applications/" + pkgId + "/data."} Navigation: the frame cannot navigate Neux itself (no top-navigation).</div></div>}
      {m.type === "web" && <div className="small dim" style={{ padding: "4px 12px", borderBottom: "1px solid var(--border)" }}>If the page stays blank, the site forbids embedding (X-Frame-Options / CSP). Neux does not bypass this — use “Open in browser tab”.</div>}
      <div className="grow" style={{ position: "relative" }}>
        {blocked ? <div style={{ padding: 20 }} className="col"><b style={{ color: "var(--danger)" }}>Blocked by Secure Center</b><div>{blocked}</div><button className="btn" onClick={() => openApp("secure")}>Open Secure Center</button></div>
          : m.type === "web" ? <iframe key={key} ref={frame} title={m.name} src={m.url} style={{ width: "100%", height: "100%", border: 0, background: "#fff" }} sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals" allow={allow} referrerPolicy="strict-origin-when-cross-origin" />
          : src ? <iframe key={key} ref={frame} title={m.name} srcDoc={src} style={{ width: "100%", height: "100%", border: 0, background: "#fff" }} sandbox="allow-scripts allow-modals" allow={allow} /> : <span className="spinner" />}
      </div>
    </div>
  );
}

export function AppBuilder() {
  const [name, setName] = useState("My App"); const [type, setType] = useState<"web" | "html">("html"); const [url, setUrl] = useState("https://example.com/");
  const [html, setHtml] = useState('<!doctype html><html><body style="font-family:sans-serif;padding:24px"><h1>Hello from my Neux app</h1><button id="b">Notify</button><script>document.getElementById("b").onclick=()=>Neux.notifications.show({title:"Hi",message:"Works"})</script></body></html>');
  const [desc, setDesc] = useState("My custom Neux app."); const [perms, setPerms] = useState<Permission[]>(["notifications"]); const [msg, setMsg] = useState("");
  const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "my-app";
  const build = async () => {
    const ini = name.trim().slice(0, 2).toUpperCase();
    const icon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" rx="22" fill="hsl(${[...name].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7)} 60% 45%)"/><text x="48" y="60" font-family="Arial" font-size="40" font-weight="700" text-anchor="middle" fill="#fff">${ini.replace(/[<>&]/g, "")}</text></svg>`;
    const manifest = { id, name, version: "1.0.0", category: "Utilities", description: desc, publisher: "Local user", type, url: type === "web" ? url : undefined, entry: "index.html", icon: "assets/icon.svg", permissions: perms, window: { width: 900, height: 600 }, compat: { platforms: ["web"], minNeux: "0.1.0" } };
    const files: Record<string, string> = { "manifest.json": JSON.stringify(manifest, null, 2), "assets/icon.svg": icon }; if (type === "html") files["index.html"] = html;
    const bytes = buildWrapp(files); await parseWrapp(bytes); return bytes;
  };
  return (
    <div className="col scroll" style={{ padding: 16, height: "100%" }}>
      <b style={{ fontSize: 17 }}>App Builder</b><div className="dim small">Creates a real .wrapp package (ZIP with manifest, icon and entry), validates it, and installs it as an unverified local app.</div>
      <label className="col" style={{ gap: 3 }}>Name<input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label><div className="dim small">Package id: {id}</div>
      <label className="col" style={{ gap: 3 }}>Description<input className="input" value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
      <div className="row"><label className="row"><input type="radio" checked={type === "html"} onChange={() => setType("html")} />Sandboxed HTML app</label><label className="row"><input type="radio" checked={type === "web"} onChange={() => setType("web")} />Web App (https URL)</label></div>
      {type === "web" ? <input className="input" value={url} onChange={(e) => setUrl(e.target.value)} aria-label="URL" /> : <textarea className="input mono" rows={8} value={html} onChange={(e) => setHtml(e.target.value)} aria-label="HTML" />}
      <div className="row wrap">{(["notifications", "storage", "network", "files.read"] as Permission[]).map((p) => <label key={p} className="row small"><input type="checkbox" checked={perms.includes(p)} onChange={(e) => setPerms(e.target.checked ? [...perms, p] : perms.filter((x) => x !== p))} />{p}</label>)}</div>
      <div className="row"><button className="btn primary" onClick={async () => { try { await installFromBytes(await build(), "App Builder"); setMsg(`Installed “${name}”. Find it in the Start menu.`); } catch (e) { setMsg("Error: " + (e as Error).message); } }}>Build & install</button>
        <button className="btn" onClick={async () => { try { const p = await fs.uniquePath(`/Users/Default/Documents/${id}.wrapp`); await fs.writeFile(p, await build()); setMsg("Saved " + p); } catch (e) { setMsg("Error: " + (e as Error).message); } }}>Save .wrapp to Documents</button></div>
      {msg && <div role="status">{msg}</div>}
    </div>
  );
}
void useMemo; void Tabs; void alertBox; void getSetting; void sha256Hex; void isolationOn; void logEvent; void pickHostFiles; void refreshInstalled;
