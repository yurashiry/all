"use client";
import { useEffect, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { useShortcut, useWin, Tabs, Empty, pickHostFiles, downloadBlob, useFs } from "@/shell/ui";
import { downloads, startDownload, pauseDownload, resumeDownload, cancelDownload, retryDownload, removeDownload, type Download } from "@/core/networking/downloads";
import { useStore } from "@/core/store";
import { openApp, notify, alertBox, setTitle, showMenu, closeWin } from "@/core/os";
import { openFile } from "@/core/file-associations";
import { formatBytes } from "@/core/util";
import { Glyph } from "@/shell/icons";
import { websocketTransport } from "@/protocols/beeco";
import { installedStore } from "@/core/applications/wrapp";

interface Tab { id: number; url: string; title: string; back: string[]; fwd: string[]; private: boolean; group: string; key: number; closed?: boolean }
interface Data { bookmarks: { title: string; url: string }[]; history: { url: string; title: string; ts: number }[]; engine: string; sitePerms: Record<string, string[]>; allowPopups: boolean }
const PATH = "/Configuration/browser.json";
const ENGINES: Record<string, [string, string]> = { duckduckgo: ["DuckDuckGo", "https://duckduckgo.com/?q="], google: ["Google", "https://www.google.com/search?q="], bing: ["Bing", "https://www.bing.com/search?q="], wikipedia: ["Wikipedia", "https://en.wikipedia.org/w/index.php?search="], brave: ["Brave Search", "https://search.brave.com/search?q="] };
const GROUPS = ["", "#5b8cff", "#e0457b", "#2fb67c", "#ff8a3d"];
export const PROTOCOLS: { scheme: string; status: "supported" | "partial" | "unsupported"; note: string }[] = [
  { scheme: "https", status: "supported", note: "Loaded in a sandboxed frame. Sites that send X-Frame-Options/CSP frame-ancestors refuse to display; use 'Open in host browser'." },
  { scheme: "http", status: "partial", note: "Blocked as mixed content when Neux itself is served over HTTPS (browser rule)." },
  { scheme: "wss / ws", status: "partial", note: "Not a page. The browser can probe a WebSocket endpoint (real handshake) but cannot render it." },
  { scheme: "beeco", status: "partial", note: "beeco://host opens the BEECO app. Rendering BEECO content pages is not implemented." },
  { scheme: "neux", status: "supported", note: "neux:app/<id> opens a built-in app or neux:app/pkg:<id> an installed one." },
  { scheme: "file, ftp, javascript, data", status: "unsupported", note: "Refused for security (no host-file access, no script injection)." },
];
export function resolveInput(input: string, engine: string): { kind: "url" | "app" | "ws" | "beeco" | "blocked"; value: string } {
  const t = input.trim();
  if (/^neux:app\//i.test(t)) return { kind: "app", value: t.replace(/^neux:app\//i, "") };
  if (/^beeco:\/\//i.test(t)) return { kind: "beeco", value: t };
  if (/^wss?:\/\//i.test(t)) return { kind: "ws", value: t };
  if (/^(file|ftp|javascript|data|blob):/i.test(t)) return { kind: "blocked", value: t };
  if (/^https?:\/\//i.test(t)) return { kind: "url", value: t };
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(t) && !t.includes(" ")) return { kind: "url", value: "https://" + t };
  if (/^localhost(:\d+)?(\/.*)?$/.test(t)) return { kind: "url", value: "http://" + t };
  return { kind: "url", value: (ENGINES[engine] ?? ENGINES.duckduckgo)[1] + encodeURIComponent(t) };
}
let tabSeq = 1;
const newTab = (url = "", priv = false): Tab => ({ id: tabSeq++, url, title: url ? url : "New tab", back: [], fwd: [], private: priv, group: "", key: 0 });

export default function Browser() {
  const { params, rev } = useWin();
  const [data, , ] = useFs(() => fs.json<Data>(PATH, { bookmarks: [], history: [], engine: "duckduckgo", sitePerms: {}, allowPopups: false }), [], { bookmarks: [], history: [], engine: "duckduckgo", sitePerms: {}, allowPopups: false } as Data);
  const [local, setLocal] = useState<Data | null>(null);
  const d = local ?? data; const save = (n: Data) => { setLocal(n); void fs.saveJson(PATH, n); };
  const [tabs, setTabs] = useState<Tab[]>([newTab()]); const [active, setActive] = useState(tabs[0].id); const [closed, setClosed] = useState<Tab[]>([]);
  const [panel, setPanel] = useState<"" | "history" | "bookmarks" | "downloads" | "protocols" | "perms" | "find">(""); const [addr, setAddr] = useState(""); const [dlUrl, setDlUrl] = useState(""); const [msg, setMsg] = useState("");
  const addrRef = useRef<HTMLInputElement>(null); const tab = tabs.find((t) => t.id === active) ?? tabs[0];
  const dls = useStore(downloads, (s) => s.items);
  useEffect(() => { setAddr(tab.url); }, [tab.id, tab.url]);
  useEffect(() => { if (params.url) navigate(String(params.url), true); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [rev]);
  const upd = (id: number, p: Partial<Tab>) => setTabs((ts) => ts.map((t) => (t.id === id ? { ...t, ...p } : t)));
  const winId = useWin().id;
  useEffect(() => { setTitle(winId, "Browser — " + (tab.url ? new URL(tab.url, "https://x").host || tab.title : "New tab")); }, [tab.url, tab.title, winId]);
  function navigate(input: string, newT = false) {
    const r = resolveInput(input, d.engine); setMsg("");
    if (r.kind === "app") { if (r.value.startsWith("pkg:")) openApp("pkg", { pkgId: r.value.slice(4) }); else if (!openApp(r.value)) setMsg("Unknown app: " + r.value); return; }
    if (r.kind === "beeco") { openApp("beeco"); return; }
    if (r.kind === "blocked") { setMsg(`The ${r.value.split(":")[0]}: scheme is blocked by Neux for security.`); return; }
    if (r.kind === "ws") { setMsg(`Probing ${r.value} …`); websocketTransport(r.value, 5000).then((t) => { t.close(); setMsg(`${r.value}: WebSocket handshake succeeded (endpoint reachable). Not a renderable page.`); }).catch((e) => setMsg(`${r.value}: ${(e as Error).message}`)); return; }
    const t = newT ? newTab(r.value) : tab; if (newT) { setTabs((ts) => [...ts, t]); setActive(t.id); }
    else upd(t.id, { url: r.value, title: r.value, back: tab.url ? [...tab.back, tab.url] : tab.back, fwd: [] });
    if (!tab.private && !t.private) { const n = { ...d, history: [{ url: r.value, title: r.value, ts: Date.now() }, ...d.history].slice(0, 500) }; save(n); }
  }
  const go = (dir: -1 | 1) => { if (dir < 0 && tab.back.length) upd(tab.id, { url: tab.back[tab.back.length - 1], back: tab.back.slice(0, -1), fwd: tab.url ? [tab.url, ...tab.fwd] : tab.fwd }); if (dir > 0 && tab.fwd.length) upd(tab.id, { url: tab.fwd[0], fwd: tab.fwd.slice(1), back: tab.url ? [...tab.back, tab.url] : tab.back }); };
  const close = (id: number) => { const t = tabs.find((x) => x.id === id); if (!t) return; if (!t.private && t.url) setClosed((c) => [t, ...c].slice(0, 20)); const rest = tabs.filter((x) => x.id !== id); if (!rest.length) { closeWin(winId, true); return; } setTabs(rest); if (active === id) setActive(rest[Math.max(0, tabs.findIndex((x) => x.id === id) - 1)].id); };
  const add = (priv = false) => { const t = newTab("", priv); setTabs((ts) => [...ts, t]); setActive(t.id); setTimeout(() => addrRef.current?.focus(), 30); };
  const host = (u: string) => { try { return new URL(u).host; } catch { return ""; } };
  const bookmarked = d.bookmarks.some((b) => b.url === tab.url);
  useShortcut("browser.newTab", () => add(), [tabs]); useShortcut("win.closeTab", () => close(tab.id), [tabs, active]);
  useShortcut("browser.restoreTab", () => { const t = closed[0]; if (!t) return false; setClosed(closed.slice(1)); const nt = { ...t, id: tabSeq++ }; setTabs((ts) => [...ts, nt]); setActive(nt.id); }, [closed]);
  useShortcut("browser.nextTab", () => { const i = tabs.findIndex((t) => t.id === active); setActive(tabs[(i + 1) % tabs.length].id); }, [tabs, active]);
  useShortcut("browser.prevTab", () => { const i = tabs.findIndex((t) => t.id === active); setActive(tabs[(i - 1 + tabs.length) % tabs.length].id); }, [tabs, active]);
  useShortcut("browser.address", () => { addrRef.current?.focus(); addrRef.current?.select(); }, []);
  useShortcut("browser.reload", () => upd(tab.id, { key: tab.key + 1 }), [tab]);
  useShortcut("browser.bookmark", () => toggleBookmark(), [tab, d]);
  useShortcut("browser.history", () => setPanel((p) => (p === "history" ? "" : "history")), []);
  useShortcut("browser.downloads", () => setPanel((p) => (p === "downloads" ? "" : "downloads")), []);
  useShortcut("browser.find", () => setPanel((p) => (p === "find" ? "" : "find")), []);
  useShortcut("win.new", () => add(), [tabs]);
  function toggleBookmark() { if (!tab.url) return; save({ ...d, bookmarks: bookmarked ? d.bookmarks.filter((b) => b.url !== tab.url) : [...d.bookmarks, { title: tab.title, url: tab.url }] }); }
  const perms = d.sitePerms[host(tab.url)] ?? [];
  const allow = [perms.includes("camera") && "camera", perms.includes("microphone") && "microphone", perms.includes("geolocation") && "geolocation", "fullscreen"].filter(Boolean).join("; ");
  const sandbox = "allow-scripts allow-same-origin allow-forms allow-downloads allow-modals" + (d.allowPopups ? " allow-popups allow-popups-to-escape-sandbox" : "");
  const exportBm = () => downloadBlob(new Blob([JSON.stringify(d.bookmarks, null, 1)], { type: "application/json" }), "neux-bookmarks.json");
  const importBm = async () => { const [f] = await pickHostFiles(".json,.html"); if (!f) return; try { const t = await f.text(); const list: { title: string; url: string }[] = t.trim().startsWith("[") ? JSON.parse(t) : [...t.matchAll(/<a[^>]+href="(https?:[^"]+)"[^>]*>([^<]*)</gi)].map((m) => ({ url: m[1], title: m[2] })); const valid = list.filter((b) => typeof b.url === "string" && /^https?:/.test(b.url)); save({ ...d, bookmarks: [...d.bookmarks, ...valid.filter((b) => !d.bookmarks.some((x) => x.url === b.url))] }); setMsg(`Imported ${valid.length} bookmark(s)`); } catch (e) { setMsg("Import failed: " + (e as Error).message); } };
  const startPage = (
    <div className="col" style={{ alignItems: "center", padding: 40, gap: 18, height: "100%", overflow: "auto" }}>
      <div style={{ fontSize: 30, fontWeight: 300 }}>{tab.private ? "Private tab" : "Neux Browser"}</div>
      <input className="input" style={{ maxWidth: 520 }} placeholder={`Search with ${ENGINES[d.engine]?.[0]} or enter an address`} onKeyDown={(e) => e.key === "Enter" && navigate((e.target as HTMLInputElement).value)} aria-label="Start page search" />
      {tab.private && <div className="dim small" style={{ maxWidth: 480, textAlign: "center" }}>Private tabs are not added to history and are not remembered by Neux. They do not hide activity from websites, your network, or the host browser.</div>}
      <div className="row wrap" style={{ justifyContent: "center", maxWidth: 640 }}>{d.bookmarks.slice(0, 12).map((b) => <button key={b.url} className="btn" onClick={() => navigate(b.url)}>{b.title.slice(0, 22)}</button>)}{!d.bookmarks.length && <span className="dim small">Bookmarks you add (Ctrl+D) appear here.</span>}</div>
    </div>);
  return (
    <div className="col" style={{ height: "100%", gap: 0, background: "color-mix(in srgb, var(--surface-solid) 70%, transparent)" }}>
      <div className="tabbar">{tabs.map((t) => <button key={t.id} className={"tab" + (t.id === active ? " active" : "")} style={{ borderTop: t.group ? `3px solid ${t.group}` : undefined }} onClick={() => setActive(t.id)} onContextMenu={(e) => showMenu(e, [{ label: "Close tab", action: () => close(t.id) }, { label: "Duplicate", action: () => { const n = { ...t, id: tabSeq++ }; setTabs((x) => [...x, n]); setActive(n.id); } }, ...GROUPS.map((g, i) => ({ label: g ? `Group: colour ${i}` : "Remove from group", action: () => upd(t.id, { group: g }) }))])} title={t.url || "New tab"}>{t.private && "🕶 "}{(t.url ? host(t.url) || t.title : "New tab")}<span role="button" aria-label="Close tab" onClick={(e) => { e.stopPropagation(); close(t.id); }} style={{ opacity: 0.7 }}>×</span></button>)}
        <button className="btn sm ghost" onClick={() => add()} aria-label="New tab">+</button><button className="btn sm ghost" onClick={() => add(true)} title="New private tab">🕶</button></div>
      <div className="toolbar">
        <button className="btn sm" disabled={!tab.back.length} onClick={() => go(-1)} aria-label="Back">←</button><button className="btn sm" disabled={!tab.fwd.length} onClick={() => go(1)} aria-label="Forward">→</button>
        <button className="btn sm" onClick={() => upd(tab.id, { key: tab.key + 1 })} aria-label="Reload">⟳</button>
        <input ref={addrRef} className="input grow" value={addr} onChange={(e) => setAddr(e.target.value)} onFocus={(e) => e.target.select()} onKeyDown={(e) => e.key === "Enter" && navigate(addr)} aria-label="Address bar" placeholder="Search or enter address (https, neux:app/…, beeco://…)" />
        <button className="btn sm" onClick={toggleBookmark} aria-label="Bookmark" title="Bookmark (Ctrl+D)" style={{ color: bookmarked ? "var(--warn)" : undefined }}>{bookmarked ? "★" : "☆"}</button>
        <button className="btn sm" onClick={() => tab.url && window.open(tab.url, "_blank", "noopener,noreferrer")} disabled={!tab.url} title="Open this page in the host browser">↗</button>
        <select className="input" style={{ width: 120 }} value={panel} onChange={(e) => setPanel(e.target.value as typeof panel)} aria-label="Browser panels"><option value="">Panels…</option><option value="bookmarks">Bookmarks</option><option value="history">History</option><option value="downloads">Downloads{dls.some((x) => x.state === "downloading") ? " ⬇" : ""}</option><option value="protocols">Protocol Manager</option><option value="perms">Site permissions</option></select>
      </div>
      {msg && <div className="small" style={{ padding: "4px 12px" }} role="status">{msg}</div>}
      <div className="row grow" style={{ alignItems: "stretch", gap: 0, minHeight: 0 }}>
        <div className="grow" style={{ position: "relative", minWidth: 0 }}>
          {tabs.map((t) => <div key={t.id} style={{ position: "absolute", inset: 0, display: t.id === active ? "block" : "none" }}>{t.url ? <iframe key={t.key} title={t.title} src={t.url} sandbox={sandbox} allow={allow} referrerPolicy={t.private ? "no-referrer" : "strict-origin-when-cross-origin"} style={{ width: "100%", height: "100%", border: 0, background: "#fff" }} /> : t.id === active ? startPage : null}</div>)}
          {tab.url && <div className="small dim" style={{ position: "absolute", bottom: 4, left: 8, background: "var(--surface-solid)", padding: "2px 8px", borderRadius: 6, opacity: 0.85 }}>Blank page? The site forbids embedding — use ↗ to open it in the host browser.</div>}
        </div>
        {panel && (
          <div className="col solid" style={{ width: 340, borderLeft: "1px solid var(--border)", padding: 10, overflow: "auto" }}>
            <div className="row"><b className="grow">{({ history: "History", bookmarks: "Bookmarks", downloads: "Downloads", protocols: "Protocol Manager", perms: "Site permissions & settings", find: "Find on page" } as Record<string, string>)[panel]}</b><button className="btn sm ghost" onClick={() => setPanel("")} aria-label="Close panel">×</button></div>
            {panel === "history" && <>{d.history.length === 0 ? <Empty>No history.</Empty> : d.history.map((h, i) => <div key={i} className="frow" onClick={() => navigate(h.url)}><span className="small grow" style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{h.url}</span><span className="dim small">{new Date(h.ts).toLocaleTimeString()}</span></div>)}{d.history.length > 0 && <button className="btn sm danger" onClick={() => save({ ...d, history: [] })}>Clear history</button>}</>}
            {panel === "bookmarks" && <><div className="row"><button className="btn sm" onClick={exportBm}>Export</button><button className="btn sm" onClick={importBm}>Import…</button></div>{d.bookmarks.length === 0 ? <Empty>No bookmarks.</Empty> : d.bookmarks.map((b) => <div key={b.url} className="frow"><span className="grow small" style={{ overflow: "hidden", textOverflow: "ellipsis", cursor: "pointer" }} onClick={() => navigate(b.url)}>{b.title}</span><button className="btn sm ghost" onClick={() => save({ ...d, bookmarks: d.bookmarks.filter((x) => x.url !== b.url) })}>×</button></div>)}</>}
            {panel === "downloads" && <Downloads url={dlUrl} setUrl={setDlUrl} items={dls} />}
            {panel === "protocols" && PROTOCOLS.map((p) => <div key={p.scheme} className="card small"><b>{p.scheme}:</b> <span className={"badge " + (p.status === "supported" ? "ok" : p.status === "partial" ? "warn" : "bad")}>{p.status}</span><div className="dim">{p.note}</div></div>)}
            {panel === "perms" && <>
              <label className="col small" style={{ gap: 3 }}>Search engine<select className="input" value={d.engine} onChange={(e) => save({ ...d, engine: e.target.value })}>{Object.entries(ENGINES).map(([k, [n]]) => <option key={k} value={k}>{n}</option>)}</select></label>
              <label className="row small"><input type="checkbox" checked={d.allowPopups} onChange={(e) => save({ ...d, allowPopups: e.target.checked })} />Allow pop-ups from sites (blocked by default)</label>
              <hr className="sep" /><b className="small">Permissions for {host(tab.url) || "(no site)"}</b>
              {["camera", "microphone", "geolocation"].map((p) => <label key={p} className="row small"><input type="checkbox" disabled={!tab.url} checked={perms.includes(p)} onChange={(e) => { const h = host(tab.url); save({ ...d, sitePerms: { ...d.sitePerms, [h]: e.target.checked ? [...perms, p] : perms.filter((x) => x !== p) } }); upd(tab.id, { key: tab.key + 1 }); }} />{p}</label>)}
              <div className="dim small">Extensions: the Neux Browser does not support browser extensions yet. Scripts on pages run in a sandboxed frame.</div></>}
            {panel === "find" && <div className="dim small">Find-in-page is unavailable for websites: browsers do not let a web app read cross-origin pages. Use the host browser&apos;s find (Ctrl+F in a host tab via ↗).</div>}
          </div>)}
      </div>
    </div>
  );
}

function Downloads({ url, setUrl, items }: { url: string; setUrl: (s: string) => void; items: Download[] }) {
  return <>
    <div className="row"><input className="input" placeholder="https://… file URL" value={url} onChange={(e) => setUrl(e.target.value)} aria-label="Download URL" onKeyDown={(e) => { if (e.key === "Enter" && /^https?:\/\//.test(url)) { startDownload(url); setUrl(""); } }} /><button className="btn primary sm" disabled={!/^https?:\/\//.test(url)} onClick={() => { startDownload(url); setUrl(""); }}>Download</button></div>
    <div className="dim small">Saved to NeuxFS/Users/Default/Downloads. In a browser, downloads only work from servers that send CORS headers (a web-platform rule Neux cannot bypass); otherwise you get a clear error.</div>
    {items.length === 0 && <Empty>No downloads.</Empty>}
    {items.map((d) => { const pct = d.total ? (d.received / d.total) * 100 : null; return (
      <div key={d.id} className="card col small" style={{ gap: 4 }}>
        <div className="row"><b className="grow" style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{d.name}</b><span className={"badge " + (d.state === "done" ? "ok" : d.state === "failed" ? "bad" : "")}>{d.state}</span></div>
        <div className="dim" style={{ overflow: "hidden", textOverflow: "ellipsis" }} title={d.url}>{d.url}</div>
        {(d.state === "downloading" || d.state === "paused") && <><div className="pbar"><div style={{ width: pct === null ? "30%" : pct + "%" }} /></div><div className="dim">{formatBytes(d.received)} / {d.total ? formatBytes(d.total) : "unknown"} {pct !== null && `(${pct.toFixed(1)}%)`}</div></>}
        {d.state === "done" && <div className="dim">{formatBytes(d.received)} · {d.mime}</div>}{d.error && <div style={{ color: "var(--danger)" }}>{d.error}</div>}
        <div className="row wrap">
          {d.state === "downloading" && <><button className="btn sm" onClick={() => pauseDownload(d.id)}>Pause</button><button className="btn sm" onClick={() => cancelDownload(d.id)}>Cancel</button></>}
          {d.state === "paused" && <><button className="btn sm" onClick={() => resumeDownload(d.id)}>Resume</button><button className="btn sm" onClick={() => cancelDownload(d.id)}>Cancel</button></>}
          {(d.state === "failed" || d.state === "canceled") && <><button className="btn sm" onClick={() => retryDownload(d.id)}>Retry</button><button className="btn sm" onClick={() => window.open(d.url, "_blank", "noopener,noreferrer")}>Open in host browser</button></>}
          {d.state === "done" && d.path && <><button className="btn sm primary" onClick={() => openFile(d.path!)}>Open</button><button className="btn sm" onClick={() => openApp("explorer", { path: "/Users/Default/Downloads" })}>Downloads folder</button></>}
          {d.state !== "downloading" && <button className="btn sm ghost" onClick={() => removeDownload(d.id)}>Remove</button>}
        </div></div>); })}
  </>;
}
void Glyph; void notify; void alertBox; void Tabs; void installedStore;
