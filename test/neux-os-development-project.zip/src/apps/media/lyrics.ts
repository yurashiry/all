export interface LyricLine { t: number | null; text: string }
export interface Lyrics { synced: boolean; lines: LyricLine[]; source: string }

const TS = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
/** Parse LRC. Only real [mm:ss.xx] timestamps are used; lines without timestamps make the result unsynced. Offset tag honoured. */
export function parseLRC(text: string, source = "LRC"): Lyrics | null {
  const out: LyricLine[] = [];
  let offset = 0, stamped = 0, plain = 0;
  for (const raw of text.replace(/\r/g, "").split("\n")) {
    const off = raw.match(/^\[offset:\s*(-?\d+)\]/i);
    if (off) { offset = Number(off[1]) / 1000; continue; }
    if (/^\[(ti|ar|al|au|by|length|re|ve):/i.test(raw)) continue;
    const stamps = [...raw.matchAll(TS)];
    const body = raw.replace(TS, "").trim();
    if (stamps.length) {
      for (const m of stamps) { const frac = m[3] ? Number(m[3].padEnd(3, "0").slice(0, 3)) / 1000 : 0; out.push({ t: Number(m[1]) * 60 + Number(m[2]) + frac - offset, text: body }); stamped++; }
    } else if (body) { out.push({ t: null, text: body }); plain++; }
  }
  if (!out.length) return null;
  if (stamped && !plain) { out.sort((a, b) => a.t! - b.t!); return { synced: true, lines: out, source }; }
  if (stamped && plain) return { synced: false, lines: out.map((l) => ({ t: null, text: l.text })).filter((l) => l.text), source: source + " (mixed timestamps ignored)" };
  return { synced: false, lines: out, source };
}
/** Index of the line active at time t (seconds). -1 before the first line. */
export function activeLine(l: Lyrics, t: number): number {
  if (!l.synced) return -1;
  let lo = 0, hi = l.lines.length - 1, ans = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (l.lines[m].t! <= t) { ans = m; lo = m + 1; } else hi = m - 1; }
  return ans;
}
/** Online lookup via LRCLIB (open, keyless, CORS-enabled public API). Returns null when nothing is found. */
export async function fetchOnlineLyrics(title: string, artist: string, album?: string, duration?: number, signal?: AbortSignal): Promise<Lyrics | null> {
  const q = new URLSearchParams({ track_name: title, artist_name: artist });
  if (album) q.set("album_name", album);
  if (duration) q.set("duration", String(Math.round(duration)));
  const r = await fetch(`https://lrclib.net/api/get?${q}`, { signal, headers: { "Lrclib-Client": "Neux OS (HAORIK Laboratory)" } });
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`Lyrics provider returned HTTP ${r.status}`);
  const j = (await r.json()) as { syncedLyrics?: string; plainLyrics?: string };
  if (j.syncedLyrics) { const p = parseLRC(j.syncedLyrics, "LRCLIB (online)"); if (p?.synced) return p; }
  if (j.plainLyrics) return parseLRC(j.plainLyrics, "LRCLIB (online, unsynced)");
  return null;
}
