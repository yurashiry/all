import { parseLRC, type Lyrics } from "./lyrics";
import { extOf } from "../../core/util";

export interface Tech { codec: string; lossless: boolean | null; sampleRate?: number; bitDepth?: number; channels?: number; bitrate?: number }
export interface Tags { title?: string; artist?: string; album?: string; art?: Blob; lyrics?: Lyrics; tech: Tech }

function dec(enc: number, b: Uint8Array): string {
  if (enc === 0) return new TextDecoder("latin1").decode(b);
  if (enc === 3) return new TextDecoder("utf-8").decode(b);
  if (enc === 2) return new TextDecoder("utf-16be").decode(b);
  return new TextDecoder(b[0] === 0xfe && b[1] === 0xff ? "utf-16be" : "utf-16le").decode(b[0] === 0xff || b[0] === 0xfe ? b.slice(2) : b);
}
function termIdx(b: Uint8Array, from: number, enc: number): number {
  if (enc === 1 || enc === 2) { for (let i = from; i + 1 < b.length; i += 2) if (b[i] === 0 && b[i + 1] === 0) return i; return b.length; }
  const i = b.indexOf(0, from); return i < 0 ? b.length : i;
}
const synchsafe = (b: Uint8Array, o: number) => (b[o] << 21) | (b[o + 1] << 14) | (b[o + 2] << 7) | b[o + 3];

function readId3(b: Uint8Array, t: Tags) {
  if (b[0] !== 0x49 || b[1] !== 0x44 || b[2] !== 0x33) return 0;
  const ver = b[3], size = synchsafe(b, 6), end = Math.min(b.length, 10 + size);
  let p = 10;
  if (b[5] & 0x40) p += synchsafe(b, 10); // extended header
  while (p + 10 < end) {
    const id = String.fromCharCode(b[p], b[p + 1], b[p + 2], b[p + 3]);
    if (!/^[A-Z0-9]{4}$/.test(id)) break;
    const sz = ver === 4 ? synchsafe(b, p + 4) : (b[p + 4] << 24 | b[p + 5] << 16 | b[p + 6] << 8 | b[p + 7]) >>> 0;
    const body = b.subarray(p + 10, p + 10 + sz);
    p += 10 + sz;
    if (!body.length) continue;
    const enc = body[0];
    if (id === "TIT2") t.title = dec(enc, body.subarray(1)).replace(/\0+$/, "");
    else if (id === "TPE1") t.artist = dec(enc, body.subarray(1)).replace(/\0+$/, "");
    else if (id === "TALB") t.album = dec(enc, body.subarray(1)).replace(/\0+$/, "");
    else if (id === "USLT") {
      const d = termIdx(body, 4, enc), start = d + (enc === 1 || enc === 2 ? 2 : 1);
      const text = dec(enc, body.subarray(start));
      const l = parseLRC(text, "Embedded lyrics (ID3 USLT)");
      if (l && !t.lyrics) t.lyrics = l;
    } else if (id === "SYLT" && !t.lyrics?.synced) {
      const fmt = body[4], ctype = body[5]; void ctype;
      const d = termIdx(body, 6, enc); let q = d + (enc === 1 || enc === 2 ? 2 : 1);
      const lines: { t: number; text: string }[] = [];
      while (q < body.length) {
        const e = termIdx(body, q, enc);
        const text = dec(enc, body.subarray(q, e)).replace(/^\n/, "");
        q = e + (enc === 1 || enc === 2 ? 2 : 1);
        if (q + 4 > body.length) break;
        const ts = (body[q] << 24 | body[q + 1] << 16 | body[q + 2] << 8 | body[q + 3]) >>> 0; q += 4;
        if (fmt === 2) lines.push({ t: ts / 1000, text });
      }
      if (lines.length) t.lyrics = { synced: true, lines: lines.filter((l) => l.text.trim()), source: "Embedded synchronized lyrics (ID3 SYLT)" };
    } else if (id === "APIC" && !t.art) {
      const m = body.indexOf(0, 1); const mime = new TextDecoder("latin1").decode(body.subarray(1, m));
      const ds = termIdx(body, m + 2, enc); const start = ds + (enc === 1 || enc === 2 ? 2 : 1);
      t.art = new Blob([body.slice(start)], { type: mime.includes("/") ? mime : "image/jpeg" });
    }
  }
  return end;
}
function mp3Header(b: Uint8Array, from: number, tech: Tech) {
  const br = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320], sr = [44100, 48000, 32000];
  for (let i = from; i < Math.min(b.length - 4, from + 8192); i++) {
    if (b[i] === 0xff && (b[i + 1] & 0xe0) === 0xe0 && ((b[i + 1] >> 3) & 3) === 3 && ((b[i + 1] >> 1) & 3) === 1) {
      const bi = b[i + 2] >> 4, si = (b[i + 2] >> 2) & 3;
      if (bi > 0 && bi < 15 && si < 3) { tech.bitrate = br[bi] * 1000; tech.sampleRate = sr[si]; tech.channels = (b[i + 3] >> 6) === 3 ? 1 : 2; return; }
    }
  }
}
function vorbisLyrics(b: Uint8Array, t: Tags) {
  const lim = Math.min(b.length, 4_000_000), txt = new TextDecoder("latin1").decode(b.subarray(0, lim));
  for (const key of ["SYNCEDLYRICS=", "LYRICS=", "UNSYNCEDLYRICS="]) {
    const i = txt.toUpperCase().indexOf(key);
    if (i < 4) continue;
    const len = b[i - 4] | b[i - 3] << 8 | b[i - 2] << 16 | b[i - 1] << 24;
    if (len <= 0 || len > 500000) continue;
    const s = new TextDecoder("utf-8").decode(b.subarray(i + key.length, i - 0 + len));
    const l = parseLRC(s, "Embedded lyrics (Vorbis comment)");
    if (l) { t.lyrics = l; return; }
  }
}
export function readTags(b: Uint8Array, name: string): Tags {
  const ext = extOf(name);
  const t: Tags = { tech: { codec: ext.toUpperCase() || "unknown", lossless: null } };
  const start = readId3(b, t);
  const tech = t.tech;
  if (ext === "flac" || (b[0] === 0x66 && b[1] === 0x4c && b[2] === 0x61 && b[3] === 0x43)) {
    tech.codec = "FLAC"; tech.lossless = true;
    if (b[4] === 0) { // STREAMINFO
      const o = 8 + 10;
      tech.sampleRate = (b[o] << 12) | (b[o + 1] << 4) | (b[o + 2] >> 4);
      tech.channels = ((b[o + 2] >> 1) & 7) + 1;
      tech.bitDepth = (((b[o + 2] & 1) << 4) | (b[o + 3] >> 4)) + 1;
    }
    vorbisLyrics(b, t);
    const m = new TextDecoder("latin1").decode(b.subarray(0, Math.min(b.length, 200000)));
    const g = (k: string) => { const i = m.toUpperCase().indexOf(k + "="); if (i < 4) return undefined; const len = b[i - 4] | b[i - 3] << 8 | b[i - 2] << 16; return new TextDecoder().decode(b.subarray(i + k.length + 1, i - 4 + 4 + len)); };
    t.title ??= g("TITLE"); t.artist ??= g("ARTIST"); t.album ??= g("ALBUM");
  } else if (ext === "wav" && String.fromCharCode(...b.subarray(0, 4)) === "RIFF") {
    tech.codec = "PCM (WAV)"; tech.lossless = true;
    let p = 12;
    while (p + 8 < b.length) {
      const id = String.fromCharCode(...b.subarray(p, p + 4)), sz = b[p + 4] | b[p + 5] << 8 | b[p + 6] << 16 | b[p + 7] << 24;
      if (id === "fmt ") { tech.channels = b[p + 10] | b[p + 11] << 8; tech.sampleRate = (b[p + 12] | b[p + 13] << 8 | b[p + 14] << 16 | b[p + 15] << 24) >>> 0; tech.bitDepth = b[p + 22] | b[p + 23] << 8; tech.bitrate = (tech.sampleRate ?? 0) * (tech.bitDepth ?? 0) * (tech.channels ?? 0); break; }
      p += 8 + sz + (sz & 1);
    }
  } else if (ext === "mp3") { tech.codec = "MP3 (MPEG-1 Layer III)"; tech.lossless = false; mp3Header(b, start, tech); }
  else if (["aac", "m4a"].includes(ext)) { tech.codec = ext === "m4a" ? "AAC / ALAC (M4A container)" : "AAC"; tech.lossless = ext === "m4a" ? null : false; }
  else if (ext === "ogg") { tech.codec = "Ogg Vorbis / Opus"; tech.lossless = false; vorbisLyrics(b, t); }
  else if (ext === "opus") { tech.codec = "Opus"; tech.lossless = false; vorbisLyrics(b, t); }
  else if (ext === "aiff" || ext === "aif") { tech.codec = "AIFF (PCM)"; tech.lossless = true; }
  return t;
}
