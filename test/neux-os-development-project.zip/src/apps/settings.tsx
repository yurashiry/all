"use client";
import { useEffect, useState } from "react";
import { useWin, Setting, Switch, Tabs, useFs } from "@/shell/ui";
import { settingsStore, setSetting, LANGUAGES, REGIONS, applyUkraineSuggestions, translatedLanguages } from "@/core/settings";
import { useStore } from "@/core/store";
import { SHORTCUTS, bindingOf, comboFromEvent, conflictsFor, normalizeCombo } from "@/core/shortcuts";
import { DEFAULT_ASSOC, setAssociation, resetAssociations } from "@/core/file-associations";
import { BUILTIN } from "@/core/applications/registry";
import { os, alertBox, confirmBox, openApp, pickFile, notify } from "@/core/os";
import { setIsolation } from "@/core/security";
import { allowVmHelpers } from "./helpers";
import { vmSupport, setAllowVm } from "@/core/virtualization";
import { listUsers, createUser, setPassword, deleteUser } from "@/core/users";
import { net } from "@/core/networking/status";
import { checkForUpdate, applyWebUpdate, type UpdateInfo } from "@/core/updates";
import { NEUX_VERSION, fs } from "@/core/kernel";
import { detectPlatform } from "@/adapters/web/platform";
import { installExtension, listExtensions, removeExtension, applyExtensions } from "@/core/extensions";
import { setupStore } from "@/shell/Overlays";
import { resetAllNeuxData } from "@/core/reset";
import { formatBytes } from "@/core/util";
import type { Role } from "@/core/filesystem/neuxfs";

const PAGES: [string, string][] = [["personalization", "Personalization"], ["language", "Language & Region"], ["accessibility", "Accessibility"], ["shortcuts", "Keyboard Shortcuts"], ["assoc", "File Associations"], ["network", "Network"], ["vpn", "VPN"], ["security", "Security"], ["users", "Users"], ["updates", "Updates"], ["extensions", "Extensions"], ["system", "System"], ["about", "About Device"]];
const ACCENTS = ["#5b8cff", "#8a5bff", "#e0457b", "#ff8a3d", "#2fb67c", "#19a7ce"];

export default function Settings() {
  const { params, rev } = useWin();
  const [page, setPage] = useState(String(params.page ?? "personalization"));
  useEffect(() => { if (params.page) setPage(String(params.page)); }, [rev, params.page]);
  return (
    <div className="app">
      <div className="sidebar">{PAGES.map(([id, l]) => <button key={id} className={"side-item" + (page === id ? " active" : "")} onClick={() => setPage(id)}>{l}</button>)}</div>
      <div className="grow scroll" style={{ padding: "8px 20px 20px" }}>
        <h2 style={{ fontWeight: 500 }}>{PAGES.find(([id]) => id === page)?.[1]}</h2>
        {page === "personalization" && <Personalization />}{page === "language" && <Language />}{page === "accessibility" && <Accessibility />}
        {page === "shortcuts" && <Shortcuts />}{page === "assoc" && <Assoc />}{page === "network" && <Network />}{page === "vpn" && <Vpn />}
        {page === "security" && <Security />}{page === "users" && <Users />}{page === "updates" && <Updates />}{page === "extensions" && <Extensions />}
        {page === "system" && <System />}{page === "about" && <About />}
      </div>
    </div>
  );
}
function Personalization() {
  const s = useStore(settingsStore, (x) => x);
  return <>
    <Setting title="Theme" desc="Dark, light, or follow the host."><select className="input" style={{ width: 130 }} value={s.theme} onChange={(e) => setSetting("theme", e.target.value as never)} aria-label="Theme"><option value="dark">Dark</option><option value="light">Light</option><option value="auto">Automatic</option></select></Setting>
    <Setting title="Accent colour"><div className="row">{ACCENTS.map((c) => <button key={c} aria-label={`Accent ${c}`} onClick={() => setSetting("accent", c)} style={{ width: 26, height: 26, borderRadius: 8, background: c, border: s.accent === c ? "3px solid var(--text)" : "1px solid var(--border)", cursor: "pointer" }} />)}<input type="color" value={s.accent} onChange={(e) => setSetting("accent", e.target.value)} aria-label="Custom accent" /></div></Setting>
    <Setting title="Glass blur" desc="Translucent window blur. Turn off for better performance."><Switch label="Glass blur" checked={s.blur} onChange={(v) => setSetting("blur", v)} /></Setting>
    <Setting title="24-hour clock"><Switch label="24-hour clock" checked={s.use24h} onChange={(v) => setSetting("use24h", v)} /></Setting>
    <Setting title="Wallpaper, themes and widgets" desc="Choose wallpapers, use a picture from NeuxFS, manage desktop widgets."><button className="btn" onClick={() => openApp("themes")}>Themes</button><button className="btn" onClick={() => openApp("widgets")}>Widgets</button></Setting>
    <Setting title="Hotbar pinned apps" desc="Pin or unpin from the Start menu or by right-clicking an app on the Hotbar. Nothing is pinned by default."><span className="badge">{s.pinned.length} pinned</span><button className="btn" onClick={() => setSetting("pinned", [])} disabled={!s.pinned.length}>Unpin all</button></Setting>
  </>;
}
function Language() {
  const s = useStore(settingsStore, (x) => x);
  return <>
    <Setting title="Primary language" desc={`Fully translated shell: ${translatedLanguages.join(", ")}. Other languages fall back to English.`}><select className="input" style={{ width: 220 }} value={s.language} onChange={(e) => setSetting("language", e.target.value)} aria-label="Primary language">{LANGUAGES.map(([c, l]) => <option key={c} value={c}>{l}</option>)}</select></Setting>
    <Setting title="Secondary language"><select className="input" style={{ width: 220 }} value={s.secondaryLanguage} onChange={(e) => setSetting("secondaryLanguage", e.target.value)} aria-label="Secondary language"><option value="">None</option>{LANGUAGES.filter(([c]) => c !== s.language).map(([c, l]) => <option key={c} value={c}>{l}</option>)}</select></Setting>
    <Setting title="Region" desc="Affects formats and suggestions only."><select className="input" style={{ width: 220 }} value={s.region} onChange={(e) => setSetting("region", e.target.value)} aria-label="Region"><option value="">Not set</option><optgroup label="Pinned">{REGIONS.pinned.map((r) => <option key={r}>{r}</option>)}</optgroup><optgroup label="All regions">{REGIONS.others.map((r) => <option key={r}>{r}</option>)}</optgroup></select></Setting>
    <Setting title="Time zone"><input className="input" style={{ width: 220 }} value={s.timezone} onChange={(e) => setSetting("timezone", e.target.value)} aria-label="Time zone" /></Setting>
    <Setting title="Currency"><input className="input" style={{ width: 90 }} value={s.currency} onChange={(e) => setSetting("currency", e.target.value.toUpperCase().slice(0, 3))} aria-label="Currency" /></Setting>
    {s.region === "Ukraine" && <Setting title="Ukrainian suggestions" desc="Ukrainian language, hryvnia, Europe/Kyiv, regional wallpaper & Store collection."><button className="btn" onClick={() => { applyUkraineSuggestions(); setSetting("wallpaper", "ua-sky"); }}>Apply</button></Setting>}
    <Setting title="Language packs" desc="Downloadable packs are not implemented yet; translations ship with Neux."><span className="badge warn">not available</span></Setting>
    <p className="dim small">Preview: {new Date().toLocaleDateString(s.language)} · {(1234567.89).toLocaleString(s.language)} · {new Intl.NumberFormat(s.language, { style: "currency", currency: s.currency || "USD" }).format(1234.5)}</p>
  </>;
}
function Accessibility() {
  const s = useStore(settingsStore, (x) => x);
  return <>
    <Setting title="Reduce motion" desc="Disables window and panel animations (also follows your OS preference)."><Switch label="Reduce motion" checked={s.reduceMotion} onChange={(v) => setSetting("reduceMotion", v)} /></Setting>
    <Setting title="High contrast" desc="Opaque surfaces and strong borders."><Switch label="High contrast" checked={s.highContrast} onChange={(v) => setSetting("highContrast", v)} /></Setting>
    <Setting title="Text size" desc={`${Math.round(s.fontScale * 100)}%`}><input className="range" type="range" min={0.85} max={1.5} step={0.05} value={s.fontScale} onChange={(e) => setSetting("fontScale", Number(e.target.value))} aria-label="Text size" style={{ width: 160 }} /></Setting>
    <p className="dim small">Keyboard: every window, menu and dialog is reachable with Tab; Escape closes menus and dialogs; window controls have text labels for screen readers.</p>
  </>;
}
function Shortcuts() {
  const map = useStore(settingsStore, (s) => s.shortcuts);
  const [q, setQ] = useState(""); const [cat, setCat] = useState("All"); const [rec, setRec] = useState<string | null>(null);
  const cats = ["All", ...Array.from(new Set(SHORTCUTS.map((s) => s.category)))];
  const list = SHORTCUTS.filter((s) => (cat === "All" || s.category === cat) && (s.label + s.keys + s.category).toLowerCase().includes(q.toLowerCase()));
  const assign = async (id: string, e: React.KeyboardEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (e.key === "Escape") return setRec(null);
    const combo = comboFromEvent(e.nativeEvent); if (!combo) return;
    const cf = conflictsFor(id, combo, map);
    if (cf.length && !(await confirmBox("Shortcut conflict", `${combo} is already used by: ${cf.map((c) => c.label).join(", ")}.\nAssign anyway? (The other shortcut will keep the same key; the focused app wins.)`, false, "Assign anyway"))) return setRec(null);
    setSetting("shortcuts", { ...map, [id]: combo }); setRec(null);
  };
  return <>
    <div className="row wrap"><input className="input" style={{ width: 220 }} placeholder="Search shortcuts" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search shortcuts" /><select className="input" style={{ width: 150 }} value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Category">{cats.map((c) => <option key={c}>{c}</option>)}</select><button className="btn" onClick={async () => { if (await confirmBox("Restore defaults", "Reset all shortcuts to their defaults?")) setSetting("shortcuts", {}); }}>Restore defaults</button></div>
    <p className="dim small">Ctrl is used on both Windows and macOS (never silently replaced by Command). Scopes: <b>system</b> (global), <b>app</b> (focused application), <b>editor</b> (document), <b>input</b> (text fields — never intercepted).</p>
    <table className="tbl"><thead><tr><th>Action</th><th>Scope</th><th>Shortcut</th><th>Platform notes</th><th /></tr></thead><tbody>{list.map((s) => {
      const cur = bindingOf(s), custom = !!map[s.id]; const cf = conflictsFor(s.id, cur, map);
      return <tr key={s.id}><td>{s.label}<div className="dim small">{s.category}</div></td><td><span className="badge">{s.scope}</span></td>
        <td>{rec === s.id ? <input className="input" autoFocus readOnly value="Press keys… (Esc cancels)" onKeyDown={(e) => assign(s.id, e)} onBlur={() => setRec(null)} aria-label={`Record shortcut for ${s.label}`} /> : <><kbd>{cur}</kbd>{s.alt && !custom && <> or <kbd>{s.alt}</kbd></>}{custom && <span className="badge ok" style={{ marginLeft: 6 }}>custom</span>}{cf.length > 0 && <div className="small" style={{ color: "var(--warn)" }}>⚠ also: {cf.map((c) => c.label).join(", ")}</div>}</>}</td>
        <td className="small dim">{s.reserved ?? s.note ?? "Works in all editions."}</td>
        <td><div className="row"><button className="btn sm" onClick={() => setRec(s.id)} disabled={s.scope === "input"} title={s.scope === "input" ? "Native text editing shortcuts cannot be reassigned" : ""}>Change</button>{custom && <button className="btn sm ghost" onClick={() => { const m = { ...map }; delete m[s.id]; setSetting("shortcuts", m); }}>Reset</button>}</div></td></tr>;
    })}</tbody></table>
    {list.length === 0 && <p className="dim">No shortcuts match.</p>}
    <p className="dim small">Reserved combos: Alt+Tab, Alt+F4, Win+arrows and some Ctrl+key combos belong to the host OS or browser. Neux binds them where possible and offers alternatives (shown above).</p>
    <span style={{ display: "none" }}>{normalizeCombo("x")}</span>
  </>;
}
function Assoc() {
  const as = useStore(settingsStore, (s) => s.assoc);
  const exts = Array.from(new Set([...Object.keys(DEFAULT_ASSOC), ...Object.keys(as)])).sort();
  return <>
    <p className="dim small">Which app opens each file type. Unknown types are never executed.</p>
    <div className="row"><button className="btn" onClick={resetAssociations}>Reset to defaults</button></div>
    <table className="tbl"><tbody>{exts.map((e) => <tr key={e}><td><b>.{e}</b></td><td><select className="input" value={as[e] ?? DEFAULT_ASSOC[e]} onChange={(ev) => setAssociation(e, ev.target.value)} aria-label={`Default app for .${e}`}>{BUILTIN.filter((b) => !["picker", "openwith"].includes(b.id)).map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></td></tr>)}</tbody></table>
  </>;
}
function Network() {
  const n = useStore(net, (s) => s);
  return <>
    <Setting title="Internet (host connection)" desc={`Neux uses your device's existing connection. Type: ${n.connection}.`}><span className={"badge " + (n.online ? "ok" : "bad")}>{n.online ? "online" : "offline"}</span></Setting>
    <Setting title="BEECO" desc={n.beeco.detail}><span className={"badge " + (n.beeco.state === "connected" ? "ok" : "warn")}>{n.beeco.state}</span><button className="btn" onClick={() => openApp("beeco")}>Open BEECO</button></Setting>
    <Setting title="Wi-Fi networks" desc="Web browsers cannot list or join Wi-Fi networks. Native editions expose this only where OS permissions allow."><span className="badge warn">unavailable on Web</span></Setting>
    <p className="dim small">BEECO is a logical networking layer. It is not Wi-Fi, not an ISP, not a SIM and not a VPN.</p>
  </>;
}
function Vpn() {
  const s = useStore(settingsStore, (x) => x); const sup = vmSupport();
  return <>
    <Setting title="VPN Manager" desc="Import subscriptions, view servers. Device-wide tunnelling needs a native edition."><button className="btn" onClick={() => openApp("vpn")}>Open VPN Manager</button></Setting>
    <hr className="sep" />
    <Setting title="Allow adding VM" desc="Lets compatible virtual-machine apps register with Neux. Default: OFF. Virtualization is a separate subsystem and not a VPN feature. Turning this OFF blocks adding and starting VMs but never deletes VM data.">
      <Switch label="Allow adding VM" checked={s.allowVM} onChange={(v) => { setAllowVm(v); allowVmHelpers.noop(); }} /></Setting>
    <div className="card small"><b>Virtualization status:</b> {sup.supported ? "supported" : "no hypervisor available in this edition"}<ul style={{ margin: "6px 0 0 18px" }}>{sup.reasons.map((r) => <li key={r}>{r}</li>)}</ul>Registered VM apps: {s.vmRegistry.length ? s.vmRegistry.join(", ") : "none"}. Enabling the toggle does not create a hypervisor; it only permits registration. Console: <code>vm list</code>.</div>
  </>;
}
function Security() {
  const iso = useStore(settingsStore, (s) => s.isolation);
  return <>
    <Setting title="File Isolation Protection" desc="Blocks untrusted scripts/packages from running and denies clipboard/camera/mic to apps. Manage details in Secure Center."><Switch label="File Isolation Protection" checked={iso} onChange={(v) => setIsolation(v)} /></Setting>
    <Setting title="Secure Center" desc="Quarantine, inspection, trusted exceptions, history."><button className="btn" onClick={() => openApp("secure")}>Open</button></Setting>
  </>;
}
function Users() {
  const me = useStore(os, (s) => s.user);
  const [users, reload] = useFs(listUsers, [], [] as Awaited<ReturnType<typeof listUsers>>);
  const [name, setName] = useState(""); const [pw, setPw] = useState(""); const [role, setRole] = useState<Role>("user"); const [msg, setMsg] = useState("");
  const admin = me && me.role !== "user";
  const act = async (f: () => Promise<void>) => { try { await f(); setMsg(""); reload(); } catch (e) { setMsg((e as Error).message); } };
  return <>
    {users.map((u) => <Setting key={u.name} title={`${u.name} ${u.name === me?.name ? "(you)" : ""}`} desc={`${u.role} · ${u.hash ? "password set" : "no password"}`}>
      {(admin || u.name === me?.name) && <button className="btn sm" onClick={async () => { const { promptBox } = await import("@/core/os"); const p = await promptBox("Change password", `New password for ${u.name}`); if (p) act(() => setPassword(u.name, p)); }}>Password</button>}
      {admin && u.name !== me?.name && <button className="btn sm danger" onClick={async () => { if (await confirmBox("Delete user", `Delete ${u.name}?`, true, "Delete")) act(() => deleteUser(u.name)); }}>Delete</button>}</Setting>)}
    {admin ? <div className="card col"><b>Add user</b><div className="row wrap"><input className="input" style={{ width: 160 }} placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} aria-label="New user name" /><input className="input" style={{ width: 160 }} type="password" placeholder="Password (optional)" value={pw} onChange={(e) => setPw(e.target.value)} aria-label="New user password" /><select className="input" style={{ width: 110 }} value={role} onChange={(e) => setRole(e.target.value as Role)} aria-label="Role"><option value="user">User</option><option value="admin">Admin</option></select><button className="btn primary" onClick={() => act(async () => { await createUser(name, role, pw || undefined); setName(""); setPw(""); })}>Create</button></div></div> : <p className="dim">Only administrators can add users.</p>}
    {msg && <div role="alert" style={{ color: "var(--danger)" }}>{msg}</div>}
    <p className="dim small">Roles: User, Admin, Root. Root applies only inside Neux (never the host OS). The Console enforces roles at the command boundary and writes an audit log.</p>
  </>;
}
function Updates() {
  const s = useStore(settingsStore, (x) => x); const [info, setInfo] = useState<UpdateInfo | null>(null); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const check = async () => { setBusy(true); setErr(""); try { setInfo(await checkForUpdate()); } catch (e) { setErr((e as Error).message); } setBusy(false); };
  useEffect(() => { if (s.autoUpdate) void check(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);
  return <>
    <Setting title="Automatic updates" desc="Check for a newer deployed version when Settings opens. You can turn this off."><Switch label="Automatic updates" checked={s.autoUpdate} onChange={(v) => setSetting("autoUpdate", v)} /></Setting>
    <Setting title="Channel"><select className="input" style={{ width: 140 }} value={s.channel} onChange={(e) => setSetting("channel", e.target.value as never)} aria-label="Update channel"><option value="stable">Stable</option><option value="beta">Beta</option><option value="developer">Developer</option></select></Setting>
    <Setting title={`Installed version ${NEUX_VERSION}`} desc={info ? (info.available ? `Version ${info.latest} is available on the ${info.channel} channel. ${info.notes}` : `You have the latest ${info.channel} version.`) : err ? `Check failed: ${err}` : "Not checked yet."}><button className="btn" onClick={check} disabled={busy}>{busy ? <span className="spinner" /> : null}Check now</button>{info?.available && <button className="btn primary" onClick={async () => { if (await confirmBox("Apply update", "Neux will clear its program cache and reload to fetch the new files. Your data is kept.")) void applyWebUpdate(); }}>Update & reload</button>}</Setting>
    <p className="dim small">Web edition: updates are the files you deploy to GitHub Pages (see README). Integrity comes from HTTPS; the package signature chain is not implemented. Rollback: redeploy the previous release files. Native editions use platform installers.</p>
  </>;
}
function Extensions() {
  const en = useStore(settingsStore, (s) => s.extensionsEnabled);
  const [list, reload] = useFs(listExtensions, [], [] as Awaited<ReturnType<typeof listExtensions>>);
  const [msg, setMsg] = useState("");
  return <>
    <div className="row"><button className="btn primary" onClick={async () => { const p = await pickFile({ filter: "all", title: "Choose a .nxe extension" }); if (!p) return; try { const m = await installExtension(p[0]); setMsg(`Installed ${m.name}`); reload(); } catch (e) { setMsg((e as Error).message); } }}>Install .nxe…</button></div>
    {msg && <div role="status" className="small">{msg}</div>}
    {list.length === 0 && <p className="dim">No extensions installed.</p>}
    {list.map((m) => <Setting key={m.id} title={`${m.name} ${m.version}`} desc={`${m.description ?? ""} Theme extension: ${Object.keys(m.vars).length} CSS variables. Mode: ${en[m.id] ? "Third-party (active)" : "Disabled"}.`}>
      <Switch label={`Enable ${m.name}`} checked={!!en[m.id]} onChange={async (v) => { setSetting("extensionsEnabled", { ...en, [m.id]: v }); await applyExtensions(); }} />
      <button className="btn sm danger" onClick={async () => { await removeExtension(m.id); reload(); }}>Remove</button></Setting>)}
    <p className="dim small">Implemented: validated .nxe packages that restyle Neux (theme variables only; no remote URLs). Not implemented yet: replacing Hotbar/Launcher/Explorer/Browser/Media components, scripted <code>extension.nxl</code> execution, third-party keyboards (need native IME integration). The default components cannot be disabled.</p>
  </>;
}
function System() {
  const [usage, setUsage] = useState(0);
  useEffect(() => { fs.usage().then(setUsage); }, []);
  return <>
    <Setting title="Setup Assistant" desc="Reopen the first-run wizard (region, language, network, shortcuts)."><button className="btn" onClick={() => setupStore.set({ open: true })}>Open</button></Setting>
    <Setting title="NeuxFS storage" desc={`${formatBytes(usage)} used in this browser profile`}><button className="btn" onClick={() => openApp("explorer", { path: "/" })}>Explorer</button><button className="btn" onClick={() => openApp("diagnostics")}>Diagnostics</button></Setting>
    <Setting title="Recovery & Backup" desc="Integrity check, repair, backup and restore."><button className="btn" onClick={() => openApp("recovery")}>Recovery</button><button className="btn" onClick={() => openApp("backup")}>Backup</button></Setting>
    <Setting title="Persistent storage" desc="Ask the browser not to evict NeuxFS under storage pressure."><button className="btn" onClick={async () => { const ok = await navigator.storage?.persist?.(); notify({ title: "Persistent storage", message: ok ? "Granted" : "Not granted by the browser" }); }}>Request</button></Setting>
  </>;
}
function About() {
  const p = detectPlatform(); const [step, setStep] = useState(0); const [ack, setAck] = useState(false); const [log, setLog] = useState<string[]>([]);
  const run = async () => {
    setStep(3);
    try { await resetAllNeuxData((s) => setLog((l) => [...l, s])); setLog((l) => [...l, "Done. Restarting into first-run setup…"]); setTimeout(() => location.reload(), 900); }
    catch (e) { setLog((l) => [...l, "Error: " + (e as Error).message + " — the reset resumes automatically on next start."]); }
  };
  return <>
    <Setting title="Neux OS" desc={`Version ${NEUX_VERSION} · HAORÏK Laboratory · ${p.edition} edition`}><span className="badge warn">alpha</span></Setting>
    <Setting title="Host" desc={`${p.host} · ${navigator.hardwareConcurrency} CPU threads · ${p.standalone ? "installed (standalone)" : "running in a browser tab"}`}><span /></Setting>
    <Setting title="Diagnostics" desc="Real capability checks for this device."><button className="btn" onClick={() => openApp("diagnostics")}>Open</button></Setting>
    <div className="card col" style={{ borderColor: "var(--danger)", marginTop: 20 }}>
      <b style={{ color: "var(--danger)" }}>Reset All Settings</b>
      <div className="dim small">Despite its name this performs a <b>complete Neux wipe</b>: all files, apps, accounts, playlists, browser data, themes and settings stored inside Neux. Your host OS and files outside Neux are never touched.</div>
      <div><button className="btn danger" onClick={() => { setStep(1); setAck(false); setLog([]); }}>Reset All Settings…</button></div>
    </div>
    {step > 0 && <div className="modal-bg" role="presentation"><div className="modal glass col" role="alertdialog" aria-modal="true" aria-label="Erase all Neux data?" style={{ borderColor: "var(--danger)" }}>
      {step === 1 && <>
        <h3 style={{ margin: 0, color: "var(--danger)" }}>Erase all Neux data?</h3>
        <div>This action will permanently delete all files, applications, accounts, projects, settings, and other data stored inside Neux OS.</div>
        <div><b>This action cannot be undone.</b></div><div className="dim">Your host operating system and files outside Neux OS will not be affected.</div>
        <label className="row" style={{ alignItems: "flex-start" }}><input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} /><span>I understand that everything inside Neux OS will be permanently lost and that no backup is created automatically.</span></label>
        <div className="row" style={{ justifyContent: "space-between" }}><button className="btn" onClick={() => setStep(0)}>Cancel</button><button className="btn danger" disabled={!ack} onClick={() => setStep(2)}>Erase everything…</button></div></>}
      {step === 2 && <>
        <h3 style={{ margin: 0, color: "var(--danger)" }}>Final confirmation</h3>
        <div>Neux will stop all running apps, erase NeuxFS and all Neux-owned storage, and restart into first-run setup.</div>
        <div className="row" style={{ justifyContent: "space-between" }}><button className="btn" autoFocus onClick={() => setStep(0)}>No, keep my data</button><button className="btn danger" onClick={run}>Yes, erase all Neux data</button></div></>}
      {step === 3 && <><h3 style={{ margin: 0 }}>Erasing Neux data…</h3><div className="mono small" aria-live="polite">{log.map((l, i) => <div key={i}>{l}</div>)}</div></>}
    </div></div>}
    <span style={{ display: "none" }}><Tabs tabs={[]} value="" onChange={() => {}} />{alertBox.length}</span>
  </>;
}
