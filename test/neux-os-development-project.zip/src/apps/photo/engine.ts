/** Neux Photo pixel engine. Pure functions over RGBA buffers — no layers, no masks, no AI. */
export interface Img { data: Uint8ClampedArray; width: number; height: number }
export interface Params {
  exposure: number; brightness: number; contrast: number; saturation: number; vibrance: number; temperature: number; tint: number;
  highlights: number; shadows: number; whites: number; blacks: number; gamma: number; clarity: number; texture: number; sharpness: number; noise: number; dehaze: number;
  levels: { inB: number; inW: number; g: number };
  curves: { m: number[]; r: number[]; g: number[]; b: number[] };
  hsl: { h: number[]; s: number[]; l: number[] };
  balance: { sh: number[]; mid: number[]; hi: number[] };
  filter: string; filterAmount: number; vignette: number; grain: number; blur: number; motion: number; pixelate: number; overlayColor: string; overlayAmount: number;
}
export const CURVE_DEFAULT = [64, 128, 192];
export const defaultParams = (): Params => ({
  exposure: 0, brightness: 0, contrast: 0, saturation: 0, vibrance: 0, temperature: 0, tint: 0, highlights: 0, shadows: 0, whites: 0, blacks: 0, gamma: 1, clarity: 0, texture: 0, sharpness: 0, noise: 0, dehaze: 0,
  levels: { inB: 0, inW: 255, g: 1 }, curves: { m: [...CURVE_DEFAULT], r: [...CURVE_DEFAULT], g: [...CURVE_DEFAULT], b: [...CURVE_DEFAULT] },
  hsl: { h: Array(8).fill(0), s: Array(8).fill(0), l: Array(8).fill(0) }, balance: { sh: [0, 0, 0], mid: [0, 0, 0], hi: [0, 0, 0] },
  filter: "none", filterAmount: 1, vignette: 0, grain: 0, blur: 0, motion: 0, pixelate: 0, overlayColor: "#ff7a00", overlayAmount: 0,
});
export const HSL_BANDS = ["Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta"];
const BAND_H = [0, 30, 60, 120, 180, 240, 270, 300];
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smooth = (a: number, b: number, x: number) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

export function curveLut(pts: number[]): Uint8Array {
  const xs = [0, 64, 128, 192, 255], ys = [0, ...pts, 255]; const lut = new Uint8Array(256);
  for (let i = 0; i < 256; i++) { let k = 0; while (k < 3 && i > xs[k + 1]) k++; const t = (i - xs[k]) / (xs[k + 1] - xs[k]); const s = t * t * (3 - 2 * t) * 0.6 + t * 0.4; lut[i] = Math.max(0, Math.min(255, Math.round(ys[k] + (ys[k + 1] - ys[k]) * s))); }
  return lut;
}
function rgb2hsl(r: number, g: number, b: number): [number, number, number] {
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; if (mx === mn) return [0, 0, l];
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); let h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return [h * 60, s, l];
}
function hsl2rgb(h: number, s: number, l: number): [number, number, number] {
  h = ((h % 360) + 360) % 360; if (!s) return [l, l, l]; const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = (t: number) => { t = (t + 360) % 360 / 360; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 0.5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return [f(h + 120), f(h), f(h - 120)];
}
export function boxBlur(src: Uint8ClampedArray, w: number, h: number, r: number): Uint8ClampedArray {
  r = Math.round(r); if (r < 1) return new Uint8ClampedArray(src);
  const tmp = new Float32Array(src.length), out = new Uint8ClampedArray(src.length), n = 2 * r + 1;
  for (let y = 0; y < h; y++) for (let c = 0; c < 3; c++) { let sum = 0; for (let x = -r; x <= r; x++) sum += src[(y * w + Math.min(w - 1, Math.max(0, x))) * 4 + c]; for (let x = 0; x < w; x++) { tmp[(y * w + x) * 4 + c] = sum / n; sum += src[(y * w + Math.min(w - 1, x + r + 1)) * 4 + c] - src[(y * w + Math.max(0, x - r)) * 4 + c]; } }
  for (let x = 0; x < w; x++) for (let c = 0; c < 3; c++) { let sum = 0; for (let y = -r; y <= r; y++) sum += tmp[(Math.min(h - 1, Math.max(0, y)) * w + x) * 4 + c]; for (let y = 0; y < h; y++) { out[(y * w + x) * 4 + c] = sum / n; sum += tmp[(Math.min(h - 1, y + r + 1) * w + x) * 4 + c] - tmp[(Math.max(0, y - r) * w + x) * 4 + c]; } }
  for (let i = 3; i < src.length; i += 4) out[i] = src[i];
  return out;
}
function unsharp(img: Img, amount: number, radius: number) {
  if (!amount) return; const b = boxBlur(img.data, img.width, img.height, radius); const d = img.data;
  for (let i = 0; i < d.length; i += 4) for (let c = 0; c < 3; c++) d[i + c] = d[i + c] + (d[i + c] - b[i + c]) * amount;
}
const FILTERS: Record<string, (r: number, g: number, b: number) => [number, number, number]> = {
  bw: (r, g, b) => { const l = 0.299 * r + 0.587 * g + 0.114 * b; return [l, l, l]; },
  sepia: (r, g, b) => [0.393 * r + 0.769 * g + 0.189 * b, 0.349 * r + 0.686 * g + 0.168 * b, 0.272 * r + 0.534 * g + 0.131 * b],
  vintage: (r, g, b) => [r * 0.9 + g * 0.2 + 0.06, g * 0.85 + b * 0.1 + 0.04, b * 0.7 + 0.08],
  film: (r, g, b) => { const f = (v: number) => v * v * (3 - 2 * v) * 0.8 + v * 0.2; return [f(r) * 1.04, f(g), f(b) * 0.94 + 0.02]; },
  warm: (r, g, b) => [r * 1.1 + 0.02, g * 1.02, b * 0.88], cool: (r, g, b) => [r * 0.9, g * 1.0, b * 1.12 + 0.02],
};
export const FILTER_NAMES = ["none", "bw", "sepia", "vintage", "film", "warm", "cool"];

/** Apply all adjustments to img in place and return it. `scale` = preview-size ratio (radius-based ops shrink with it). */
export function applyParams(img: Img, p: Params, scale = 1): Img {
  const d = img.data, w = img.width, h = img.height;
  const lut = { m: curveLut(p.curves.m), r: curveLut(p.curves.r), g: curveLut(p.curves.g), b: curveLut(p.curves.b) };
  const curved = [p.curves.m, p.curves.r, p.curves.g, p.curves.b].some((c) => c.some((v, i) => v !== CURVE_DEFAULT[i]));
  const hslOn = [...p.hsl.h, ...p.hsl.s, ...p.hsl.l].some((v) => v !== 0);
  const balOn = [...p.balance.sh, ...p.balance.mid, ...p.balance.hi].some((v) => v !== 0);
  const expo = Math.pow(2, p.exposure), cf = p.contrast >= 0 ? 1 + p.contrast * 1.5 : 1 + p.contrast, lv = p.levels, lvOn = lv.inB !== 0 || lv.inW !== 255 || lv.g !== 1;
  const wb = p.temperature, tn = p.tint, gm = 1 / p.gamma, dh = p.dehaze;
  const pre = p.noise > 0 ? boxBlur(d, w, h, 1) : null;
  if (pre) for (let i = 0; i < d.length; i += 4) for (let c = 0; c < 3; c++) d[i + c] = d[i + c] * (1 - p.noise * 0.8) + pre[i + c] * p.noise * 0.8;
  for (let i = 0; i < d.length; i += 4) {
    let r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255;
    if (wb || tn) { r *= 1 + wb * 0.3; b *= 1 - wb * 0.3; g *= 1 - tn * 0.2; r *= 1 + tn * 0.08; b *= 1 + tn * 0.08; }
    if (p.exposure) { r *= expo; g *= expo; b *= expo; }
    if (lvOn) { const s = (lv.inW - lv.inB) / 255 || 1 / 255, o = lv.inB / 255, ig = 1 / lv.g; r = Math.pow(clamp01((r - o) / s), ig); g = Math.pow(clamp01((g - o) / s), ig); b = Math.pow(clamp01((b - o) / s), ig); }
    if (p.gamma !== 1) { r = Math.pow(clamp01(r), gm); g = Math.pow(clamp01(g), gm); b = Math.pow(clamp01(b), gm); }
    if (p.brightness) { r += p.brightness * 0.5; g += p.brightness * 0.5; b += p.brightness * 0.5; }
    if (p.contrast) { r = (r - 0.5) * cf + 0.5; g = (g - 0.5) * cf + 0.5; b = (b - 0.5) * cf + 0.5; }
    if (p.highlights || p.shadows || p.whites || p.blacks) {
      const L = clamp01(0.299 * r + 0.587 * g + 0.114 * b);
      const add = p.shadows * (1 - L) * (1 - L) * 0.5 + p.highlights * L * L * 0.5 + p.whites * smooth(0.6, 1, L) * 0.4 + p.blacks * (1 - smooth(0, 0.4, L)) * 0.4;
      r += add; g += add; b += add;
    }
    if (dh) { const k = dh * 0.12; r = (r - k) / (1 - k); g = (g - k) / (1 - k); b = (b - k) / (1 - k); }
    if (balOn) { const L = clamp01(0.299 * r + 0.587 * g + 0.114 * b), ws = 1 - smooth(0, 0.5, L), wh = smooth(0.5, 1, L), wm = 1 - ws - wh; for (let c = 0; c < 3; c++) { const o = (p.balance.sh[c] * ws + p.balance.mid[c] * wm + p.balance.hi[c] * wh) * 0.3; if (c === 0) r += o; else if (c === 1) g += o; else b += o; } }
    r = clamp01(r); g = clamp01(g); b = clamp01(b);
    if (hslOn || p.saturation || p.vibrance) {
      let [hh, ss, ll] = rgb2hsl(r, g, b);
      if (hslOn) { let dh2 = 0, ds = 0, dl = 0; for (let k = 0; k < 8; k++) { let dist = Math.abs(hh - BAND_H[k]); if (dist > 180) dist = 360 - dist; const wgt = Math.max(0, 1 - dist / 40) * Math.min(1, ss * 4); if (wgt) { dh2 += p.hsl.h[k] * 30 * wgt; ds += p.hsl.s[k] * wgt; dl += p.hsl.l[k] * 0.3 * wgt; } } hh += dh2; ss = clamp01(ss * (1 + ds)); ll = clamp01(ll + dl); }
      if (p.saturation) ss = clamp01(ss * (1 + p.saturation));
      if (p.vibrance) ss = clamp01(ss + p.vibrance * (1 - ss) * ss * 2);
      [r, g, b] = hsl2rgb(hh, ss, ll);
    }
    let R = Math.round(r * 255), G = Math.round(g * 255), B = Math.round(b * 255);
    if (curved) { R = lut.r[lut.m[R]]; G = lut.g[lut.m[G]]; B = lut.b[lut.m[B]]; }
    d[i] = R; d[i + 1] = G; d[i + 2] = B;
  }
  const sc = Math.max(0.15, scale);
  unsharp(img, p.clarity * 1.2, 12 * sc); unsharp(img, p.texture * 1.0, 3 * sc); unsharp(img, p.sharpness * 1.5, Math.max(1, 1.2 * sc));
  if (p.filter !== "none" && FILTERS[p.filter]) { const f = FILTERS[p.filter], a = p.filterAmount; for (let i = 0; i < d.length; i += 4) { const [r, g, b] = f(d[i] / 255, d[i + 1] / 255, d[i + 2] / 255); d[i] = (d[i] * (1 - a) + clamp01(r) * 255 * a); d[i + 1] = (d[i + 1] * (1 - a) + clamp01(g) * 255 * a); d[i + 2] = (d[i + 2] * (1 - a) + clamp01(b) * 255 * a); } }
  if (p.blur > 0) { let b = d; const r = Math.max(1, p.blur * 0.5 * sc); for (let k = 0; k < 3; k++) b = boxBlur(b, w, h, r); d.set(b); }
  if (p.motion > 0) { const len = Math.max(1, Math.round(p.motion * sc)); const src = new Uint8ClampedArray(d); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let r = 0, g = 0, b = 0; for (let k = 0; k < len; k++) { const xx = Math.min(w - 1, x + k), j = (y * w + xx) * 4; r += src[j]; g += src[j + 1]; b += src[j + 2]; } const o = (y * w + x) * 4; d[o] = r / len; d[o + 1] = g / len; d[o + 2] = b / len; } }
  if (p.pixelate > 1) { const s = Math.max(2, Math.round(p.pixelate * sc)); for (let y = 0; y < h; y += s) for (let x = 0; x < w; x += s) { let r = 0, g = 0, b = 0, n = 0; for (let yy = y; yy < Math.min(h, y + s); yy++) for (let xx = x; xx < Math.min(w, x + s); xx++) { const j = (yy * w + xx) * 4; r += d[j]; g += d[j + 1]; b += d[j + 2]; n++; } for (let yy = y; yy < Math.min(h, y + s); yy++) for (let xx = x; xx < Math.min(w, x + s); xx++) { const j = (yy * w + xx) * 4; d[j] = r / n; d[j + 1] = g / n; d[j + 2] = b / n; } } }
  if (p.overlayAmount > 0) { const c = parseInt(p.overlayColor.slice(1), 16), or = c >> 16, og = (c >> 8) & 255, ob = c & 255, a = p.overlayAmount; for (let i = 0; i < d.length; i += 4) { d[i] = d[i] * (1 - a) + or * a; d[i + 1] = d[i + 1] * (1 - a) + og * a; d[i + 2] = d[i + 2] * (1 - a) + ob * a; } }
  if (p.vignette) { const cx = w / 2, cy = h / 2, md = Math.hypot(cx, cy); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const t = Math.hypot(x - cx, y - cy) / md; const f = 1 - p.vignette * smooth(0.35, 1.05, t) * (p.vignette > 0 ? 0.9 : -0.9 * -1); const j = (y * w + x) * 4; const m = p.vignette > 0 ? f : 1 + -p.vignette * smooth(0.35, 1.05, t); d[j] *= m; d[j + 1] *= m; d[j + 2] *= m; } }
  if (p.grain > 0) { let s = 1337; for (let i = 0; i < d.length; i += 4) { s = (s * 1664525 + 1013904223) >>> 0; const n = ((s >>> 8) / 16777216 - 0.5) * p.grain * 90; d[i] += n; d[i + 1] += n; d[i + 2] += n; } }
  return img;
}
export function histogram(img: Img): { r: number[]; g: number[]; b: number[]; l: number[] } {
  const r = Array(256).fill(0), g = Array(256).fill(0), b = Array(256).fill(0), l = Array(256).fill(0);
  for (let i = 0; i < img.data.length; i += 4) { r[img.data[i]]++; g[img.data[i + 1]]++; b[img.data[i + 2]]++; l[Math.round(0.299 * img.data[i] + 0.587 * img.data[i + 1] + 0.114 * img.data[i + 2])]++; }
  return { r, g, b, l };
}
/** Minimal uncompressed baseline TIFF (RGBA, 8-bit, sRGB assumed). */
export function encodeTiff(img: Img): Uint8Array {
  const { width: w, height: h, data } = img; const entries = 12, ifdOff = 8, ifdLen = 2 + entries * 12 + 4, bpsOff = ifdOff + ifdLen, dataOff = bpsOff + 8 + 8; // bits per sample (4×short) + 8 spare
  const out = new Uint8Array(dataOff + data.length); const dv = new DataView(out.buffer);
  out[0] = 0x49; out[1] = 0x49; dv.setUint16(2, 42, true); dv.setUint32(4, ifdOff, true); dv.setUint16(ifdOff, entries, true);
  let o = ifdOff + 2; const E = (tag: number, type: number, count: number, val: number) => { dv.setUint16(o, tag, true); dv.setUint16(o + 2, type, true); dv.setUint32(o + 4, count, true); if (type === 3 && count === 1) dv.setUint16(o + 8, val, true); else dv.setUint32(o + 8, val, true); o += 12; };
  E(256, 4, 1, w); E(257, 4, 1, h); E(258, 3, 4, bpsOff); E(259, 3, 1, 1); E(262, 3, 1, 2); E(273, 4, 1, dataOff); E(277, 3, 1, 4); E(278, 4, 1, h); E(279, 4, 1, data.length); E(282, 5, 1, bpsOff + 8); E(284, 3, 1, 1); E(338, 3, 1, 2);
  for (let i = 0; i < 4; i++) dv.setUint16(bpsOff + i * 2, 8, true); dv.setUint32(bpsOff + 8, 72, true); dv.setUint32(bpsOff + 12, 1, true);
  out.set(data, dataOff); return out;
}
