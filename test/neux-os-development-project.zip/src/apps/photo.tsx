"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { useWin, useShortcut, downloadBlob, Tabs } from "@/shell/ui";
import { applyParams, defaultParams, histogram, encodeTiff, boxBlur, FILTER_NAMES, HSL_BANDS, type Params } from "./photo/engine";
import { pickFile, notify, alertBox, confirmBox, promptBox, closeWin, setCloseGuard, setTitle } from "@/core/os";
import { basename, join } from "@/core/filesystem/neuxfs";

type Tool = "pan" | "select" | "crop" | "brush" | "eraser" | "clone" | "heal" | "spot" | "blur" | "sharpen" | "dodge" | "burn" | "picker" | "text" | "shape" | "graphic";
type Sel = { kind: "rect" | "ellipse"; x: number; y: number; w: number; h: number } | null;
interface Snap { canvas: HTMLCanvasElement; params: Params }
const DIR = "/Users/Default/Pictures/Neux Photo Projects", EXPORTS = "/Users/Default/Pictures/Exports", AUTOSAVE = DIR + "/.autosave.wrphoto";
const clone = (c: HTMLCanvasElement) => { const n = document.createElement("canvas"); n.width = c.width; n.height = c.height; n.getContext("2d")!.drawImage(c, 0, 0); return n; };
const mkCanvas = (w: number, h: number) => { const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
const toB64 = (u: Uint8Array) => { let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const RATIOS: Record<string, number | null> = { Free: null, "1:1": 1, "4:3": 4 / 3, "3:2": 3 / 2, "16:9": 16 / 9, "9:16": 9 / 16, "3:4": 3 / 4, "2:3": 2 / 3 };

function Slider({ label, v, min, max, step = 0.01, set, commit, fmt }: { label: string; v: number; min: number; max: number; step?: number; set: (n: number) => void; commit: () => void; fmt?: (n: number) => string }) {
  return <label className="row small" style={{ gap: 6 }}><span style={{ width: 86 }}>{label}</span><input type="range" className="range" min={min} max={max} step={step} value={v} onChange={(e) => set(Number(e.target.value))} onPointerUp={commit} onKeyUp={commit} onDoubleClick={() => { set(label === "Gamma" ? 1 : 0); setTimeout(commit, 0); }} aria-label={label} /><span style={{ width: 40, textAlign: "right" }} className="dim">{fmt ? fmt(v) : Math.round(v * 100) / 100}</span></label>;
}

export default function Photo() {
  const win = useWin();
  const base = useRef<HTMLCanvasElement | null>(null); const original = useRef<{ canvas: HTMLCanvasElement; bytes: Uint8Array; mime: string; name: string } | null>(null);
  const view = useRef<HTMLCanvasElement>(null); const histCv = useRef<HTMLCanvasElement>(null); const box = useRef<HTMLDivElement>(null);
  const [params, setParams] = useState<Params>(defaultParams()); const paramsRef = useRef(params); paramsRef.current = params;
  const hist = useRef<Snap[]>([]); const hi = useRef(-1); const [, force] = useState(0); const rerender = () => force((n) => n + 1);
  const [loaded, setLoaded] = useState(false); const [tool, setTool] = useState<Tool>("pan"); const [zoom, setZoom] = useState(1); const [tab, setTab] = useState("light"); const [panels, setPanels] = useState(true); const [viewMode, setViewMode] = useState(false);
  const [compare, setCompare] = useState(false); const [dirty, setDirty] = useState(false); const [projectPath, setProjectPath] = useState<string | null>(null); const [msg, setMsg] = useState("");
  const [brush, setBrush] = useState({ size: 30, hardness: 0.6, opacity: 1, color: "#e0457b", strength: 0.5 }); const brushRef = useRef(brush); brushRef.current = brush;
  const [sel, setSel] = useState<Sel>(null); const selRef = useRef<Sel>(null); selRef.current = sel; const [selKind, setSelKind] = useState<"rect" | "ellipse">("rect");
  const [crop, setCrop] = useState<{ x: number; y: number; w: number; h: number } | null>(null); const [ratio, setRatio] = useState("Free");
  const [text, setText] = useState({ s: "Neux Photo", font: "sans-serif", size: 64, weight: 700, color: "#ffffff", align: "center" as CanvasTextAlign, rot: 0 });
  const [shape, setShape] = useState({ kind: "rect" as "rect" | "ellipse" | "line" | "arrow", color: "#ff3b5c", width: 6, fill: false }); const [graphic, setGraphic] = useState<{ bmp: ImageBitmap; scale: number } | null>(null);
  const [geo, setGeo] = useState({ angle: 0, w: 0, h: 0, lock: true, pad: 50, padColor: "#ffffff", keyV: 0, keyH: 0, dpi: 72 });
  const [exp, setExp] = useState({ fmt: "image/png", quality: 0.92, scale: 100, bg: "#ffffff" }); const [presets, setPresets] = useState<Record<string, Partial<Params>>>({});
  const [picked, setPicked] = useState(""); const drag = useRef<{ x0: number; y0: number; x: number; y: number; last?: { x: number; y: number }; off?: { x: number; y: number }; drawing?: boolean; sx?: number; sy?: number } | null>(null);
  const cloneSrc = useRef<{ x: number; y: number } | null>(null); const [dragShape, setDragShape] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const spaceDown = useRef(false); const raf = useRef(0);

  const render = useCallback(() => {
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(() => {
      const b = base.current, v = view.current; if (!b || !v) return;
      const src = compare && original.current ? original.current.canvas : b;
      const maxS = 1500, sc = Math.min(1, maxS / Math.max(src.width, src.height)); const w = Math.max(1, Math.round(src.width * sc)), h = Math.max(1, Math.round(src.height * sc));
      v.width = w; v.height = h; const ctx = v.getContext("2d", { willReadFrequently: true })!; ctx.drawImage(src, 0, 0, w, h);
      const id = ctx.getImageData(0, 0, w, h);
      if (!compare) applyParams(id, paramsRef.current, sc);
      ctx.putImageData(id, 0, 0);
      const hc = histCv.current; if (hc) { const hg = histogram(id), x = hc.getContext("2d")!; x.clearRect(0, 0, 256, 80); const mx = Math.max(...hg.l.slice(2, 254), 1); for (const [k, col] of [["r", "rgba(255,70,70,.6)"], ["g", "rgba(70,220,100,.6)"], ["b", "rgba(80,120,255,.6)"]] as const) { x.fillStyle = col; hg[k].forEach((n, i) => x.fillRect(i, 80 - Math.min(80, (n / mx) * 80), 1, 80)); } }
    });
  }, [compare]);
  useEffect(() => { render(); }, [params, compare, render, loaded]);

  const fit = useCallback(() => { const b = base.current, c = box.current; if (!b || !c) return; setZoom(Math.min(1, (c.clientWidth - 30) / b.width, (c.clientHeight - 30) / b.height)); }, []);
  const snapshot = (label?: string) => { const b = base.current; if (!b) return; hist.current = hist.current.slice(0, hi.current + 1); hist.current.push({ canvas: clone(b), params: JSON.parse(JSON.stringify(paramsRef.current)) }); if (hist.current.length > 25) hist.current.shift(); hi.current = hist.current.length - 1; setDirty(true); void label; rerender(); };
  const restore = (i: number) => { const s = hist.current[i]; if (!s) return; base.current = clone(s.canvas); hi.current = i; setParams(JSON.parse(JSON.stringify(s.params))); setDirty(true); render(); rerender(); };
  const undo = () => restore(hi.current - 1), redo = () => restore(hi.current + 1);
  const replaceBase = (c: HTMLCanvasElement) => { base.current = c; setSel(null); setCrop(null); snapshot(); setTimeout(fit, 0); render(); };
  const set = <K extends keyof Params>(k: K, v: Params[K]) => setParams((p) => ({ ...p, [k]: v }));
  const num = (k: keyof Params, label: string, min = -1, max = 1, step = 0.01) => <Slider key={k} label={label} v={params[k] as number} min={min} max={max} step={step} set={(n) => set(k, n as never)} commit={() => snapshot()} />;

  const loadBlob = useCallback(async (blob: Blob, name: string, bytes?: Uint8Array) => {
    try { const bmp = await createImageBitmap(blob); const c = mkCanvas(bmp.width, bmp.height); c.getContext("2d")!.drawImage(bmp, 0, 0); base.current = c; original.current = { canvas: clone(c), bytes: bytes ?? new Uint8Array(await blob.arrayBuffer()), mime: blob.type, name };
      hist.current = []; hi.current = -1; setParams(defaultParams()); paramsRef.current = defaultParams(); setSel(null); setCrop(null); snapshot(); setDirty(false); setLoaded(true); setGeo((g) => ({ ...g, w: c.width, h: c.height })); setMsg(""); setTimeout(fit, 30); }
    catch { setMsg(`Cannot decode “${name}” in this browser (${blob.type || "unknown type"}). Supported: whatever your browser decodes — typically JPG, PNG, WebP, AVIF, BMP, GIF (first frame). TIFF and RAW are not decodable here.`); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fit]);
  const openPath = useCallback(async (path: string) => {
    if (path.endsWith(".wrphoto")) { try { const j = JSON.parse(await fs.readText(path)); if (j.format !== "wrphoto/1") throw new Error("Unsupported project format"); const b = await (await fetch(j.base)).blob(); await loadBlob(b, j.name); if (j.original) original.current = { canvas: (await (async () => { const ob = await createImageBitmap(new Blob([fromB64(j.original)], { type: j.originalMime })); const c = mkCanvas(ob.width, ob.height); c.getContext("2d")!.drawImage(ob, 0, 0); return c; })()), bytes: fromB64(j.original), mime: j.originalMime, name: j.name }; setParams(j.params); paramsRef.current = j.params; hist.current = []; hi.current = -1; snapshot(); setDirty(false); setProjectPath(path); } catch (e) { setMsg("Cannot open project: " + (e as Error).message); } return; }
    const n = await fs.stat(path); await loadBlob(n.data!, n.name); setProjectPath(null); setTitle(win.id, "Neux Photo — " + n.name);
  }, [loadBlob, win.id]);
  const openDlg = async () => { const p = await pickFile({ filter: "image", title: "Open image or .wrphoto project", startPath: "/Users/Default/Pictures" }); if (p) await openPath(p[0]); };
  useEffect(() => { const p = win.params.path as string | undefined; if (p) void openPath(p); else fs.exists(AUTOSAVE).then(async (e) => { if (e && await confirmBox("Recover unsaved work?", "Neux Photo found an autosaved project from an earlier session (possibly a crash). Recover it?", false, "Recover")) void openPath(AUTOSAVE); }); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  useEffect(() => { fs.json<Record<string, Partial<Params>>>(DIR + "/presets.json", {}).then(setPresets); }, []);
  useEffect(() => { setCloseGuard(win.id, () => !dirty || confirm("You have unsaved changes in Neux Photo. Close anyway?")); return () => setCloseGuard(win.id, null); }, [dirty, win.id]);
  const saveProject = useCallback(async (auto = false, as = false) => {
    if (!base.current || !original.current) return;
    let path = auto ? AUTOSAVE : projectPath;
    if (!path || (as && !auto)) { const p = await pickFile({ mode: "save", title: "Save Neux Photo project", startPath: DIR, defaultName: original.current.name.replace(/\.[^.]+$/, "") + ".wrphoto" }); if (!p) return; path = p[0].endsWith(".wrphoto") ? p[0] : p[0] + ".wrphoto"; }
    const o = original.current;
    const proj = { format: "wrphoto/1", name: o.name, savedAt: new Date().toISOString(), size: [base.current.width, base.current.height], params: paramsRef.current, base: base.current.toDataURL("image/png"), originalMime: o.mime, original: toB64(o.bytes) };
    await fs.writeFile(path, JSON.stringify(proj), { mime: "application/json", role: auto ? "user" : "user" });
    if (!auto) { setProjectPath(path); setDirty(false); notify({ title: "Project saved", message: basename(path) }); }
  }, [projectPath]);
  useEffect(() => { const t = setInterval(() => { if (dirty && base.current) void saveProject(true); }, 20000); return () => clearInterval(t); }, [dirty, saveProject]);

  // ---------- shortcuts ----------
  useShortcut("photo.open", openDlg, []); useShortcut("photo.save", () => void saveProject(), [saveProject]); useShortcut("photo.export", () => setTab("export"), []);
  useShortcut("photo.undo", () => undo(), []); useShortcut("photo.redo", () => redo(), []);
  useShortcut("photo.zoomIn", () => setZoom((z) => Math.min(8, z * 1.25)), []); useShortcut("photo.zoomOut", () => setZoom((z) => Math.max(0.05, z / 1.25)), []); useShortcut("photo.fit", fit, [fit]);
  useShortcut("photo.view", () => { setViewMode((v) => !v); setTimeout(fit, 30); }, [fit]);
  useShortcut("photo.brushDown", () => setBrush((b) => ({ ...b, size: Math.max(2, b.size - 5) })), []); useShortcut("photo.brushUp", () => setBrush((b) => ({ ...b, size: Math.min(400, b.size + 5) })), []);
  useShortcut("photo.panels", () => setPanels((p) => !p), []);
  useEffect(() => { const d = (e: KeyboardEvent) => { if (e.code === "Space" && win.focused && (e.target as HTMLElement).tagName !== "INPUT" && (e.target as HTMLElement).tagName !== "TEXTAREA") { spaceDown.current = true; e.preventDefault(); } }; const u = (e: KeyboardEvent) => { if (e.code === "Space") spaceDown.current = false; }; window.addEventListener("keydown", d); window.addEventListener("keyup", u); return () => { window.removeEventListener("keydown", d); window.removeEventListener("keyup", u); }; }, [win.focused]);

  // ---------- pointer tools ----------
  const toBase = (e: React.PointerEvent) => { const r = view.current!.getBoundingClientRect(); return { x: ((e.clientX - r.left) / r.width) * base.current!.width, y: ((e.clientY - r.top) / r.height) * base.current!.height }; };
  const inSel = (x: number, y: number) => { const s = selRef.current; if (!s) return true; if (s.kind === "rect") return x >= s.x && x <= s.x + s.w && y >= s.y && y <= s.y + s.h; const rx = s.w / 2, ry = s.h / 2; return ((x - s.x - rx) / rx) ** 2 + ((y - s.y - ry) / ry) ** 2 <= 1; };
  const clipSel = (ctx: CanvasRenderingContext2D) => { const s = selRef.current; if (!s) return; ctx.beginPath(); if (s.kind === "rect") ctx.rect(s.x, s.y, s.w, s.h); else ctx.ellipse(s.x + s.w / 2, s.y + s.h / 2, s.w / 2, s.h / 2, 0, 0, Math.PI * 2); ctx.clip(); };
  const stamp = (x: number, y: number, off?: { x: number; y: number }) => {
    const b = base.current!, ctx = b.getContext("2d", { willReadFrequently: true })!, br = brushRef.current, r = br.size / 2; const t = tool;
    ctx.save(); clipSel(ctx);
    if (t === "brush" || t === "eraser") { const g = ctx.createRadialGradient(x, y, r * br.hardness, x, y, r); const col = t === "eraser" ? "0,0,0" : [1, 3, 5].map((i) => parseInt(br.color.slice(i, i + 2), 16)).join(","); g.addColorStop(0, `rgba(${col},${br.opacity})`); g.addColorStop(1, `rgba(${col},0)`); ctx.globalCompositeOperation = t === "eraser" ? "destination-out" : "source-over"; ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }
    else {
      const x0 = Math.max(0, Math.floor(x - r)), y0 = Math.max(0, Math.floor(y - r)), w = Math.min(b.width - x0, Math.ceil(r * 2)), h = Math.min(b.height - y0, Math.ceil(r * 2)); if (w < 1 || h < 1) { ctx.restore(); return; }
      const id = ctx.getImageData(x0, y0, w, h), d = id.data; const wt = (px: number, py: number) => { const dd = Math.hypot(px + x0 - x, py + y0 - y) / r; return dd >= 1 ? 0 : (dd < br.hardness ? 1 : 1 - (dd - br.hardness) / (1 - br.hardness + 1e-6)) * br.strength; };
      if (t === "blur" || t === "sharpen") { const bl = boxBlur(d, w, h, 2); for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) { const k = wt(px, py); if (!k) continue; const i = (py * w + px) * 4; for (let c = 0; c < 3; c++) d[i + c] = t === "blur" ? d[i + c] * (1 - k) + bl[i + c] * k : d[i + c] + (d[i + c] - bl[i + c]) * k * 2; } }
      else if (t === "dodge" || t === "burn") { for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) { const k = wt(px, py) * 0.25; if (!k) continue; const i = (py * w + px) * 4; for (let c = 0; c < 3; c++) d[i + c] = t === "dodge" ? d[i + c] + (255 - d[i + c]) * k : d[i + c] * (1 - k); } }
      else if (t === "spot") { let rr = 0, gg = 0, bb = 0, n = 0; for (let a = 0; a < 48; a++) { const an = (a / 48) * Math.PI * 2, px = Math.round(x + Math.cos(an) * r * 1.4), py = Math.round(y + Math.sin(an) * r * 1.4); if (px >= 0 && py >= 0 && px < b.width && py < b.height) { const p = ctx.getImageData(px, py, 1, 1).data; rr += p[0]; gg += p[1]; bb += p[2]; n++; } } if (n) for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) { const k = wt(px, py) / Math.max(br.strength, 0.01) * 0.95; if (!k) continue; const i = (py * w + px) * 4; d[i] = d[i] * (1 - k) + (rr / n) * k; d[i + 1] = d[i + 1] * (1 - k) + (gg / n) * k; d[i + 2] = d[i + 2] * (1 - k) + (bb / n) * k; } }
      else if ((t === "clone" || t === "heal") && off) { const sx = Math.round(x0 + off.x), sy = Math.round(y0 + off.y); if (sx >= 0 && sy >= 0 && sx + w <= b.width && sy + h <= b.height) { const sid = ctx.getImageData(sx, sy, w, h).data; let dm = [0, 0, 0], sm = [0, 0, 0], n = 0; if (t === "heal") for (let i = 0; i < d.length; i += 16) { for (let c = 0; c < 3; c++) { dm[c] += d[i + c]; sm[c] += sid[i + c]; } n++; } for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) { const k = wt(px, py) / Math.max(br.strength, 0.01) * br.opacity; if (!k) continue; const i = (py * w + px) * 4; for (let c = 0; c < 3; c++) { const s = sid[i + c] + (t === "heal" && n ? (dm[c] - sm[c]) / n : 0); d[i + c] = d[i + c] * (1 - k) + s * k; } } } }
      ctx.putImageData(id, x0, y0);
    }
    ctx.restore();
  };
  const down = (e: React.PointerEvent) => {
    if (!base.current) return; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); const p = toBase(e);
    if (tool === "pan" || spaceDown.current) { drag.current = { x0: e.clientX, y0: e.clientY, x: box.current!.scrollLeft, y: box.current!.scrollTop, drawing: false, sx: 1 }; return; }
    drag.current = { x0: p.x, y0: p.y, x: p.x, y: p.y, drawing: true };
    if (tool === "picker") { const d = view.current!.getContext("2d")!; const vx = (p.x / base.current.width) * view.current!.width, vy = (p.y / base.current.height) * view.current!.height; const px = d.getImageData(Math.floor(vx), Math.floor(vy), 1, 1).data; const hex = "#" + [px[0], px[1], px[2]].map((v) => v.toString(16).padStart(2, "0")).join(""); setPicked(hex); setBrush((b) => ({ ...b, color: hex })); text && setText((t) => ({ ...t, color: hex })); drag.current = null; return; }
    if (tool === "clone" || tool === "heal") { if (e.altKey || !cloneSrc.current) { cloneSrc.current = p; setMsg(`Clone source set at ${Math.round(p.x)}, ${Math.round(p.y)}. Now paint elsewhere (Alt+click to change source).`); drag.current = null; return; } drag.current.off = { x: cloneSrc.current.x - p.x, y: cloneSrc.current.y - p.y }; }
    if (["brush", "eraser", "clone", "heal", "blur", "sharpen", "dodge", "burn", "spot"].includes(tool)) { if (inSel(p.x, p.y)) stamp(p.x, p.y, drag.current.off); drag.current.last = p; render(); }
    if (tool === "text") { const b = base.current, ctx = b.getContext("2d")!; ctx.save(); clipSel(ctx); ctx.translate(p.x, p.y); ctx.rotate((text.rot * Math.PI) / 180); ctx.font = `${text.weight} ${text.size}px ${text.font}`; ctx.fillStyle = text.color; ctx.textAlign = text.align; ctx.textBaseline = "middle"; text.s.split("\n").forEach((l, i) => ctx.fillText(l, 0, i * text.size * 1.2)); ctx.restore(); snapshot(); render(); drag.current = null; }
    if (tool === "graphic" && graphic) { const b = base.current, ctx = b.getContext("2d")!; const w = graphic.bmp.width * graphic.scale, h = graphic.bmp.height * graphic.scale; ctx.drawImage(graphic.bmp, p.x - w / 2, p.y - h / 2, w, h); snapshot(); render(); drag.current = null; }
    if (tool === "shape") setDragShape({ x0: p.x, y0: p.y, x1: p.x, y1: p.y });
    if (tool === "select") setSel({ kind: selKind, x: p.x, y: p.y, w: 0, h: 0 });
    if (tool === "crop") setCrop({ x: p.x, y: p.y, w: 0, h: 0 });
  };
  const move = (e: React.PointerEvent) => {
    const d = drag.current; if (!d || !base.current) return;
    if (!d.drawing) { box.current!.scrollLeft = d.x - (e.clientX - d.x0); box.current!.scrollTop = d.y - (e.clientY - d.y0); return; }
    const p = toBase(e);
    if (d.last && tool !== "spot") { const dist = Math.hypot(p.x - d.last.x, p.y - d.last.y), step = Math.max(1, brushRef.current.size * 0.2); for (let t = step; t <= dist; t += step) { const q = { x: d.last.x + ((p.x - d.last.x) * t) / dist, y: d.last.y + ((p.y - d.last.y) * t) / dist }; if (inSel(q.x, q.y)) stamp(q.x, q.y, d.off); } d.last = p; render(); }
    if (tool === "shape") setDragShape({ x0: d.x0, y0: d.y0, x1: p.x, y1: p.y });
    if (tool === "select") setSel({ kind: selKind, x: Math.min(d.x0, p.x), y: Math.min(d.y0, p.y), w: Math.abs(p.x - d.x0), h: Math.abs(p.y - d.y0) });
    if (tool === "crop") { let w = p.x - d.x0, h = p.y - d.y0; const r = RATIOS[ratio]; if (r) h = Math.sign(h || 1) * Math.abs(w) / r; setCrop({ x: Math.min(d.x0, d.x0 + w), y: Math.min(d.y0, d.y0 + h), w: Math.abs(w), h: Math.abs(h) }); }
  };
  const up = () => {
    const d = drag.current; drag.current = null; if (!d?.drawing) return;
    if (["brush", "eraser", "clone", "heal", "blur", "sharpen", "dodge", "burn", "spot"].includes(tool)) snapshot();
    if (tool === "shape" && dragShape) { const b = base.current!, ctx = b.getContext("2d")!, s = dragShape; ctx.save(); clipSel(ctx); ctx.strokeStyle = ctx.fillStyle = shape.color; ctx.lineWidth = shape.width; ctx.lineCap = "round";
      const x = Math.min(s.x0, s.x1), y = Math.min(s.y0, s.y1), w = Math.abs(s.x1 - s.x0), h = Math.abs(s.y1 - s.y0);
      if (shape.kind === "rect") shape.fill ? ctx.fillRect(x, y, w, h) : ctx.strokeRect(x, y, w, h); else if (shape.kind === "ellipse") { ctx.beginPath(); ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, 7); shape.fill ? ctx.fill() : ctx.stroke(); }
      else { ctx.beginPath(); ctx.moveTo(s.x0, s.y0); ctx.lineTo(s.x1, s.y1); ctx.stroke(); if (shape.kind === "arrow") { const a = Math.atan2(s.y1 - s.y0, s.x1 - s.x0), L = shape.width * 4; ctx.beginPath(); ctx.moveTo(s.x1, s.y1); ctx.lineTo(s.x1 - L * Math.cos(a - 0.45), s.y1 - L * Math.sin(a - 0.45)); ctx.lineTo(s.x1 - L * Math.cos(a + 0.45), s.y1 - L * Math.sin(a + 0.45)); ctx.closePath(); ctx.fill(); } }
      ctx.restore(); setDragShape(null); snapshot(); render(); }
    if (tool === "select" && selRef.current && selRef.current.w < 3) setSel(null);
  };

  // ---------- geometry ----------
  const transform = (w: number, h: number, fn: (ctx: CanvasRenderingContext2D) => void) => { const n = mkCanvas(w, h); const c = n.getContext("2d")!; fn(c); replaceBase(n); setGeo((g) => ({ ...g, w: n.width, h: n.height })); };
  const rot90 = (dir: 1 | -1) => { const b = base.current!; transform(b.height, b.width, (c) => { c.translate(b.height / 2, b.width / 2); c.rotate((dir * Math.PI) / 2); c.drawImage(b, -b.width / 2, -b.height / 2); }); };
  const flip = (hz: boolean) => { const b = base.current!; transform(b.width, b.height, (c) => { c.translate(hz ? b.width : 0, hz ? 0 : b.height); c.scale(hz ? -1 : 1, hz ? 1 : -1); c.drawImage(b, 0, 0); }); };
  const rotateAny = (deg: number, cropFit: boolean) => { const b = base.current!, a = (deg * Math.PI) / 180, s = Math.abs(Math.sin(a)), co = Math.abs(Math.cos(a)); let W = b.width * co + b.height * s, H = b.width * s + b.height * co;
    if (cropFit) { const long = Math.max(b.width, b.height), short = Math.min(b.width, b.height); let cw: number, ch: number; if (short <= 2 * s * co * long || Math.abs(s - co) < 1e-9) { const x = short / 2; cw = b.width >= b.height ? x / s : x / co; ch = b.width >= b.height ? x / co : x / s; } else { const cos2a = co * co - s * s; cw = (b.width * co - b.height * s) / cos2a; ch = (b.height * co - b.width * s) / cos2a; } W = Math.max(1, cw); H = Math.max(1, ch); }
    transform(W, H, (c) => { c.translate(W / 2, H / 2); c.rotate(a); c.drawImage(b, -b.width / 2, -b.height / 2); }); };
  const resize = () => { const b = base.current!; if (geo.w < 1 || geo.h < 1 || geo.w * geo.h > 120_000_000) return setMsg("Invalid size (max 120 MP)"); transform(geo.w, geo.h, (c) => { c.imageSmoothingQuality = "high"; c.drawImage(b, 0, 0, geo.w, geo.h); }); };
  const expand = () => { const b = base.current!, p = geo.pad; transform(b.width + p * 2, b.height + p * 2, (c) => { c.fillStyle = geo.padColor; c.fillRect(0, 0, b.width + p * 2, b.height + p * 2); c.drawImage(b, p, p); }); };
  const trim = () => { const b = base.current!, d = b.getContext("2d")!.getImageData(0, 0, b.width, b.height).data; const px = (x: number, y: number) => (y * b.width + x) * 4; const bg = [d[0], d[1], d[2], d[3]]; const same = (i: number) => Math.abs(d[i] - bg[0]) < 6 && Math.abs(d[i + 1] - bg[1]) < 6 && Math.abs(d[i + 2] - bg[2]) < 6 && Math.abs(d[i + 3] - bg[3]) < 6;
    let t = 0, bt = b.height - 1, l = 0, r = b.width - 1; const rowSame = (y: number) => { for (let x = 0; x < b.width; x++) if (!same(px(x, y))) return false; return true; }; const colSame = (x: number) => { for (let y = t; y <= bt; y++) if (!same(px(x, y))) return false; return true; };
    while (t < bt && rowSame(t)) t++; while (bt > t && rowSame(bt)) bt--; while (l < r && colSame(l)) l++; while (r > l && colSame(r)) r--; if (t === 0 && l === 0 && bt === b.height - 1 && r === b.width - 1) return setMsg("Nothing to trim: edges are not a uniform colour.");
    transform(r - l + 1, bt - t + 1, (c) => c.drawImage(b, -l, -t)); };
  const keystone = () => { const b = base.current!; transform(b.width, b.height, (c) => { for (let y = 0; y < b.height; y++) { const fy = y / b.height - 0.5, sx = 1 + geo.keyV * fy * 2, w = b.width * Math.max(0.2, sx); c.drawImage(b, 0, y, b.width, 1, (b.width - w) / 2, y, w, 1); } }); };
  const applyCrop = () => { const b = base.current!, c = crop; if (!c || c.w < 4 || c.h < 4) return; const x = Math.max(0, c.x), y = Math.max(0, c.y), w = Math.min(c.w, b.width - x), h = Math.min(c.h, b.height - y); transform(w, h, (ctx) => ctx.drawImage(b, -x, -y)); };
  const frame = () => { const b = base.current!, t = geo.pad; transform(b.width, b.height, (c) => { c.drawImage(b, 0, 0); c.strokeStyle = geo.padColor; c.lineWidth = t * 2; c.strokeRect(0, 0, b.width, b.height); }); };
  const bakeAdjust = () => { const b = base.current!, c = b.getContext("2d")!; const id = c.getImageData(0, 0, b.width, b.height); applyParams(id, paramsRef.current, 1); c.putImageData(id, 0, 0); setParams(defaultParams()); paramsRef.current = defaultParams(); snapshot(); render(); };

  const doExport = async (target: "neux" | "device") => {
    const b = base.current; if (!b) return; const sc = exp.scale / 100, w = Math.max(1, Math.round(b.width * sc)), h = Math.max(1, Math.round(b.height * sc)); if (w * h > 120_000_000) return setMsg("Export too large");
    const c = mkCanvas(w, h), ctx = c.getContext("2d", { willReadFrequently: true })!; if (exp.fmt === "image/jpeg") { ctx.fillStyle = exp.bg; ctx.fillRect(0, 0, w, h); } ctx.imageSmoothingQuality = "high"; ctx.drawImage(b, 0, 0, w, h);
    const id = ctx.getImageData(0, 0, w, h); applyParams(id, paramsRef.current, 1); ctx.putImageData(id, 0, 0);
    let blob: Blob | null; let ext: string;
    if (exp.fmt === "image/tiff") { blob = new Blob([encodeTiff(id) as BlobPart], { type: "image/tiff" }); ext = "tiff"; }
    else { blob = await new Promise<Blob | null>((r) => c.toBlob(r, exp.fmt, exp.quality)); if (!blob) return setMsg("Encoding failed"); if (blob.type !== exp.fmt) return setMsg(`This browser cannot encode ${exp.fmt} (it produced ${blob.type}). Choose another format.`); ext = exp.fmt === "image/jpeg" ? "jpg" : exp.fmt.split("/")[1]; }
    const stem = (original.current?.name ?? "image").replace(/\.[^.]+$/, "");
    if (target === "device") { downloadBlob(blob, `${stem}.${ext}`); setMsg(`Downloaded ${blob.size} bytes to your device`); return; }
    const p = await pickFile({ mode: "save", title: "Export image", startPath: EXPORTS, defaultName: `${stem}.${ext}` }); if (!p) return;
    const path = await fs.uniquePath(p[0]); await fs.writeFile(path, blob); setMsg(`Exported ${path} (${blob.size} bytes)`); notify({ title: "Export complete", message: basename(path), appId: "explorer" });
  };
  const fonts = ["sans-serif", "serif", "monospace", "cursive", "fantasy", "Arial", "Georgia", "Impact", "Courier New", "Trebuchet MS", "Verdana"];
  const filterThumbName = (n: string) => ({ none: "None", bw: "Black & white", sepia: "Sepia", vintage: "Vintage", film: "Film", warm: "Warm", cool: "Cool" } as Record<string, string>)[n];
  const b = base.current; const sz = b ? { w: b.width * zoom, h: b.height * zoom } : { w: 0, h: 0 }; const cursor = tool === "pan" ? "grab" : tool === "picker" ? "crosshair" : "crosshair";
  const T = (t: Tool, l: string) => <button key={t} className={"btn sm" + (tool === t ? " primary" : "")} onClick={() => { setTool(t); if (t === "crop" && b) setCrop(null); }} aria-pressed={tool === t}>{l}</button>;
  const curveRow = (ch: "m" | "r" | "g" | "b", l: string) => <div key={ch} className="col" style={{ gap: 0 }}><b className="small">{l}</b>{[0, 1, 2].map((i) => <Slider key={i} label={["Shadows", "Midtones", "Highlights"][i]} v={params.curves[ch][i]} min={0} max={255} step={1} set={(n) => setParams((p) => { const c = [...p.curves[ch]]; c[i] = n; return { ...p, curves: { ...p.curves, [ch]: c } }; })} commit={() => snapshot()} />)}</div>;
  return (
    <div className="app" style={{ flexDirection: "column" }}>
      <div className="toolbar"><button className="btn sm" onClick={openDlg}>Open…</button><button className="btn sm" onClick={() => saveProject()} disabled={!loaded}>Save project</button><button className="btn sm" onClick={() => saveProject(false, true)} disabled={!loaded}>Save as…</button>
        <button className="btn sm" onClick={undo} disabled={hi.current <= 0} aria-label="Undo">↶</button><button className="btn sm" onClick={redo} disabled={hi.current >= hist.current.length - 1} aria-label="Redo">↷</button>
        <button className="btn sm" onPointerDown={() => setCompare(true)} onPointerUp={() => setCompare(false)} onPointerLeave={() => setCompare(false)} disabled={!loaded}>Hold: original</button>
        <button className="btn sm" onClick={() => setZoom((z) => Math.max(0.05, z / 1.25))}>−</button><span className="small" style={{ width: 44, textAlign: "center" }}>{Math.round(zoom * 100)}%</span><button className="btn sm" onClick={() => setZoom((z) => Math.min(8, z * 1.25))}>+</button><button className="btn sm" onClick={fit}>Fit</button>
        <span className="grow" /><span className="dim small">{b ? `${b.width}×${b.height}${dirty ? " · unsaved" : ""}` : ""}{picked && <> · picked <b style={{ color: picked }}>{picked}</b></>}</span></div>
      <div className="row grow" style={{ alignItems: "stretch", gap: 0, minHeight: 0 }}>
        {panels && !viewMode && <div className="col solid scroll" style={{ width: 118, padding: 8, borderRight: "1px solid var(--border)", gap: 4 }}>{(["pan", "select", "crop", "brush", "eraser", "clone", "heal", "spot", "blur", "sharpen", "dodge", "burn", "picker", "text", "shape", "graphic"] as Tool[]).map((t) => T(t, t === "pan" ? "Pan / view" : t === "select" ? "Selection" : t === "clone" ? "Clone stamp" : t === "heal" ? "Healing" : t === "spot" ? "Spot fix" : t === "blur" ? "Blur brush" : t === "sharpen" ? "Sharpen brush" : t === "dodge" ? "Dodge" : t === "burn" ? "Burn" : t === "picker" ? "Color picker" : t === "graphic" ? "Graphic" : t[0].toUpperCase() + t.slice(1)))}</div>}
        <div ref={box} className="grow scroll" style={{ background: "repeating-conic-gradient(#8883 0 25%, #0000 0 50%) 0 0/20px 20px", position: "relative", display: "grid", placeItems: "center" }}>
          {!loaded ? <div className="col" style={{ alignItems: "center", gap: 10, padding: 30 }}><div style={{ fontSize: 22 }}>Neux Photo</div><div className="dim" style={{ maxWidth: 420, textAlign: "center" }}>Open an image from NeuxFS or a .wrphoto project. Editing is non-destructive until you commit a tool; your original is kept inside the project until you explicitly export or overwrite. No layers, masks or AI.</div><button className="btn primary" onClick={openDlg}>Open image…</button>{msg && <div role="alert" className="small" style={{ color: "var(--danger)", maxWidth: 420 }}>{msg}</div>}</div> :
            <div style={{ position: "relative", width: sz.w, height: sz.h, margin: 15, flexShrink: 0 }}>
              <canvas ref={view} style={{ width: sz.w, height: sz.h, display: "block", cursor, touchAction: "none", imageRendering: zoom > 2 ? "pixelated" : "auto" }} onPointerDown={down} onPointerMove={move} onPointerUp={up} />
              <svg style={{ position: "absolute", inset: 0, pointerEvents: "none" }} width={sz.w} height={sz.h} viewBox={`0 0 ${b!.width} ${b!.height}`}>
                {sel && <>{sel.kind === "rect" ? <rect x={sel.x} y={sel.y} width={sel.w} height={sel.h} fill="none" stroke="#fff" strokeDasharray={`${6 / zoom} ${4 / zoom}`} strokeWidth={1.5 / zoom} /> : <ellipse cx={sel.x + sel.w / 2} cy={sel.y + sel.h / 2} rx={sel.w / 2} ry={sel.h / 2} fill="none" stroke="#fff" strokeDasharray={`${6 / zoom} ${4 / zoom}`} strokeWidth={1.5 / zoom} />}</>}
                {crop && <><path fillRule="evenodd" fill="rgba(0,0,0,.55)" d={`M0 0H${b!.width}V${b!.height}H0Z M${crop.x} ${crop.y}h${crop.w}v${crop.h}h${-crop.w}Z`} /><rect x={crop.x} y={crop.y} width={crop.w} height={crop.h} fill="none" stroke="#fff" strokeWidth={2 / zoom} /></>}
                {dragShape && <line x1={dragShape.x0} y1={dragShape.y0} x2={dragShape.x1} y2={dragShape.y1} stroke={shape.color} strokeWidth={shape.width} opacity={0.6} />}
                {cloneSrc.current && (tool === "clone" || tool === "heal") && <circle cx={cloneSrc.current.x} cy={cloneSrc.current.y} r={brush.size / 2} fill="none" stroke="#0ff" strokeWidth={1.5 / zoom} />}
              </svg>
            </div>}
          {msg && loaded && <div className="small card" style={{ position: "absolute", bottom: 8, left: 8, right: 8 }} role="status">{msg} <button className="btn sm ghost" onClick={() => setMsg("")}>×</button></div>}
        </div>
        {panels && !viewMode && <div className="col solid" style={{ width: 300, borderLeft: "1px solid var(--border)", gap: 0 }}>
          <canvas ref={histCv} width={256} height={80} style={{ width: "100%", height: 64, background: "#0007" }} aria-label="Histogram" />
          <Tabs tabs={[["light", "Light"], ["color", "Color"], ["detail", "Detail"], ["curves", "Curves"], ["hsl", "HSL"], ["geo", "Geometry"], ["filters", "Filters"], ["tool", "Tool"], ["text", "Text/Shapes"], ["presets", "Presets"], ["export", "Export"]]} value={tab} onChange={setTab} />
          <div className="scroll grow col" style={{ padding: 10, gap: 4 }}>
            {tab === "light" && <>{num("exposure", "Exposure", -3, 3)}{num("brightness", "Brightness")}{num("contrast", "Contrast")}{num("highlights", "Highlights")}{num("shadows", "Shadows")}{num("whites", "Whites")}{num("blacks", "Blacks")}{num("gamma", "Gamma", 0.3, 3)}{num("dehaze", "Dehaze", 0, 1)}
              <b className="small">Levels</b>{(["inB", "inW", "g"] as const).map((k) => <Slider key={k} label={k === "inB" ? "Black point" : k === "inW" ? "White point" : "Mid gamma"} v={params.levels[k]} min={k === "g" ? 0.3 : 0} max={k === "g" ? 3 : 255} step={k === "g" ? 0.01 : 1} set={(n) => set("levels", { ...params.levels, [k]: n })} commit={() => snapshot()} />)}</>}
            {tab === "color" && <>{num("temperature", "Temperature")}{num("tint", "Tint")}{num("saturation", "Saturation")}{num("vibrance", "Vibrance")}<b className="small">Color balance</b>{(["sh", "mid", "hi"] as const).map((z) => <div key={z}><span className="dim small">{z === "sh" ? "Shadows" : z === "mid" ? "Midtones" : "Highlights"} R/G/B</span>{[0, 1, 2].map((c) => <Slider key={c} label={["Red", "Green", "Blue"][c]} v={params.balance[z][c]} min={-1} max={1} set={(n) => setParams((p) => { const a = [...p.balance[z]]; a[c] = n; return { ...p, balance: { ...p.balance, [z]: a } }; })} commit={() => snapshot()} />)}</div>)}</>}
            {tab === "detail" && <>{num("clarity", "Clarity", 0, 1)}{num("texture", "Texture", 0, 1)}{num("sharpness", "Sharpness", 0, 1)}{num("noise", "Noise reduction", 0, 1)}</>}
            {tab === "curves" && <>{curveRow("m", "Master")}{curveRow("r", "Red")}{curveRow("g", "Green")}{curveRow("b", "Blue")}<button className="btn sm" onClick={() => { setParams((p) => ({ ...p, curves: defaultParams().curves })); setTimeout(snapshot, 0); }}>Reset curves</button></>}
            {tab === "hsl" && <><div className="dim small">HSL / selective colour per hue range</div>{HSL_BANDS.map((n, i) => <div key={n}><b className="small">{n}</b>{(["h", "s", "l"] as const).map((k) => <Slider key={k} label={k === "h" ? "Hue" : k === "s" ? "Saturation" : "Luminance"} v={params.hsl[k][i]} min={-1} max={1} set={(v) => setParams((p) => { const a = [...p.hsl[k]]; a[i] = v; return { ...p, hsl: { ...p.hsl, [k]: a } }; })} commit={() => snapshot()} />)}</div>)}</>}
            {tab === "geo" && <>
              <div className="row wrap"><button className="btn sm" onClick={() => rot90(-1)}>⟲ 90°</button><button className="btn sm" onClick={() => rot90(1)}>⟳ 90°</button><button className="btn sm" onClick={() => flip(true)}>Flip H</button><button className="btn sm" onClick={() => flip(false)}>Flip V</button><button className="btn sm" onClick={trim}>Trim canvas</button></div>
              <Slider label="Angle" v={geo.angle} min={-45} max={45} step={0.1} set={(n) => setGeo({ ...geo, angle: n })} commit={() => {}} fmt={(n) => n.toFixed(1) + "°"} /><div className="row"><button className="btn sm" onClick={() => rotateAny(geo.angle, false)}>Rotate (expand)</button><button className="btn sm" onClick={() => rotateAny(geo.angle, true)}>Straighten (crop to fit)</button></div>
              <b className="small">Resize / resolution</b><div className="row"><input className="input" type="number" value={geo.w} onChange={(e) => { const w = Number(e.target.value); setGeo({ ...geo, w, h: geo.lock && b ? Math.round((w * b.height) / b.width) : geo.h }); }} aria-label="Width" /><span>×</span><input className="input" type="number" value={geo.h} onChange={(e) => { const h = Number(e.target.value); setGeo({ ...geo, h, w: geo.lock && b ? Math.round((h * b.width) / b.height) : geo.w }); }} aria-label="Height" /><label className="row small"><input type="checkbox" checked={geo.lock} onChange={(e) => setGeo({ ...geo, lock: e.target.checked })} />lock</label></div><button className="btn sm" onClick={resize}>Resize</button>
              <div className="row small"><span>Resolution</span><input className="input" style={{ width: 70 }} type="number" value={geo.dpi} onChange={(e) => setGeo({ ...geo, dpi: Number(e.target.value) })} aria-label="DPI" /><span className="dim">dpi (metadata only; pixels unchanged — canvas export cannot embed it)</span></div>
              <b className="small">Expand canvas / frame</b><div className="row"><input className="input" type="number" value={geo.pad} onChange={(e) => setGeo({ ...geo, pad: Number(e.target.value) })} aria-label="Padding px" /><input type="color" value={geo.padColor} onChange={(e) => setGeo({ ...geo, padColor: e.target.value })} aria-label="Colour" /></div><div className="row"><button className="btn sm" onClick={expand}>Expand</button><button className="btn sm" onClick={frame}>Add border frame</button></div>
              <b className="small">Perspective (vertical keystone)</b><Slider label="Keystone" v={geo.keyV} min={-0.5} max={0.5} set={(n) => setGeo({ ...geo, keyV: n })} commit={() => {}} /><button className="btn sm" onClick={keystone}>Apply keystone</button><div className="dim small">Full 4-point perspective correction is not implemented.</div>
              <b className="small">Crop</b><div className="row"><select className="input" value={ratio} onChange={(e) => setRatio(e.target.value)} aria-label="Aspect ratio">{Object.keys(RATIOS).map((r) => <option key={r}>{r}</option>)}</select><button className="btn sm" onClick={() => { setTool("crop"); }}>Crop tool</button></div><div className="row"><button className="btn sm primary" disabled={!crop || crop.w < 4} onClick={applyCrop}>Apply crop</button>{sel && <button className="btn sm" onClick={() => { setCrop(sel); setTimeout(applyCrop, 0); }}>Crop to selection</button>}</div></>}
            {tab === "filters" && <><div className="row wrap">{FILTER_NAMES.map((n) => <button key={n} className={"btn sm" + (params.filter === n ? " primary" : "")} onClick={() => { set("filter", n); setTimeout(snapshot, 0); }}>{filterThumbName(n)}</button>)}</div>{num("filterAmount", "Filter amount", 0, 1)}{num("vignette", "Vignette", -1, 1)}{num("grain", "Grain", 0, 1)}{num("blur", "Gaussian blur", 0, 30, 0.5)}{num("motion", "Motion blur", 0, 60, 1)}{num("pixelate", "Pixelate", 0, 60, 1)}{num("overlayAmount", "Color overlay", 0, 1)}<input type="color" value={params.overlayColor} onChange={(e) => set("overlayColor", e.target.value)} aria-label="Overlay colour" /><div className="dim small">Adjustments are previewed non-destructively. “Bake” commits them into the pixels.</div><button className="btn sm" onClick={bakeAdjust}>Bake adjustments into image</button></>}
            {tab === "tool" && <><div className="dim small">Active tool: <b>{tool}</b>. Space+drag pans. [ and ] change brush size.</div><Slider label="Size" v={brush.size} min={2} max={400} step={1} set={(n) => setBrush({ ...brush, size: n })} commit={() => {}} /><Slider label="Hardness" v={brush.hardness} min={0} max={0.95} set={(n) => setBrush({ ...brush, hardness: n })} commit={() => {}} /><Slider label="Opacity" v={brush.opacity} min={0.05} max={1} set={(n) => setBrush({ ...brush, opacity: n })} commit={() => {}} /><Slider label="Strength" v={brush.strength} min={0.05} max={1} set={(n) => setBrush({ ...brush, strength: n })} commit={() => {}} /><label className="row small">Colour <input type="color" value={brush.color} onChange={(e) => setBrush({ ...brush, color: e.target.value })} /></label>
              <b className="small">Selection</b><div className="row"><select className="input" value={selKind} onChange={(e) => setSelKind(e.target.value as "rect" | "ellipse")} aria-label="Selection shape"><option value="rect">Rectangle</option><option value="ellipse">Ellipse</option></select><button className="btn sm" onClick={() => setTool("select")}>Select</button><button className="btn sm" onClick={() => setSel(null)} disabled={!sel}>Deselect</button></div>
              {sel && <button className="btn sm" onClick={() => { const c = base.current!.getContext("2d")!; c.save(); clipSel(c); c.fillStyle = brush.color; c.fillRect(0, 0, base.current!.width, base.current!.height); c.restore(); snapshot(); render(); }}>Fill selection</button>}<div className="dim small">Clone/Heal: click once to set the source (or Alt+click), then paint.</div></>}
            {tab === "text" && <><b className="small">Text (click the image to place; flattened on commit)</b><textarea className="input" rows={2} value={text.s} onChange={(e) => setText({ ...text, s: e.target.value })} aria-label="Text" />
              <div className="row"><select className="input" value={text.font} onChange={(e) => setText({ ...text, font: e.target.value })} aria-label="Font">{fonts.map((f) => <option key={f} style={{ fontFamily: f }}>{f}</option>)}</select><input type="color" value={text.color} onChange={(e) => setText({ ...text, color: e.target.value })} aria-label="Text colour" /></div>
              <Slider label="Size" v={text.size} min={8} max={500} step={1} set={(n) => setText({ ...text, size: n })} commit={() => {}} /><Slider label="Weight" v={text.weight} min={100} max={900} step={100} set={(n) => setText({ ...text, weight: n })} commit={() => {}} /><Slider label="Rotation" v={text.rot} min={-180} max={180} step={1} set={(n) => setText({ ...text, rot: n })} commit={() => {}} />
              <div className="row">{(["left", "center", "right"] as const).map((a) => <button key={a} className={"btn sm" + (text.align === a ? " primary" : "")} onClick={() => setText({ ...text, align: a })}>{a}</button>)}<button className="btn sm primary" onClick={() => setTool("text")}>Place text</button></div>
              <hr className="sep" /><b className="small">Shapes</b><div className="row wrap">{(["rect", "ellipse", "line", "arrow"] as const).map((k) => <button key={k} className={"btn sm" + (shape.kind === k ? " primary" : "")} onClick={() => { setShape({ ...shape, kind: k }); setTool("shape"); }}>{k}</button>)}</div><div className="row"><input type="color" value={shape.color} onChange={(e) => setShape({ ...shape, color: e.target.value })} aria-label="Shape colour" /><Slider label="Width" v={shape.width} min={1} max={60} step={1} set={(n) => setShape({ ...shape, width: n })} commit={() => {}} /></div><label className="row small"><input type="checkbox" checked={shape.fill} onChange={(e) => setShape({ ...shape, fill: e.target.checked })} />Filled</label>
              <hr className="sep" /><b className="small">Imported graphic</b><button className="btn sm" onClick={async () => { const p = await pickFile({ filter: "image", title: "Choose a graphic" }); if (!p) return; try { setGraphic({ bmp: await createImageBitmap((await fs.stat(p[0])).data!), scale: 0.4 }); setTool("graphic"); } catch { setMsg("Cannot decode that graphic."); } }}>Choose graphic…</button>{graphic && <Slider label="Scale" v={graphic.scale} min={0.02} max={3} set={(n) => setGraphic({ ...graphic, scale: n })} commit={() => {}} />}</>}
            {tab === "presets" && <><button className="btn sm primary" onClick={async () => { const n = await promptBox("Save preset", "Preset name"); if (!n) return; const { ...rest } = params; const np = { ...presets, [n]: rest }; setPresets(np); await fs.writeFile(DIR + "/presets.json", JSON.stringify(np)); }}>Save current adjustments as preset</button>
              {Object.keys(presets).length === 0 && <div className="dim small">No presets yet.</div>}{Object.entries(presets).map(([n, pr]) => <div key={n} className="row"><button className="btn sm grow" onClick={() => { setParams({ ...defaultParams(), ...pr } as Params); setTimeout(snapshot, 0); }}>{n}</button><button className="btn sm" onClick={async () => { const nn = await promptBox("Rename preset", "Name", n); if (!nn || nn === n) return; const np = { ...presets }; np[nn] = np[n]; delete np[n]; setPresets(np); await fs.writeFile(DIR + "/presets.json", JSON.stringify(np)); }}>Rename</button><button className="btn sm danger" onClick={async () => { const np = { ...presets }; delete np[n]; setPresets(np); await fs.writeFile(DIR + "/presets.json", JSON.stringify(np)); }}>×</button></div>)}<button className="btn sm" onClick={() => { setParams(defaultParams()); setTimeout(snapshot, 0); }}>Reset all adjustments</button></>}
            {tab === "export" && <><select className="input" value={exp.fmt} onChange={(e) => setExp({ ...exp, fmt: e.target.value })} aria-label="Format"><option value="image/png">PNG (lossless, transparency)</option><option value="image/jpeg">JPEG</option><option value="image/webp">WebP</option><option value="image/avif">AVIF (if encodable)</option><option value="image/tiff">TIFF (uncompressed RGBA)</option></select>
              <Slider label="Quality" v={exp.quality} min={0.1} max={1} set={(n) => setExp({ ...exp, quality: n })} commit={() => {}} /><Slider label="Scale %" v={exp.scale} min={5} max={200} step={1} set={(n) => setExp({ ...exp, scale: n })} commit={() => {}} fmt={(n) => `${n}%`} /><div className="dim small">Output: {b ? `${Math.round(b.width * exp.scale / 100)}×${Math.round(b.height * exp.scale / 100)} px` : "—"} · colour profile sRGB (not embedded) · metadata not preserved (re-encoding strips EXIF) · {exp.fmt === "image/jpeg" ? "transparency flattened on background" : "transparency kept"}</div>
              {exp.fmt === "image/jpeg" && <label className="row small">Background <input type="color" value={exp.bg} onChange={(e) => setExp({ ...exp, bg: e.target.value })} /></label>}
              <button className="btn primary" disabled={!loaded} onClick={() => doExport("neux")}>Export to NeuxFS…</button><button className="btn" disabled={!loaded} onClick={() => doExport("device")}>Download to this device</button><div className="dim small">Your original file is never modified. Default folder: {EXPORTS}</div></>}
          </div>
        </div>}
      </div>
    </div>
  );
}
void join; void alertBox; void closeWin;
