"use client";
import { useEffect, useRef, useState } from "react";
import { fs, NEUX_VERSION } from "@/core/kernel";
import { useWin, Switch, Setting, Tabs, Empty, useFs, downloadBlob } from "@/shell/ui";
import { os, closeWin, focusWin, openApp, pickFile, confirmBox, alertBox, notify } from "@/core/os";
import { useStore } from "@/core/store";
import { settingsStore, setSetting } from "@/core/settings";
import { formatBytes, sha256Hex } from "@/core/util";
import { inspect, quarantine, restoreQuarantine, trust, untrust, trustedHashes, getHistory, listQuarantine, protectionMatrix, setIsolation, logEvent, type Inspection } from "@/core/security";
import { runIntegrityCheck, type Check } from "@/core/recovery";
import { backupAll, restoreBackup } from "@/core/filesystem/archive";
import { capabilities, detectPlatform } from "@/adapters/web/platform";
import { jobs } from "@/core/applications/store-service";
import { downloads } from "@/core/networking/downloads";
import { WALLPAPERS } from "@/shell/wallpapers";
import { resetAllNeuxData } from "@/core/reset";
import { BUILTIN } from "@/core/applications/registry";
import { AppIcon } from "@/shell/icons";
import { applyWebUpdate } from "@/core/updates";
import { basename } from "@/core/filesystem/neuxfs";

export function SecureCenter() {
  const { params, rev } = useWin(); const iso = useStore(settingsStore, (s) => s.isolation);
  const [tab, setTab] = useState(String(params.tab ?? "dash")); const [path, setPath] = useState(String(params.path ?? "")); const [res, setRes] = useState<Inspection | null>(null); const [err, setErr] = useState("");
  const [q, reloadQ] = useFs(listQuarantine, [], [] as Awaited<ReturnType<typeof listQuarantine>>); const [trusted, setTrusted] = useState<string[]>([]); const [hist, setHist] = useState<Awaited<ReturnType<typeof getHistory>>>([]);
  const refresh = () => { trustedHashes().then(setTrusted); getHistory().then(setHist); };
  useEffect(refresh, [tab, q.length]);
  useEffect(() => { if (params.tab) setTab(String(params.tab)); if (params.path) { setPath(String(params.path)); void doInspect(String(params.path)); } /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [rev]);
  async function doInspect(p: string) { setErr(""); setRes(null); try { setRes(await inspect(p)); } catch (e) { setErr((e as Error).message); } }
  const m = protectionMatrix();
  return (
    <div className="col" style={{ height: "100%", gap: 0 }}>
      <div className="row" style={{ padding: "12px 16px", gap: 12 }}><AppIcon id="secure" size={40} /><div className="grow"><b style={{ fontSize: 17 }}>Secure Center</b><div className="dim small">WR Security Centre · isolation & inspection — not an antivirus</div></div><span className={"badge " + (iso ? "ok" : "warn")}>{iso ? "Isolation ON" : "Isolation off"}</span></div>
      {params.blocked ? <div className="card small" role="alert" style={{ margin: "0 16px", borderColor: "var(--warn)" }}>Blocked: {String(params.blocked)}</div> : null}
      <Tabs tabs={[["dash", "Dashboard"], ["inspect", "Inspect file"], ["quarantine", `Quarantine (${q.length})`], ["trusted", "Trusted exceptions"], ["history", "History"]]} value={tab} onChange={setTab} />
      <div className="scroll grow" style={{ padding: 16 }}>
        {tab === "dash" && <div className="col">
          <div className="card col"><Setting title="File Isolation Protection" desc="Turn this on before opening a file you suspect is unsafe. Untrusted scripts, packages and .wr/.wrapp files will be blocked from running; apps lose clipboard, camera and microphone access; executables are never launched."><Switch label="File Isolation Protection" checked={iso} onChange={(v) => setIsolation(v)} /></Setting></div>
          <b>What is actually enforced in this edition</b>
          <table className="tbl"><tbody>{m.map((x) => <tr key={x.name}><td style={{ width: 24 }}>{x.available ? <span style={{ color: "var(--ok)" }}>✓</span> : <span style={{ color: "var(--danger)" }}>✗</span>}</td><td><b>{x.name}</b><div className="dim small">{x.note}</div></td></tr>)}</tbody></table>
          <div className="dim small">“Safe” is never concluded from a hash, signature or extension check. Items marked ✗ are not available on the Web edition and will be shown as available only once a native adapter implements them.</div></div>}
        {tab === "inspect" && <div className="col">
          <div className="row"><input className="input" value={path} onChange={(e) => setPath(e.target.value)} placeholder="/Users/Default/Downloads/file" aria-label="File path" /><button className="btn" onClick={async () => { const p = await pickFile({ filter: "all", title: "Choose a file to inspect" }); if (p) { setPath(p[0]); void doInspect(p[0]); } }}>Browse…</button><button className="btn primary" disabled={!path} onClick={() => doInspect(path)}>Inspect</button></div>
          {err && <div role="alert" style={{ color: "var(--danger)" }}>{err}</div>}
          {res && <div className="card col small"><div><b>{basename(res.path)}</b> · {formatBytes(res.size)} · type .{res.ext || "none"} · detected <b>{res.magic}</b></div><div className="mono" style={{ wordBreak: "break-all" }}>SHA-256 {res.sha256}</div>
            {res.warnings.length ? res.warnings.map((w) => <div key={w} className="badge bad" style={{ display: "block", padding: 6 }}>⚠ {w}</div>) : <div className="badge ok">No structural warnings found (this does not mean the file is safe)</div>}
            {res.entries && <details><summary>Archive contents ({res.entries.length})</summary><div className="mono">{res.entries.slice(0, 80).join("\n")}</div></details>}{res.manifest ? <details open><summary>Package manifest / requested permissions</summary><pre className="mono small" style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(res.manifest, null, 1)}</pre></details> : null}
            <div className="dim">{res.note}</div><div className="row"><button className="btn danger sm" onClick={async () => { await quarantine(res.path); setRes(null); setTab("quarantine"); }}>Quarantine</button><button className="btn sm" onClick={async () => { await trust(res.path); refresh(); notify({ title: "Trusted exception added", message: "This exact file hash may run while isolation is on." }); }}>Trust this exact file</button><button className="btn sm" onClick={() => openApp("texteditor", { path: res.path, readonly: true })}>View as text (safe)</button></div></div>}
        </div>}
        {tab === "quarantine" && (q.length === 0 ? <Empty>Quarantine is empty.</Empty> : <table className="tbl"><thead><tr><th>File</th><th>Original location</th><th /></tr></thead><tbody>{q.map((n) => <tr key={n.path}><td>{n.name}</td><td className="dim small">{String(n.meta?.originalPath ?? "?")}</td><td><div className="row"><button className="btn sm" onClick={async () => { await restoreQuarantine(n.path); reloadQ(); }}>Restore</button><button className="btn sm danger" onClick={async () => { if (await confirmBox("Delete", "Permanently delete this file?", true, "Delete")) { await fs.remove(n.path, { role: "root" }); await logEvent("delete-quarantined", n.name); reloadQ(); } }}>Delete</button></div></td></tr>)}</tbody></table>)}
        {tab === "trusted" && (trusted.length === 0 ? <Empty>No trusted exceptions. A trusted file hash may run even while isolation is ON.</Empty> : trusted.map((h) => <div key={h} className="row card" style={{ marginBottom: 6 }}><span className="mono small grow" style={{ wordBreak: "break-all" }}>{h}</span><button className="btn sm" onClick={async () => { await untrust(h); refresh(); }}>Remove</button></div>))}
        {tab === "history" && (hist.length === 0 ? <Empty>No security events.</Empty> : <table className="tbl"><tbody>{hist.map((h, i) => <tr key={i}><td className="dim small" style={{ whiteSpace: "nowrap" }}>{new Date(h.ts).toLocaleString()}</td><td><span className="badge">{h.action}</span></td><td className="small">{h.target}<div className="dim">{h.detail}</div></td></tr>)}</tbody></table>)}
      </div>
    </div>
  );
}

export function Recovery() {
  const [tab, setTab] = useState("integrity"); const [checks, setChecks] = useState<Check[]>([]); const [busy, setBusy] = useState(false); const [usage, setUsage] = useState(0); const [msg, setMsg] = useState("");
  const [ack, setAck] = useState(false); const [typed, setTyped] = useState(""); const [log, setLog] = useState<string[]>([]); const [resetting, setResetting] = useState(false);
  const run = async (repair: boolean) => { setBusy(true); try { setChecks(await runIntegrityCheck(repair)); } catch (e) { setMsg((e as Error).message); } setBusy(false); };
  useEffect(() => { void run(false); fs.usage().then(setUsage); }, []);
  const doBackup = async (dl: boolean) => { const bytes = await backupAll(fs); const name = `neux-backup-${new Date().toISOString().slice(0, 10)}.zip`; if (dl) downloadBlob(new Blob([bytes as BlobPart]), name); else { const p = await fs.uniquePath("/Users/Default/Documents/" + name); await fs.writeFile(p, bytes); setMsg(`Backup saved to ${p} · SHA-256 ${(await sha256Hex(bytes)).slice(0, 24)}…`); } };
  const doRestore = async () => { const p = await pickFile({ filter: "archive", title: "Choose a Neux backup (.zip)" }); if (!p) return; if (!(await confirmBox("Restore backup", "Files from the backup are written into NeuxFS (existing files with the same path are overwritten). Continue?", true, "Restore"))) return; try { const n = await restoreBackup(fs, await fs.readBytes(p[0])); setMsg(`Restored ${n} file(s). Restart Neux to reload configuration.`); } catch (e) { setMsg("Restore failed: " + (e as Error).message); } };
  return (
    <div className="col" style={{ height: "100%", gap: 0 }}>
      <div className="row" style={{ padding: 14 }}><AppIcon id="recovery" size={38} /><div><b style={{ fontSize: 17 }}>Neux Recovery</b><div className="dim small">Application-level recovery. It does not repair or reset your host operating system.</div></div></div>
      <Tabs tabs={[["integrity", "Integrity & repair"], ["storage", "Storage"], ["backup", "Backup & restore"], ["reinstall", "Reinstall / rollback"], ["factory", "Factory reset"]]} value={tab} onChange={setTab} />
      <div className="scroll grow col" style={{ padding: 16 }}>
        {msg && <div role="status" className="card small">{msg}</div>}
        {tab === "integrity" && <><div className="row"><button className="btn" onClick={() => run(false)} disabled={busy}>Run check</button><button className="btn primary" onClick={async () => { if (await confirmBox("Repair", "Recreate missing system folders and remove damaged app registrations?")) run(true); }} disabled={busy}>Repair</button></div>{checks.map((c) => <div key={c.name} className="row card small"><span style={{ color: c.ok ? "var(--ok)" : "var(--danger)" }}>{c.ok ? "✓" : "✗"}</span><b>{c.name}</b><span className="dim">{c.detail}</span></div>)}</>}
        {tab === "storage" && <><div className="card">NeuxFS uses <b>{formatBytes(usage)}</b>.</div><button className="btn" style={{ alignSelf: "flex-start" }} onClick={() => run(false)}>Re-run storage read/write check</button>{checks.filter((c) => c.name.startsWith("Storage")).map((c) => <div key={c.name} className="card small">{c.ok ? "✓" : "✗"} {c.detail}</div>)}<button className="btn" style={{ alignSelf: "flex-start" }} onClick={async () => { await fs.emptyTrash(); fs.usage().then(setUsage); }}>Empty Trash</button></>}
        {tab === "backup" && <><div className="row wrap"><button className="btn primary" onClick={() => doBackup(false)}>Back up to NeuxFS Documents</button><button className="btn" onClick={() => doBackup(true)}>Download backup to this device</button><button className="btn" onClick={doRestore}>Restore from backup…</button></div><div className="dim small">Backups are ZIP files containing every NeuxFS file plus an index. They are never created automatically. Store a copy outside the browser profile.</div></>}
        {tab === "reinstall" && <><div className="card col"><b>Reinstall Neux program files</b><div className="dim small">Clears Neux&apos;s program cache and reloads the app so the files deployed on your server are fetched again. Your data is untouched.</div><button className="btn" style={{ alignSelf: "flex-start" }} onClick={() => confirmBox("Reinstall", "Clear the program cache and reload?").then((y) => { if (y) void applyWebUpdate(); })}>Reinstall program files</button></div><div className="card dim small"><b>Update rollback:</b> not available in the Web edition — redeploy the previous release folder to roll back. Native editions keep the previous version for rollback (see PLATFORM_SPECIFICATION.md).</div></>}
        {tab === "factory" && <div className="card col" style={{ borderColor: "var(--danger)" }}><b style={{ color: "var(--danger)" }}>Erase all Neux data</b><div className="small">Deletes everything stored inside Neux (files, apps, accounts, settings, playlists, browser data). Your host OS and other files are not touched. Cannot be undone; no backup is made unless you make one first.</div>
          <label className="row small"><input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} />I understand that all Neux data will be permanently erased.</label><input className="input" placeholder='Type ERASE to confirm' value={typed} onChange={(e) => setTyped(e.target.value)} aria-label="Type ERASE" style={{ maxWidth: 240 }} />
          <button className="btn danger" style={{ alignSelf: "flex-start" }} disabled={!ack || typed !== "ERASE" || resetting} onClick={async () => { if (!(await confirmBox("Final confirmation", "Erase all Neux data now?", true, "Erase"))) return; setResetting(true); try { await resetAllNeuxData((s) => setLog((l) => [...l, s])); setLog((l) => [...l, "Restarting…"]); setTimeout(() => location.reload(), 800); } catch (e) { setLog((l) => [...l, "Error: " + (e as Error).message]); } }}>Erase all Neux data</button><div className="mono small">{log.map((l, i) => <div key={i}>{l}</div>)}</div></div>}
      </div>
    </div>
  );
}

export function TaskManager() {
  const ws = useStore(os, (s) => s.windows); const allJobs = useStore(jobs, (s) => s.list); const js = allJobs.filter((j) => !["installed", "failed", "canceled"].includes(j.state)); const allDl = useStore(downloads, (s) => s.items); const dl = allDl.filter((d) => d.state === "downloading");
  return (
    <div className="scroll" style={{ padding: 12, height: "100%" }}>
      <table className="tbl"><thead><tr><th>Application</th><th>Window</th><th>State</th><th>Desktop</th><th>Running</th><th /></tr></thead><tbody>
        {ws.map((w) => <tr key={w.id}><td><span className="row"><AppIcon id={w.appId === "pkg" ? "pkg:" + w.params.pkgId : w.appId} size={22} />{BUILTIN.find((b) => b.id === w.appId)?.name ?? String(w.params.pkgId)}</span></td><td>{w.title}</td><td>{w.state}</td><td>{w.desktop + 1}</td><td className="dim small">{Math.round((Date.now() - w.startedAt) / 1000)} s</td><td><div className="row"><button className="btn sm" onClick={() => { os.set((s) => ({ windows: s.windows.map((x) => (x.id === w.id ? { ...x, desktop: s.current } : x)) })); focusWin(w.id); }}>Switch</button><button className="btn sm danger" onClick={() => closeWin(w.id, true)}>End task</button></div></td></tr>)}</tbody></table>
      {!ws.length && <Empty>No windows.</Empty>}
      {(js.length > 0 || dl.length > 0) && <><b>Background work</b>{js.map((j) => <div key={j.id} className="card small">Installing {j.name}: {j.state} {Math.round(j.percent)}%</div>)}{dl.map((d) => <div key={d.id} className="card small">Downloading {d.name}: {formatBytes(d.received)}</div>)}</>}
    </div>
  );
}

export function SysMonitor() {
  const [fps, setFps] = useState<number[]>([]); const [heap, setHeap] = useState<number[]>([]); const [info, setInfo] = useState<{ used: number; quota: number }>({ used: 0, quota: 0 }); const cv = useRef<HTMLCanvasElement>(null);
  useEffect(() => { let n = 0, t0 = performance.now(), on = true; const f = () => { if (!on) return; n++; requestAnimationFrame(f); }; requestAnimationFrame(f);
    const iv = setInterval(() => { const now = performance.now(); setFps((a) => [...a.slice(-59), (n * 1000) / (now - t0)]); n = 0; t0 = now; const m = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory; if (m) setHeap((a) => [...a.slice(-59), m.usedJSHeapSize]); navigator.storage?.estimate?.().then((e) => setInfo({ used: e.usage ?? 0, quota: e.quota ?? 0 })); }, 1000); return () => { on = false; clearInterval(iv); }; }, []);
  useEffect(() => { const c = cv.current; if (!c) return; const x = c.getContext("2d")!; x.clearRect(0, 0, c.width, c.height); x.strokeStyle = "#5b8cff"; x.beginPath(); fps.forEach((v, i) => { const px = (i / 59) * c.width, py = c.height - (Math.min(v, 120) / 120) * c.height; i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.stroke(); }, [fps]);
  const m = heap[heap.length - 1];
  return <div className="col scroll" style={{ padding: 16, height: "100%" }}>
    <div className="card"><b>Frame rate</b> — {fps.length ? fps[fps.length - 1].toFixed(0) : "…"} fps (measured with requestAnimationFrame)<canvas ref={cv} width={600} height={90} style={{ width: "100%", height: 90, marginTop: 6 }} aria-label="FPS graph" /></div>
    <table className="tbl"><tbody>
      <tr><td>JS heap used</td><td>{m ? formatBytes(m) : "not exposed by this browser"}</td></tr><tr><td>Device memory hint</td><td>{(navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? "n/a"} GB</td></tr><tr><td>Logical CPU threads</td><td>{navigator.hardwareConcurrency}</td></tr>
      <tr><td>Storage used by this origin</td><td>{formatBytes(info.used)} of ~{formatBytes(info.quota)}</td></tr><tr><td>CPU load</td><td className="dim">Browsers do not expose CPU load to web pages</td></tr></tbody></table></div>;
}

export function Diagnostics() {
  const [tests, setTests] = useState<{ name: string; ok: boolean; detail: string }[]>([]); const p = detectPlatform();
  useEffect(() => { (async () => {
    const out: typeof tests = [];
    try { const probe = "diag-" + Date.now(); await fs.writeFile("/Temporary/diag.txt", probe, { role: "root" }); const ok = (await fs.readText("/Temporary/diag.txt")) === probe; await fs.remove("/Temporary/diag.txt", { role: "root" }); out.push({ name: "NeuxFS write/read", ok, detail: ok ? "OK" : "mismatch" }); } catch (e) { out.push({ name: "NeuxFS write/read", ok: false, detail: (e as Error).message }); }
    try { const h = await sha256Hex(new TextEncoder().encode("abc")); out.push({ name: "SHA-256 known-answer", ok: h.startsWith("ba7816bf"), detail: h.slice(0, 16) }); } catch (e) { out.push({ name: "SHA-256", ok: false, detail: (e as Error).message }); }
    const reg = await navigator.serviceWorker?.getRegistration?.(); out.push({ name: "Service worker (offline)", ok: !!reg, detail: reg ? "registered, scope " + reg.scope : "not registered (needs HTTPS and a production build)" });
    out.push({ name: "Persistent storage granted", ok: !!(await navigator.storage?.persisted?.()), detail: "Request it in Settings → System" });
    setTests(out); })(); }, []);
  return <div className="col scroll" style={{ padding: 16, height: "100%" }}>
    <div className="card small">Neux {NEUX_VERSION} · {p.edition} edition · host {p.host} · {p.standalone ? "installed PWA" : "browser tab"} · secure context: {String(window.isSecureContext)}</div>
    <b>Self-tests (executed now)</b>{tests.map((t) => <div key={t.name} className="row card small"><span style={{ color: t.ok ? "var(--ok)" : "var(--warn)" }}>{t.ok ? "✓" : "✗"}</span><b>{t.name}</b><span className="dim">{t.detail}</span></div>)}
    <b>Platform capabilities</b><table className="tbl"><tbody>{capabilities().map((c) => <tr key={c.name}><td style={{ width: 24, color: c.available ? "var(--ok)" : "var(--danger)" }}>{c.available ? "✓" : "✗"}</td><td>{c.name}<div className="dim small">{c.detail}</div></td></tr>)}</tbody></table></div>;
}

export function Backup() {
  const [msg, setMsg] = useState(""); const [list] = useFs(async () => (await fs.list("/Users/Default/Documents")).filter((n) => n.name.startsWith("neux-backup")), [], [] as Awaited<ReturnType<typeof fs.list>>);
  return <div className="col scroll" style={{ padding: 16, height: "100%" }}><b>Backup</b><div className="dim small">Creates a ZIP of everything in NeuxFS. Nothing is backed up automatically and nothing leaves your device unless you download it.</div>
    <div className="row wrap"><button className="btn primary" onClick={async () => { const bytes = await backupAll(fs); const p = await fs.uniquePath(`/Users/Default/Documents/neux-backup-${new Date().toISOString().slice(0, 10)}.zip`); await fs.writeFile(p, bytes); setMsg(`Saved ${p} (${formatBytes(bytes.length)})`); }}>Back up now</button><button className="btn" onClick={async () => downloadBlob(new Blob([(await backupAll(fs)) as BlobPart]), "neux-backup.zip")}>Download backup</button><button className="btn" onClick={async () => { const p = await pickFile({ filter: "archive", title: "Choose backup" }); if (p && await confirmBox("Restore", "Overwrite matching files in NeuxFS with the backup contents?", true, "Restore")) try { setMsg(`Restored ${await restoreBackup(fs, await fs.readBytes(p[0]))} file(s)`); } catch (e) { setMsg((e as Error).message); } }}>Restore…</button></div>
    {msg && <div role="status" className="card small">{msg}</div>}{list.map((n) => <div key={n.path} className="row card small"><span className="grow">{n.name}</span><span className="dim">{formatBytes(n.size)}</span><button className="btn sm" onClick={() => openApp("explorer", { path: n.path })}>Show</button></div>)}</div>;
}

export function Themes() {
  const s = useStore(settingsStore, (x) => x);
  return <div className="col scroll" style={{ padding: 16, height: "100%" }}>
    <Setting title="Mode"><div className="row">{(["dark", "light", "auto"] as const).map((m) => <button key={m} className={"btn sm" + (s.theme === m ? " primary" : "")} onClick={() => setSetting("theme", m)}>{m}</button>)}</div></Setting>
    <Setting title="Accent"><input type="color" value={s.accent} onChange={(e) => setSetting("accent", e.target.value)} aria-label="Accent colour" /></Setting>
    <b>Wallpapers</b><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 10 }}>{WALLPAPERS.filter((w) => !w.region || w.region === s.region || s.wallpaper === w.id).map((w) => <button key={w.id} onClick={() => setSetting("wallpaper", w.id)} aria-label={w.name} aria-pressed={s.wallpaper === w.id} style={{ height: 90, borderRadius: 12, border: s.wallpaper === w.id ? "3px solid var(--accent)" : "1px solid var(--border)", backgroundImage: w.css, backgroundSize: "cover", cursor: "pointer", color: "#fff", textShadow: "0 1px 3px #000", fontSize: 12, display: "flex", alignItems: "flex-end", padding: 6, textAlign: "left" }}>{w.name}</button>)}</div>
    <div className="row"><button className="btn" onClick={async () => { const p = await pickFile({ filter: "image", title: "Choose wallpaper", startPath: "/Users/Default/Pictures" }); if (p) setSetting("wallpaper", "fs:" + p[0]); }}>Use a picture from NeuxFS…</button>{s.wallpaper.startsWith("fs:") && <span className="dim small">{basename(s.wallpaper.slice(3))}</span>}</div>
    {!s.region && <div className="dim small">Set a region in Settings to reveal regional wallpaper collections.</div>}</div>;
}
export function WidgetsApp() {
  const w = useStore(settingsStore, (s) => s.widgets);
  const tog = (id: string, v: boolean) => setSetting("widgets", v ? [...w, id] : w.filter((x) => x !== id));
  return <div className="col" style={{ padding: 16 }}><b>Desktop widgets</b>{[["clock", "Clock & date (with regional holiday)"], ["storage", "NeuxFS storage usage"], ["calendar", "Today"]].map(([id, l]) => <Setting key={id} title={l}><Switch label={l} checked={w.includes(id)} onChange={(v) => tog(id, v)} /></Setting>)}</div>;
}
void Checks; void alertBox; function Checks() { return null; }
