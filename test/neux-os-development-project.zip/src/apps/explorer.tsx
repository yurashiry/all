"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { basename, dirname, join, norm, type FsNode } from "@/core/filesystem/neuxfs";
import { openApp, showMenu, alertBox, confirmBox, promptBox, notify, resolvePicker, pickerOptions, closeWin, setTitle, type PickerFilter, type PickerOptions, type MenuItem } from "@/core/os";
import { openFile, compatibleApps, defaultAppFor, setAssociation } from "@/core/file-associations";
import { BUILTIN } from "@/core/applications/registry";
import { extOf, formatBytes, kindOf, sha256Hex } from "@/core/util";
import { archivePaths, unarchive } from "@/core/filesystem/archive";
import { useFs, FileGlyph, useWin, useShortcut, pickHostFiles } from "@/shell/ui";
import { Glyph, AppIcon } from "@/shell/icons";
import { useStore } from "@/core/store";
import { os } from "@/core/os";

const clip = { paths: [] as string[], cut: false };
const FAV = "/Configuration/favorites.json";
const PLACES: [string, string, string][] = [["Desktop", "/Users/Default/Desktop", "desktops"], ["Documents", "/Users/Default/Documents", "file"], ["Downloads", "/Users/Default/Downloads", "download"], ["Music", "/Users/Default/Music", "media"], ["Videos", "/Users/Default/Videos", "play"], ["Pictures", "/Users/Default/Pictures", "gallery"], ["Projects", "/Users/Default/Projects", "developer"], ["Applications", "/Applications", "store"], ["Trash", "/Trash", "trash"]];

export const FILTERS: Record<PickerFilter, { label: string; test: (n: FsNode) => boolean }> = {
  all: { label: "All files", test: () => true },
  audio: { label: "Music files", test: (n) => kindOf(n.name) === "audio" },
  video: { label: "Video files", test: (n) => kindOf(n.name) === "video" },
  media: { label: "Music & video", test: (n) => ["audio", "video"].includes(kindOf(n.name)) },
  image: { label: "Images", test: (n) => kindOf(n.name) === "image" },
  document: { label: "Documents", test: (n) => kindOf(n.name) === "document" },
  archive: { label: "Archives", test: (n) => kindOf(n.name) === "archive" },
  app: { label: "Applications", test: (n) => kindOf(n.name) === "app" },
  wr: { label: ".wr and .wrapp", test: (n) => ["wr", "wrapp"].includes(extOf(n.name)) },
  user: { label: "User files", test: (n) => n.path.startsWith("/Users/") },
  code: { label: "Code & text", test: (n) => ["code", "document"].includes(kindOf(n.name)) },
};
const typeLabel = (n: FsNode) => (n.type === "dir" ? "Folder" : (extOf(n.name).toUpperCase() || "File") + " file");

export async function showProperties(n: FsNode) {
  let hash = "";
  if (n.type === "file" && n.size < 20_000_000) hash = "\nSHA-256: " + (await sha256Hex(await fs.readBytes(n.path)));
  await alertBox("Properties — " + n.name, `Path: ${n.path}\nType: ${typeLabel(n)} (${n.mime})\nSize: ${formatBytes(n.size)} (${n.size} bytes)\nCreated: ${new Date(n.created).toLocaleString()}\nModified: ${new Date(n.modified).toLocaleString()}${n.meta?.sourceUrl ? "\nSource: " + n.meta.sourceUrl : ""}${hash}`);
}
function useFavorites(): [string[], (p: string) => void] {
  const [f, reload] = useFs(() => fs.json<string[]>(FAV, []), [], [] as string[]);
  return [f, async (p: string) => { await fs.saveJson(FAV, f.includes(p) ? f.filter((x) => x !== p) : [...f, p]); reload(); }];
}

export interface BrowserProps { initial?: string; picker?: { reqId: string; opts: PickerOptions } }
export function FileBrowser({ initial = "/Users/Default", picker }: BrowserProps) {
  const win = useWin();
  const [hist, setHist] = useState<string[]>([initial]); const [hi, setHi] = useState(0);
  const path = hist[hi];
  const [view, setView] = useState<"dir" | "recent" | "favorites" | "search">("dir");
  const [q, setQ] = useState(""); const [sort, setSort] = useState<"name" | "modified" | "size" | "type">("name"); const [desc, setDesc] = useState(false);
  const [sel, setSel] = useState<string[]>([]); const [anchor, setAnchor] = useState("");
  const [filter, setFilter] = useState<PickerFilter>(picker?.opts.filter ?? "all");
  const [name, setName] = useState(picker?.opts.defaultName ?? "");
  const [favs, toggleFav] = useFavorites();
  const [addr, setAddr] = useState(path);
  useEffect(() => setAddr(path), [path]);
  const go = (p: string) => { setView("dir"); setQ(""); setSel([]); const n = hist.slice(0, hi + 1); n.push(norm(p)); setHist(n); setHi(n.length - 1); };
  useEffect(() => { if (!picker && win.params.path) { const p = String(win.params.path); fs.stat(p).then((n) => go(n.type === "dir" ? p : dirname(p))).catch(() => {}); } /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  useEffect(() => { if (!picker) setTitle(win.id, view === "dir" ? `Explorer — ${basename(path) || "NeuxFS"}` : `Explorer — ${view}`); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [path, view]);

  const [nodes, , loading, err] = useFs<FsNode[]>(async () => {
    if (view === "recent") return (await fs.all()).filter((n) => n.type === "file" && n.meta?.lastOpened).sort((a, b) => (b.meta!.lastOpened as number) - (a.meta!.lastOpened as number)).slice(0, 50);
    if (view === "favorites") { const out: FsNode[] = []; for (const p of favs) try { out.push(await fs.stat(p)); } catch { /* removed */ } return out; }
    if (view === "search") return q ? fs.search(q, path === "/Trash" ? "/Trash" : path) : [];
    return fs.list(path);
  }, [path, view, q, favs.join("|")], []);
  const list = useMemo(() => {
    const f = FILTERS[filter].test;
    const l = nodes.filter((n) => n.type === "dir" || f(n));
    const dir = desc ? -1 : 1;
    return l.sort((a, b) => { if (a.type !== b.type) return a.type === "dir" ? -1 : 1; const c = sort === "name" ? a.name.localeCompare(b.name, undefined, { numeric: true }) : sort === "modified" ? a.modified - b.modified : sort === "size" ? a.size - b.size : typeLabel(a).localeCompare(typeLabel(b)); return c * dir; });
  }, [nodes, sort, desc, filter]);

  const openNode = (n: FsNode) => {
    if (n.type === "dir") { if (n.path.startsWith("/Applications/") && dirname(n.path) === "/Applications") return void openApp("pkg", { pkgId: n.name }); return go(n.path); }
    if (picker) return void accept([n.path]);
    if (n.path.startsWith("/Trash/")) return void alertBox("In Trash", "Restore the item first to open it.");
    void openFile(n.path);
  };
  const compat = (n: FsNode) => { const f = picker?.opts.filter ?? "all"; return picker?.opts.mode === "folder" ? n.type === "dir" : n.type === "file" && FILTERS[f].test(n); };
  const accept = (paths: string[]) => { if (picker) { resolvePicker(picker.reqId, paths); closeWin(win.id, true); } };
  const pickOk = picker ? (picker.opts.mode === "save" ? !!name.trim() && view === "dir" : sel.length > 0 && sel.every((p) => { const n = nodes.find((x) => x.path === p); return n && compat(n); }) && (picker.opts.multiple || sel.length === 1)) : false;
  const selNodes = sel.map((p) => nodes.find((n) => n.path === p)).filter(Boolean) as FsNode[];

  const doPaste = async () => {
    if (!clip.paths.length) return;
    try { for (const s of clip.paths) { const dest = await fs.uniquePath(join(path, basename(s))); if (clip.cut) await fs.move(s, dest); else await fs.copy(s, dest); } if (clip.cut) clip.paths = []; } catch (e) { await alertBox("Paste failed", (e as Error).message); }
  };
  const doDelete = async (ns: FsNode[]) => {
    if (!ns.length) return;
    const inTrash = ns[0].path.startsWith("/Trash/");
    if (inTrash && !(await confirmBox("Delete permanently", `Permanently delete ${ns.length} item(s)? This cannot be undone.`, true, "Delete"))) return;
    try { for (const n of ns) await fs.trash(n.path); setSel([]); } catch (e) { await alertBox("Cannot delete", (e as Error).message); }
  };
  const doRename = async (n?: FsNode) => { if (!n) return; const nn = await promptBox("Rename", "New name", n.name); if (nn && nn !== n.name) try { await fs.rename(n.path, nn); } catch (e) { await alertBox("Rename failed", (e as Error).message); } };
  const newItem = async (dir: boolean) => { const nm = await promptBox(dir ? "New folder" : "New file", "Name", dir ? "New folder" : "Untitled.txt"); if (!nm) return; try { const p = await fs.uniquePath(join(path, nm)); if (dir) await fs.mkdir(p); else await fs.writeFile(p, ""); } catch (e) { await alertBox("Failed", (e as Error).message); } };
  const importHost = async () => { const files = await pickHostFiles("", true); if (!files.length) return; const added: string[] = []; for (const f of files) { const p = await fs.uniquePath(join(path.startsWith("/Users") ? path : "/Users/Default/Downloads", f.name)); await fs.writeFile(p, f); added.push(p); } notify({ title: "Imported", message: `${added.length} file(s) copied into NeuxFS from this device` }); setSel(added); };

  const menuFor = (n: FsNode | null) => (e: React.MouseEvent) => {
    if (n && !sel.includes(n.path)) setSel([n.path]);
    const cur = n ? (sel.includes(n.path) ? selNodes : [n]) : [];
    const inTrash = path.startsWith("/Trash");
    const items: MenuItem[] = [];
    if (n) {
      items.push({ label: "Open", action: () => openNode(n) });
      if (n.type === "file") {
        const apps = compatibleApps(n.name);
        items.push({ label: "Open with…", action: () => openApp("openwith", { path: n.path }), disabled: !apps.length && false });
        if (kindOf(n.name) === "audio" || kindOf(n.name) === "video") items.push({ label: "Add to playlist", action: () => openApp("media", { addToPlaylist: n.path }) });
        if (kindOf(n.name) === "image") items.push({ label: "Set as wallpaper", action: async () => { const { setSetting } = await import("@/core/settings"); setSetting("wallpaper", "fs:" + n.path); } });
        if (extOf(n.name) === "zip") items.push({ label: "Extract here", action: async () => { try { const c = await unarchive(fs, n.path); notify({ title: "Extracted", message: `${c} file(s)` }); } catch (er) { alertBox("Extract failed", (er as Error).message); } } });
        items.push({ label: "Inspect in Secure Center", action: () => openApp("secure", { tab: "inspect", path: n.path }) });
      }
      if (view !== "dir") items.push({ label: "Open file location", action: () => { go(dirname(n.path)); setSel([n.path]); } });
      items.push({ label: "", separator: true });
      if (!inTrash) items.push({ label: "Cut", action: () => { clip.paths = cur.map((x) => x.path); clip.cut = true; } }, { label: "Copy", action: () => { clip.paths = cur.map((x) => x.path); clip.cut = false; } });
      if (!inTrash) items.push({ label: "Rename", action: () => doRename(n) }, { label: favs.includes(n.path) ? "Remove from Favorites" : "Add to Favorites", action: () => toggleFav(n.path) }, { label: "Archive to .zip", action: async () => { try { const dest = await fs.uniquePath(join(dirname(n.path), (cur.length > 1 ? "Archive" : n.name) + ".zip")); const c = await archivePaths(fs, cur.map((x) => x.path), dest); notify({ title: "Archive created", message: `${basename(dest)} (${c} files)` }); } catch (er) { alertBox("Archive failed", (er as Error).message); } } });
      if (inTrash) items.push({ label: "Restore", action: async () => { for (const x of cur) try { await fs.restore(x.path); } catch (er) { alertBox("Restore failed", (er as Error).message); } } });
      items.push({ label: inTrash ? "Delete permanently" : "Move to Trash", danger: true, action: () => doDelete(cur) }, { label: "", separator: true }, { label: "Properties", action: () => showProperties(n) });
    } else {
      items.push({ label: "New folder", action: () => newItem(true) }, { label: "New file", action: () => newItem(false) }, { label: "Paste", disabled: !clip.paths.length, action: doPaste });
      if (inTrash) items.push({ label: "Empty Trash", danger: true, action: async () => { if (await confirmBox("Empty Trash", "Permanently delete everything in Trash?", true, "Empty")) await fs.emptyTrash(); } });
      items.push({ label: "Import files from this device…", action: importHost });
    }
    showMenu(e, items);
  };
  const onRow = (n: FsNode, e: React.MouseEvent) => {
    e.stopPropagation();
    if (e.shiftKey && anchor) { const a = list.findIndex((x) => x.path === anchor), b = list.findIndex((x) => x.path === n.path); setSel(list.slice(Math.min(a, b), Math.max(a, b) + 1).map((x) => x.path)); }
    else if (e.ctrlKey || e.metaKey) setSel(sel.includes(n.path) ? sel.filter((p) => p !== n.path) : [...sel, n.path]);
    else { setSel([n.path]); setAnchor(n.path); }
  };
  const focused = win.focused;
  useShortcut("gen.delete", () => { if (picker || !selNodes.length) return false; void doDelete(selNodes); }, [sel, nodes]);
  useShortcut("gen.rename", () => { if (picker || selNodes.length !== 1) return false; void doRename(selNodes[0]); }, [sel, nodes]);
  useShortcut("gen.open", () => { if (selNodes.length !== 1) return false; openNode(selNodes[0]); }, [sel, nodes]);
  const onKey = (e: React.KeyboardEvent) => {
    if ((e.target as HTMLElement).tagName === "INPUT") return;
    if (e.ctrlKey && e.key === "a") { e.preventDefault(); setSel(list.map((n) => n.path)); }
    else if (!picker && e.ctrlKey && (e.key === "c" || e.key === "x")) { clip.paths = sel; clip.cut = e.key === "x"; }
    else if (!picker && e.ctrlKey && e.key === "v") void doPaste();
    else if (e.key === "Backspace" || (e.altKey && e.key === "ArrowUp")) go(dirname(path));
    else if (e.key === "Enter" && selNodes.length === 1) openNode(selNodes[0]);
  };
  const th = (k: typeof sort, l: string) => <th onClick={() => { if (sort === k) setDesc(!desc); else { setSort(k); setDesc(false); } }} style={{ cursor: "pointer" }} aria-sort={sort === k ? (desc ? "descending" : "ascending") : "none"}>{l}{sort === k ? (desc ? " ▾" : " ▴") : ""}</th>;
  void focused;
  return (
    <div className="app" onKeyDown={onKey} tabIndex={-1} style={{ outline: "none" }}>
      <div className="sidebar">
        <button className={"side-item" + (view === "favorites" ? " active" : "")} onClick={() => { setView("favorites"); setSel([]); }}><Glyph name="star" size={16} />Favorites</button>
        <button className={"side-item" + (view === "recent" ? " active" : "")} onClick={() => { setView("recent"); setSel([]); }}><Glyph name="recovery" size={16} />Recent</button>
        <hr className="sep" />
        {PLACES.map(([l, p, g]) => <button key={p} className={"side-item" + (view === "dir" && path === p ? " active" : "")} onClick={() => go(p)} onDragOver={(e) => e.preventDefault()}><Glyph name={g} size={16} />{l}</button>)}
        <hr className="sep" /><button className={"side-item" + (view === "dir" && path === "/" ? " active" : "")} onClick={() => go("/")}><Glyph name="explorer" size={16} />NeuxFS root</button>
      </div>
      <div className="col grow" style={{ gap: 0 }}>
        <div className="toolbar">
          <button className="btn sm" aria-label="Back" disabled={hi === 0} onClick={() => setHi(hi - 1)}>←</button>
          <button className="btn sm" aria-label="Forward" disabled={hi >= hist.length - 1} onClick={() => setHi(hi + 1)}>→</button>
          <button className="btn sm" aria-label="Up" disabled={path === "/"} onClick={() => go(dirname(path))}>↑</button>
          <input className="input grow" style={{ minWidth: 120 }} value={addr} aria-label="Path" onChange={(e) => setAddr(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") fs.stat(addr).then((n) => (n.type === "dir" ? go(addr) : setAddr(path))).catch(() => alertBox("Not found", addr)); }} />
          <input className="input" style={{ width: 150 }} placeholder="Search here" value={q} aria-label="Search" onChange={(e) => { setQ(e.target.value); setView(e.target.value ? "search" : "dir"); }} />
          {!picker && <><button className="btn sm" onClick={() => newItem(true)}>+ Folder</button><button className="btn sm" onClick={() => newItem(false)}>+ File</button><button className="btn sm" onClick={importHost} title="Copies files from this device into NeuxFS (explicit import)">Import…</button></>}
        </div>
        <div className="scroll grow" onClick={() => setSel([])} onContextMenu={menuFor(null)}>
          {err ? <div style={{ padding: 20, color: "var(--danger)" }}>{err}</div> : loading && !nodes.length ? <div style={{ padding: 20 }}><span className="spinner" /></div> : list.length === 0 ? <div className="dim" style={{ padding: 30, textAlign: "center" }}>{view === "search" ? "No matches." : view === "recent" ? "No recently opened files yet." : view === "favorites" ? "No favorites. Right-click an item → Add to Favorites." : "This folder is empty."}</div> : (
            <table className="tbl"><thead><tr>{th("name", "Name")}{th("modified", "Modified")}{th("type", "Type")}{th("size", "Size")}</tr></thead>
              <tbody>{list.map((n) => (
                <tr key={n.path} className={"frow" + (sel.includes(n.path) ? " sel" : "")} style={{ display: "table-row", opacity: picker && n.type === "file" && !compat(n) ? 0.5 : 1 }} onClick={(e) => onRow(n, e)} onDoubleClick={() => openNode(n)} onContextMenu={(e) => menuFor(n)(e)} draggable onDragStart={(e) => e.dataTransfer.setData("text/neux-path", n.path)}>
                  <td><span className="row">{view === "dir" && path === "/Applications" && n.type === "dir" ? <AppIcon id={"pkg:" + n.name} size={20} /> : <FileGlyph node={n} />}<span>{n.name}</span>{favs.includes(n.path) && <span style={{ color: "var(--warn)" }}>★</span>}</span></td>
                  <td className="dim">{new Date(n.modified).toLocaleString()}</td><td className="dim">{typeLabel(n)}</td><td className="dim">{n.type === "dir" ? "" : formatBytes(n.size)}</td></tr>))}</tbody></table>)}
        </div>
        <div className="toolbar" style={{ borderTop: "1px solid var(--border)", borderBottom: 0 }}>
          <span className="dim small grow">{list.length} item(s){sel.length ? ` · ${sel.length} selected` : ""}{view === "dir" && path !== "/" ? " · " + path : ""}</span>
          {picker && <>
            {picker.opts.mode === "save" && <input className="input" style={{ width: 200 }} value={name} onChange={(e) => setName(e.target.value)} placeholder="File name" aria-label="File name" />}
            <select className="input" style={{ width: 160 }} value={filter} onChange={(e) => setFilter(e.target.value as PickerFilter)} aria-label="File type filter">{(Object.keys(FILTERS) as PickerFilter[]).map((k) => <option key={k} value={k}>{FILTERS[k].label}</option>)}</select>
            <button className="btn" onClick={() => { resolvePicker(picker.reqId, null); closeWin(win.id, true); }}>Cancel</button>
            <button className="btn primary" disabled={!pickOk} onClick={() => accept(picker.opts.mode === "save" ? [join(path, name.trim())] : picker.opts.mode === "folder" && !sel.length ? [path] : sel)}>{picker.opts.mode === "save" ? "Save" : "Open"}</button></>}
        </div>
      </div>
    </div>
  );
}
export function Explorer() { return <FileBrowser initial="/Users/Default" />; }
export function FilePickerApp() {
  const { params } = useWin();
  const reqId = String(params.reqId); const opts = pickerOptions.get(reqId);
  useEffect(() => { /* title */ }, []);
  if (!opts) return <div style={{ padding: 20 }}>This file request is no longer active.</div>;
  return <FileBrowser picker={{ reqId, opts }} initial={opts.startPath ?? (opts.filter === "audio" ? "/Users/Default/Music" : opts.filter === "video" ? "/Users/Default/Videos" : opts.filter === "image" ? "/Users/Default/Pictures" : "/Users/Default")} />;
}
export function OpenWith() {
  const { params, id } = useWin(); const path = String(params.path ?? ""); const name = basename(path);
  const apps = compatibleApps(name); const [always, setAlways] = useState(false);
  const all = BUILTIN.filter((b) => !b.system || ["secure"].includes(b.id));
  const unknown = !defaultAppFor(name) && !apps.length;
  return (
    <div className="col" style={{ padding: 16, height: "100%" }}>
      <b>{unknown ? "Unknown file type" : "Open with"}</b>
      <div className="dim small">{unknown ? `Neux does not know how to open “${name}” (.${extOf(name) || "no extension"}) and will never run an unknown file automatically. Choose a compatible app to view it, or inspect it safely.` : name}</div>
      <div className="scroll grow col" style={{ gap: 2 }}>
        {(apps.length ? apps : []).map((a) => <button key={a} className="side-item" onClick={() => { if (always) setAssociation(extOf(name), a); void openFile(path, a); closeWin(id, true); }}><AppIcon id={a} size={28} />{BUILTIN.find((b) => b.id === a)?.name}</button>)}
        {unknown && <><div className="dim small">View as text (read-only, safe):</div><button className="side-item" onClick={() => { void openFile(path, "texteditor"); closeWin(id, true); }}><AppIcon id="texteditor" size={28} />Text Editor</button></>}
        <button className="side-item" onClick={() => { openApp("secure", { tab: "inspect", path }); closeWin(id, true); }}><AppIcon id="secure" size={28} />Inspect in Secure Center</button>
        <details><summary className="dim small" style={{ cursor: "pointer", padding: 6 }}>All apps (may not understand this file)</summary>{all.map((a) => <button key={a.id} className="side-item" onClick={() => { void openFile(path, a.id); closeWin(id, true); }}><AppIcon id={a.id} size={24} />{a.name}</button>)}</details>
      </div>
      {!unknown && <label className="row small"><input type="checkbox" checked={always} onChange={(e) => setAlways(e.target.checked)} />Always use this app for .{extOf(name)} files</label>}
    </div>
  );
}
void useStore; void os; void useRef;
