"use client";
import type { ComponentType } from "react";
import { Explorer, FilePickerApp, OpenWith } from "./explorer";
import Settings from "./settings";
import Store, { Installer, PkgApp, AppBuilder } from "./store";
import Browser from "./browser";
import Media from "./media";
import Photo from "./photo";
import Developer, { ConsoleApp, Runtime } from "./dev";
import { SecureCenter, Recovery, TaskManager, SysMonitor, Diagnostics, Backup, Themes, WidgetsApp } from "./system";
import { Calculator, Calendar, Notes, Gallery, TextEditor, Screenshot, Archive, Share, PdfViewer } from "./utils";
import { BeecoApp, VpnApp } from "./network";

const MAP: Record<string, ComponentType> = {
  explorer: Explorer, picker: FilePickerApp, openwith: OpenWith, settings: Settings, store: Store, installer: Installer, pkg: PkgApp, appbuilder: AppBuilder,
  browser: Browser, media: Media, photo: Photo, developer: Developer, console: ConsoleApp, runtime: Runtime, secure: SecureCenter, recovery: Recovery,
  taskmanager: TaskManager, sysmonitor: SysMonitor, diagnostics: Diagnostics, backup: Backup, themes: Themes, widgets: WidgetsApp,
  calculator: Calculator, calendar: Calendar, notes: Notes, gallery: Gallery, texteditor: TextEditor, screenshot: Screenshot, archive: Archive, share: Share, pdf: PdfViewer,
  beeco: BeecoApp, vpn: VpnApp,
};
export function AppView({ appId }: { appId: string }) {
  const C = MAP[appId];
  return C ? <C /> : <div style={{ padding: 20 }}>Unknown application “{appId}”.</div>;
}
