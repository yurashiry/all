"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { useWin, useShortcut, useFs, Empty, pickHostFiles } from "@/shell/ui";
import { basename, dirname, join, type FsNode } from "@/core/filesystem/neuxfs";
import { extOf, formatBytes } from "@/core/util";
import { promptBox, alertBox, pickFile, notify, openApp, confirmBox, setCloseGuard, setTitle } from "@/core/os";
import { compileNxl, runNxl, serializeBytecode, disassemble, NxlError, NXL_VERSION } from "@/nxl";
import { VM } from "@/nxl/runtime/vm";
import { neuxHost } from "@/nxl/sdk";
import { execute, tokenize, commands, type ConsoleCtx } from "@/core/runtime/console";
import { consoleBus, takePendingConsole } from "@/core/api";
import { useStore } from "@/core/store";
import { os } from "@/core/os";
import { unarchive } from "@/core/filesystem/archive";
import { startLoopback, net } from "@/core/networking/status";
import { buildWrapp, installFromBytes } from "@/core/applications/wrapp";

const KW: Record<string, string[]> = {
  js: ["const", "let", "var", "function", "return", "if", "else", "for", "while", "class", "new", "import", "export", "from", "async", "await", "try", "catch", "throw", "true", "false", "null", "undefined", "this", "switch", "case", "break", "continue", "typeof"],
  nxl: ["let", "const", "fn", "if", "else", "while", "for", "in", "return", "true", "false", "null", "struct", "import", "try", "catch", "throw", "break", "continue", "and", "or", "not", "async", "await"],
};
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
export function highlight(code: string, lang: string): string {
  const L = lang === "wr" ? "nxl" : lang === "mjs" || lang === "json" ? "js" : lang;
  if (L === "html" || L === "htm") return esc(code).replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<i style="color:#7a8aa6">$1</i>').replace(/(&lt;\/?)([\w-]+)/g, '$1<b style="color:#ff7b9c;font-weight:400">$2</b>').replace(/([\w-]+)=(&quot;|")/g, '<span style="color:#ffd479">$1</span>=$2');
  const kw = KW[L] ?? []; const re = new RegExp(`(\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)|("(?:[^"\\\\\\n]|\\\\.)*"|'(?:[^'\\\\\\n]|\\\\.)*'|\`[^\`]*\`)|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b(?:${kw.join("|") || "$^"})\\b)|(\\b[A-Za-z_-]+(?=\\s*:))`, "g");
  return esc(code).replace(re, (m, c, s, n, k, p) => (c ? `<i style="color:#7a8aa6">${m}</i>` : s ? `<span style="color:#9be39b">${m}</span>` : n ? `<span style="color:#ffb86c">${m}</span>` : k ? `<b style="color:#c792ea;font-weight:400">${m}</b>` : L === "css" && p ? `<span style="color:#82aaff">${m}</span>` : m));
}
const TEMPLATES: Record<string, Record<string, string>> = {
  "Web (HTML/CSS/JS)": { "index.html": '<!doctype html>\n<html>\n<head>\n  <meta charset="utf-8">\n  <title>My page</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <h1 id="title">Hello Neux</h1>\n  <button id="b">Click</button>\n  <script src="app.js"></script>\n</body>\n</html>\n', "style.css": "body { font-family: system-ui, sans-serif; padding: 2rem; }\nbutton { padding: .5rem 1rem; }\n", "app.js": 'document.getElementById("b").onclick = () => {\n  document.getElementById("title").textContent = "Clicked at " + new Date().toLocaleTimeString();\n};\n' },
  "NXL program": { "main.nxl": 'fn fib(n: int) -> int {\n  if n < 2 { return n }\n  return fib(n - 1) + fib(n - 2)\n}\n\nlet total = 0\nfor i in range(10) {\n  total += fib(i)\n  print("fib({i}) = {fib(i)}")\n}\nprint("sum: {total}")\n' },
};
interface OpenFile { path: string; text: string; saved: string }

export default function Developer() {
  const win = useWin(); const [project, setProject] = useState(""); const [open, setOpen] = useState<OpenFile[]>([]); const [active, setActive] = useState(""); const [sidebar, setSidebar] = useState(true);
  const [projects, reloadProjects] = useFs(async () => (await fs.list("/Users/Default/Projects")).filter((n) => n.type === "dir"), [], [] as FsNode[]);
  const [tree] = useFs(async () => { if (!project) return []; return (await fs.all()).filter((n) => n.type === "file" && n.path.startsWith(project + "/")).sort((a, b) => a.path.localeCompare(b.path)); }, [project], [] as FsNode[]);
  const [out, setOut] = useState<{ t: "log" | "err" | "info"; s: string }[]>([]); const [bottom, setBottom] = useState<"output" | "preview" | "terminal" | "none">("none"); const [preview, setPreview] = useState(""); const [palette, setPalette] = useState(false); const [pq, setPq] = useState("");
  const [find, setFind] = useState(false); const [fq, setFq] = useState(""); const [rq, setRq] = useState(""); const [running, setRunning] = useState(false); const vm = useRef<VM | null>(null);
  const ta = useRef<HTMLTextAreaElement>(null); const pre = useRef<HTMLPreElement>(null); const file = open.find((f) => f.path === active); const dirty = open.some((f) => f.text !== f.saved);
  const log = (t: "log" | "err" | "info", s: string) => setOut((o) => [...o.slice(-500), { t, s }]);
  useEffect(() => { setCloseGuard(win.id, () => !dirty || confirm("Unsaved changes in Developer. Close anyway?")); return () => setCloseGuard(win.id, null); }, [dirty, win.id]);
  const openFile = useCallback(async (p: string) => { if (!open.some((f) => f.path === p)) { try { const t = await fs.readText(p); setOpen((o) => [...o, { path: p, text: t, saved: t }]); } catch (e) { return void alertBox("Cannot open", (e as Error).message); } } setActive(p); }, [open]);
  useEffect(() => { const p = win.params.path as string | undefined; if (p) { setProject(dirname(p).startsWith("/Users/Default/Projects") ? dirname(p) : ""); void openFile(p); } /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  useEffect(() => { setTitle(win.id, "Developer" + (project ? " — " + basename(project) : "")); }, [project, win.id]);
  const edit = (t: string) => setOpen((o) => o.map((f) => (f.path === active ? { ...f, text: t } : f)));
  const save = async () => { if (!file) return; await fs.writeFile(file.path, file.text); setOpen((o) => o.map((f) => (f.path === file.path ? { ...f, saved: f.text } : f))); };
  const saveAll = async () => { for (const f of open) if (f.text !== f.saved) await fs.writeFile(f.path, f.text); setOpen((o) => o.map((f) => ({ ...f, saved: f.text }))); };
  const newProject = async () => { const names = Object.keys(TEMPLATES); const t = await promptBox("New project", `Template (${names.join(" / ")})`, names[0]); if (!t || !TEMPLATES[t]) return; const n = await promptBox("Project name", "Name", "my-project"); if (!n) return; const root = await fs.uniquePath(join("/Users/Default/Projects", n)); for (const [f, c] of Object.entries(TEMPLATES[t])) await fs.writeFile(join(root, f), c); setProject(root); reloadProjects(); await openFile(join(root, Object.keys(TEMPLATES[t])[0])); };
  const newFile = async () => { const base = project || "/Users/Default/Projects"; const n = await promptBox("New file", "File name", "untitled.nxl"); if (!n) return; const p = await fs.uniquePath(join(base, n)); await fs.writeFile(p, ""); await openFile(p); };
  const importZip = async () => { const [f] = await pickHostFiles(".zip"); if (!f) return; try { const tmp = await fs.uniquePath("/Temporary/" + f.name); await fs.writeFile(tmp, f); const dest = await fs.uniquePath(join("/Users/Default/Projects", f.name.replace(/\.zip$/i, ""))); const n = await unarchive(fs, tmp, dest); await fs.remove(tmp, { role: "root" }); setProject(dest); notify({ title: "ZIP imported", message: `${n} file(s) → ${dest}` }); } catch (e) { alertBox("Import failed", (e as Error).message); } };
  const stop = () => { vm.current?.stop(); setPreview(""); setRunning(false); };
  const run = useCallback(async () => {
    if (!file) return; await saveAll(); const ext = extOf(file.path); setOut([]); 
    if (ext === "nxl" || ext === "wr") {
      setBottom("output"); setRunning(true); log("info", `NXL ${NXL_VERSION} — running ${basename(file.path)}`);
      try { const bc = compileNxl(file.text); const v = new VM(bc, neuxHost((s) => log("log", s), dirname(file.path))); vm.current = v; await v.run(); log("info", `Finished (${v.steps} VM steps)`); }
      catch (e) { log("err", e instanceof NxlError || e instanceof Error ? e.message : String(e)); }
      setRunning(false); return;
    }
    if (["html", "htm", "css", "js"].includes(ext)) {
      const dir = dirname(file.path); const entry = ext === "html" || ext === "htm" ? file.path : join(dir, "index.html");
      if (!(await fs.exists(entry))) return void log("err", "No index.html next to this file to preview.");
      let html = open.find((f) => f.path === entry)?.text ?? (await fs.readText(entry));
      for (const m of [...html.matchAll(/<link[^>]+href="([^":]+\.css)"[^>]*>/g)]) { try { html = html.replace(m[0], `<style>${open.find((f) => f.path === join(dir, m[1]))?.text ?? (await fs.readText(join(dir, m[1])))}</style>`); } catch { log("err", "Missing " + m[1]); } }
      for (const m of [...html.matchAll(/<script[^>]+src="([^":]+\.js)"[^>]*><\/script>/g)]) { try { html = html.replace(m[0], `<script>${(open.find((f) => f.path === join(dir, m[1]))?.text ?? (await fs.readText(join(dir, m[1])))).replace(/<\/script/gi, "<\\/script")}</script>`); } catch { log("err", "Missing " + m[1]); } }
      const hook = `<script>addEventListener("error",e=>parent.postMessage({neuxDev:1,t:"err",s:e.message+" (line "+e.lineno+")"},"*"));addEventListener("unhandledrejection",e=>parent.postMessage({neuxDev:1,t:"err",s:"Unhandled rejection: "+e.reason},"*"));const _l=console.log;console.log=(...a)=>{parent.postMessage({neuxDev:1,t:"log",s:a.join(" ")},"*");_l(...a)};</script>`;
      setPreview(hook + html); setBottom("preview"); log("info", "Preview started in a sandboxed frame (no network server)."); return;
    }
    log("err", `Don't know how to run .${ext} files. Run .nxl/.wr programs or HTML projects.`); setBottom("output");
  }, [file, open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { const h = (e: MessageEvent) => { if (e.data?.neuxDev) { log(e.data.t, e.data.s); } }; window.addEventListener("message", h); return () => window.removeEventListener("message", h); }, []);
  const comment = () => { const t = ta.current; if (!t || !file) return; const ext = extOf(file.path); const c = ["nxl", "wr", "js", "json"].includes(ext) ? "//" : ext === "css" ? "/*" : "<!--"; const v = t.value, s = v.lastIndexOf("\n", t.selectionStart - 1) + 1; let e = v.indexOf("\n", t.selectionEnd); if (e < 0) e = v.length; const lines = v.slice(s, e).split("\n"); const all = lines.every((l) => l.trim().startsWith(c)); const nl = lines.map((l) => (all ? l.replace(c + " ", "").replace(c, "").replace(/ ?(\*\/|-->)$/, "") : c === "//" ? "// " + l : c === "/*" ? "/* " + l + " */" : "<!-- " + l + " -->")); edit(v.slice(0, s) + nl.join("\n") + v.slice(e)); };
  useShortcut("dev.newFile", newFile, [project]); useShortcut("dev.newProject", newProject, []); useShortcut("dev.comment", comment, [file]); useShortcut("dev.palette", () => { setPalette(true); setPq(""); }, []); useShortcut("dev.sidebar", () => setSidebar((s) => !s), []);
  useShortcut("dev.run", run, [run]); useShortcut("dev.stop", stop, []); useShortcut("dev.tools", () => setBottom((b) => (b === "none" ? "output" : "none")), []); useShortcut("gen.save", save, [file]); useShortcut("gen.saveAs", async () => { if (!file) return; const p = await pickFile({ mode: "save", startPath: dirname(file.path), defaultName: basename(file.path) }); if (p) { await fs.writeFile(p[0], file.text); await openFile(p[0]); } }, [file]); useShortcut("win.closeTab", () => { if (!active) return false; setOpen((o) => o.filter((f) => f.path !== active)); setActive(open.find((f) => f.path !== active)?.path ?? ""); }, [active, open]);
  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const t = e.currentTarget;
    if (e.key === "Tab") { e.preventDefault(); const s = t.selectionStart; edit(t.value.slice(0, s) + "  " + t.value.slice(t.selectionEnd)); requestAnimationFrame(() => (t.selectionStart = t.selectionEnd = s + 2)); }
    if (e.key === "Enter" && !e.ctrlKey) { e.preventDefault(); const s = t.selectionStart, ls = t.value.lastIndexOf("\n", s - 1) + 1, line = t.value.slice(ls, s), ind = line.match(/^\s*/)![0] + (/[{(\[:]\s*$/.test(line) ? "  " : ""); const closing = /[{(\[]$/.test(line) && /^[})\]]/.test(t.value.slice(s)) ? "\n" + line.match(/^\s*/)![0] : ""; edit(t.value.slice(0, s) + "\n" + ind + closing + t.value.slice(t.selectionEnd)); requestAnimationFrame(() => (t.selectionStart = t.selectionEnd = s + 1 + ind.length)); }
  };
  const doFind = (next = true) => { const t = ta.current; if (!t || !fq) return; const i = next ? t.value.indexOf(fq, t.selectionEnd) : t.value.lastIndexOf(fq, t.selectionStart - 1); const j = i < 0 ? (next ? t.value.indexOf(fq) : t.value.lastIndexOf(fq)) : i; if (j >= 0) { t.focus(); t.setSelectionRange(j, j + fq.length); } };
  useShortcut("browser.find", () => false, []);
  useEffect(() => { const h = (e: KeyboardEvent) => { if (win.focused && e.ctrlKey && (e.key === "f" || e.key === "h") && ta.current && document.activeElement === ta.current) { e.preventDefault(); e.stopPropagation(); setFind(true); } }; window.addEventListener("keydown", h, true); return () => window.removeEventListener("keydown", h, true); }, [win.focused]);
  const cmds: [string, () => void][] = [["Run (F5)", run], ["Stop (Shift+F5)", stop], ["Save", save], ["Save all", saveAll], ["New file", newFile], ["New project", newProject], ["Import ZIP project…", importZip], ["Toggle sidebar", () => setSidebar((s) => !s)], ["Find / replace", () => setFind(true)], ["Disassemble NXL bytecode", () => { if (!file) return; try { setOut([{ t: "log", s: disassemble(compileNxl(file.text)) }]); setBottom("output"); } catch (e) { log("err", (e as Error).message); setBottom("output"); } }], ["Build NXL → .nxb", async () => { if (!file) return; try { const bc = compileNxl(file.text); const d = file.path.replace(/\.[^.]+$/, "") + ".nxb"; await fs.writeFile(d, serializeBytecode(bc)); log("info", `Wrote ${d}`); setBottom("output"); } catch (e) { log("err", (e as Error).message); setBottom("output"); } }], ["Package project as .wrapp (HTML app)", async () => { if (!project) return; try { const files: Record<string, string> = {}; for (const f of tree) files[f.path.slice(project.length + 1)] = await fs.readText(f.path); const name = basename(project); const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "-"); files["manifest.json"] ??= JSON.stringify({ id, name, version: "1.0.0", category: "Utilities", description: "Built with Neux Developer", publisher: "Local user", type: "html", entry: "index.html", icon: "assets/icon.svg", permissions: [], window: { width: 800, height: 560 }, compat: { platforms: ["web"] } }); files["assets/icon.svg"] ??= `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" rx="22" fill="#5b8cff"/><text x="48" y="62" font-size="42" text-anchor="middle" fill="#fff" font-family="Arial">${name[0]?.toUpperCase()}</text></svg>`; const bytes = buildWrapp(files); const p = await fs.uniquePath(`/Users/Default/Documents/${id}.wrapp`); await fs.writeFile(p, bytes); log("info", `Built ${p} (${formatBytes(bytes.length)}). Install it with App Builder / Package Installer.`); setBottom("output"); const y = await confirmBox("Install now?", `Install ${name} as a local app?`); if (y) await installFromBytes(bytes, "Developer"); } catch (e) { log("err", (e as Error).message); setBottom("output"); } }], ["Local server (localhost:8080)", () => { log("err", "The Web edition cannot bind http://localhost:8080 — browsers cannot open listening sockets. Use Preview (sandboxed iframe) instead. Native editions can host a real local server."); setBottom("output"); }], ["BEECO Local (in-page loopback)", async () => { try { await startLoopback(); log("info", "BEECO Local loopback session established (no network traffic)."); } catch (e) { log("err", (e as Error).message); } setBottom("output"); }], ["BEECO Network…", () => openApp("beeco")]];
  const shown = cmds.filter(([n]) => n.toLowerCase().includes(pq.toLowerCase()));
  const lang = file ? extOf(file.path) : "";
  const lines = (file?.text.split("\n").length ?? 1);
  const beeco = useStore(net, (s) => s.beeco.state);
  return (
    <div className="col" style={{ height: "100%", gap: 0 }}>
      <div className="toolbar"><button className="btn sm" onClick={() => setSidebar(!sidebar)} aria-label="Toggle sidebar">☰</button><button className="btn sm primary" disabled={!file || running} onClick={run}>▶ Run</button><button className="btn sm" disabled={!running && !preview} onClick={stop}>■ Stop</button><button className="btn sm" onClick={save} disabled={!file}>Save</button><button className="btn sm" onClick={() => setFind(!find)}>Find</button><button className="btn sm" onClick={() => { setPalette(true); setPq(""); }}>Commands</button><span className="grow" /><span className="dim small">BEECO: {beeco}</span></div>
      <div className="row grow" style={{ alignItems: "stretch", gap: 0, minHeight: 0 }}>
        {sidebar && <div className="sidebar" style={{ width: 200 }}>
          <div className="row"><b className="small grow">Projects</b><button className="btn sm ghost" onClick={newProject} aria-label="New project">+</button><button className="btn sm ghost" onClick={importZip} title="Import ZIP">⇪</button></div>
          {projects.map((p) => <button key={p.path} className={"side-item" + (project === p.path ? " active" : "")} onClick={() => setProject(p.path)}>{p.name}</button>)}{!projects.length && <div className="dim small">No projects. Create one with +.</div>}
          {project && <><hr className="sep" /><div className="row"><b className="small grow">{basename(project)}</b><button className="btn sm ghost" onClick={newFile}>+</button></div>{tree.map((f) => <button key={f.path} className={"side-item small" + (active === f.path ? " active" : "")} onClick={() => openFile(f.path)} onContextMenu={async (e) => { e.preventDefault(); if (await confirmBox("Delete file", `Move ${f.name} to Trash?`, true, "Trash")) { await fs.trash(f.path); setOpen((o) => o.filter((x) => x.path !== f.path)); } }} title="Right-click to delete">{f.path.slice(project.length + 1)}</button>)}</>}</div>}
        <div className="col grow" style={{ gap: 0, minWidth: 0 }}>
          <div className="tabbar">{open.map((f) => <button key={f.path} className={"tab" + (f.path === active ? " active" : "")} onClick={() => setActive(f.path)}>{basename(f.path)}{f.text !== f.saved ? " ●" : ""}<span role="button" aria-label="Close file" onClick={(e) => { e.stopPropagation(); if (f.text !== f.saved && !confirm("Discard unsaved changes?")) return; setOpen((o) => o.filter((x) => x.path !== f.path)); if (active === f.path) setActive(open.find((x) => x.path !== f.path)?.path ?? ""); }}>×</span></button>)}</div>
          {find && file && <div className="toolbar"><input className="input" style={{ width: 160 }} placeholder="Find" value={fq} onChange={(e) => setFq(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doFind(!e.shiftKey)} aria-label="Find" autoFocus /><button className="btn sm" onClick={() => doFind(false)}>↑</button><button className="btn sm" onClick={() => doFind(true)}>↓</button><input className="input" style={{ width: 160 }} placeholder="Replace" value={rq} onChange={(e) => setRq(e.target.value)} aria-label="Replace" /><button className="btn sm" onClick={() => { const t = ta.current; if (t && fq && t.value.slice(t.selectionStart, t.selectionEnd) === fq) { edit(t.value.slice(0, t.selectionStart) + rq + t.value.slice(t.selectionEnd)); } doFind(true); }}>Replace</button><button className="btn sm" onClick={() => fq && edit(file.text.split(fq).join(rq))}>Replace all</button><span className="dim small">{fq ? file.text.split(fq).length - 1 : 0} match(es)</span><button className="btn sm ghost" onClick={() => setFind(false)}>×</button></div>}
          <div className="grow" style={{ position: "relative", minHeight: 0, background: "#0b0e16", color: "#e6e9f2" }}>
            {file ? <div style={{ position: "absolute", inset: 0, display: "flex", overflow: "hidden" }}>
              <div className="mono small" aria-hidden style={{ padding: "10px 8px", textAlign: "right", color: "#667", userSelect: "none", lineHeight: "20px", background: "#0a0c13", overflow: "hidden", whiteSpace: "pre" }} id="gutter">{Array.from({ length: lines }, (_, i) => i + 1).join("\n")}</div>
              <div style={{ position: "relative", flex: 1, minWidth: 0 }}>
                <pre ref={pre} aria-hidden className="mono" style={{ position: "absolute", inset: 0, margin: 0, padding: 10, lineHeight: "20px", fontSize: 13, overflow: "hidden", whiteSpace: "pre", pointerEvents: "none", tabSize: 2 }} dangerouslySetInnerHTML={{ __html: highlight(file.text, lang) + "\n" }} />
                <textarea ref={ta} className="mono" value={file.text} onChange={(e) => edit(e.target.value)} onKeyDown={onKey} spellCheck={false} aria-label={`Editor: ${basename(file.path)}`} wrap="off"
                  onScroll={(e) => { const t = e.currentTarget; if (pre.current) { pre.current.scrollTop = t.scrollTop; pre.current.scrollLeft = t.scrollLeft; } const g = document.getElementById("gutter"); if (g) g.scrollTop = t.scrollTop; }}
                  style={{ position: "absolute", inset: 0, width: "100%", height: "100%", padding: 10, lineHeight: "20px", fontSize: 13, background: "transparent", color: "transparent", caretColor: "#fff", border: 0, outline: 0, resize: "none", whiteSpace: "pre", overflow: "auto", tabSize: 2 }} />
              </div></div> : <Empty>Create or open a project. Supports HTML, CSS, JavaScript and NXL (.nxl / .wr).</Empty>}
          </div>
          {bottom !== "none" && <div className="col" style={{ height: 230, borderTop: "1px solid var(--border)", gap: 0 }}>
            <div className="tabbar">{(["output", "preview", "terminal"] as const).map((b) => <button key={b} className={"tab" + (bottom === b ? " active" : "")} onClick={() => setBottom(b)}>{b}</button>)}<span className="grow" /><button className="btn sm ghost" onClick={() => setOut([])}>Clear</button><button className="btn sm ghost" onClick={() => setBottom("none")} aria-label="Close panel">×</button></div>
            <div className="grow" style={{ minHeight: 0 }}>
              {bottom === "output" && <div className="term scroll" role="log">{out.length === 0 ? <span style={{ opacity: 0.5 }}>Output & errors appear here.</span> : out.map((o, i) => <div key={i} style={{ color: o.t === "err" ? "#ff7b7b" : o.t === "info" ? "#7aa2ff" : undefined }}>{o.s}</div>)}</div>}
              {bottom === "preview" && (preview ? <iframe title="Preview" srcDoc={preview} sandbox="allow-scripts allow-modals" style={{ width: "100%", height: "100%", border: 0, background: "#fff" }} /> : <Empty>Run an HTML file to preview it.</Empty>)}
              {bottom === "terminal" && <ConsoleView cwd={project || "/Users/Default"} />}
            </div></div>}
        </div>
      </div>
      {palette && <div className="modal-bg" onClick={() => setPalette(false)}><div className="modal glass col" onClick={(e) => e.stopPropagation()} style={{ width: 520 }} role="dialog" aria-label="Command palette"><input className="input" autoFocus placeholder="Type a command…" value={pq} onChange={(e) => setPq(e.target.value)} onKeyDown={(e) => { if (e.key === "Escape") setPalette(false); if (e.key === "Enter" && shown[0]) { setPalette(false); shown[0][1](); } }} aria-label="Command" /><div className="scroll" style={{ maxHeight: 300 }}>{shown.map(([n, f]) => <button key={n} className="side-item" onClick={() => { setPalette(false); f(); }}>{n}</button>)}</div></div></div>}
    </div>
  );
}

export function ConsoleView({ cwd = "/Users/Default", initial }: { cwd?: string; initial?: boolean }) {
  const user = useStore(os, (s) => s.user); const ctx = useRef<ConsoleCtx>({ cwd, role: user?.role ?? "user", env: {}, user: user?.name ?? "guest" });
  ctx.current.role = user?.role ?? "user"; ctx.current.user = user?.name ?? "guest";
  const [lines, setLines] = useState<string[]>(["Neux Console — type 'help'. Commands run real operations on NeuxFS and Neux services.", ""]); const [input, setInput] = useState(""); const hist = useRef<string[]>([]); const hp = useRef(-1); const end = useRef<HTMLDivElement>(null); const [prompt, setPrompt] = useState(cwd); const inp = useRef<HTMLInputElement>(null);
  const print = useCallback((s: string) => setLines((l) => [...l.slice(-1500), ...String(s).split("\n")]), []);
  const exec = useCallback(async (line: string) => { print(`${ctx.current.user}@neux:${ctx.current.cwd}$ ${line}`); if (line.trim() === "clear") { setLines([]); return; } hist.current.push(line); hp.current = -1; await execute(line, ctx.current, print); setPrompt(ctx.current.cwd); }, [print]);
  useEffect(() => { consoleBus.type = (s) => { setInput(s); inp.current?.focus(); }; consoleBus.exec = (s) => void exec(s); const p = takePendingConsole(); if (p.cmd) setInput(p.cmd); if (p.run) void exec(p.run); void initial; return () => { consoleBus.type = undefined; consoleBus.exec = undefined; }; }, [exec, initial]);
  useEffect(() => { end.current?.scrollIntoView(); }, [lines]);
  const complete = () => { const t = input; const toks = t.split(" "); if (toks.length === 1) { const m = commands().map((c) => c.name).filter((n) => n.startsWith(t)); if (m.length === 1) setInput(m[0] + " "); else if (m.length) print(m.join("   ")); } else { const last = toks[toks.length - 1]; const dir = last.includes("/") ? last.slice(0, last.lastIndexOf("/") + 1) : ""; fs.list(dir ? (dir.startsWith("/") ? dir : join(ctx.current.cwd, dir)) : ctx.current.cwd).then((l) => { const m = l.filter((n) => n.name.startsWith(last.slice(dir.length))); if (m.length === 1) setInput([...toks.slice(0, -1), dir + m[0].name + (m[0].type === "dir" ? "/" : "")].join(" ")); else if (m.length) print(m.map((n) => n.name).join("   ")); }).catch(() => {}); } };
  void tokenize;
  return (
    <div className="term" style={{ display: "flex", flexDirection: "column", padding: 0 }} onClick={() => inp.current?.focus()}>
      <div className="scroll grow" style={{ padding: 10 }} role="log" aria-live="polite">{lines.map((l, i) => <div key={i} style={{ minHeight: "1.2em" }}>{l}</div>)}<div ref={end} /></div>
      <div className="row" style={{ padding: "6px 10px", borderTop: "1px solid #1c2233" }}><span style={{ color: "#7aa2ff" }}>{user?.name ?? "guest"}@neux:{prompt}$</span><input ref={inp} autoFocus value={input} onChange={(e) => setInput(e.target.value)} aria-label="Console input" spellCheck={false} autoCapitalize="off" autoComplete="off" style={{ flex: 1, background: "transparent", border: 0, outline: 0, color: "inherit", font: "inherit" }}
        onKeyDown={(e) => { if (e.key === "Enter") { const v = input; setInput(""); void exec(v); } else if (e.key === "ArrowUp") { e.preventDefault(); if (hist.current.length) { hp.current = hp.current < 0 ? hist.current.length - 1 : Math.max(0, hp.current - 1); setInput(hist.current[hp.current]); } } else if (e.key === "ArrowDown") { e.preventDefault(); if (hp.current >= 0) { hp.current++; setInput(hp.current >= hist.current.length ? "" : hist.current[hp.current]); } } else if (e.key === "Tab") { e.preventDefault(); complete(); } else if (e.key === "l" && e.ctrlKey) { e.preventDefault(); setLines([]); } }} /></div>
    </div>
  );
}
export function ConsoleApp() { return <ConsoleView />; }

export function Runtime() {
  const { params, rev } = useWin(); const path = String(params.path ?? ""); const [out, setOut] = useState<string[]>([]); const [state, setState] = useState<"idle" | "running" | "done" | "error">("idle"); const vm = useRef<VM | null>(null);
  const [debug, setDebug] = useState(false); const [bp, setBp] = useState(""); const [stop, setStop] = useState<{ line: number; fn: string; locals: Record<string, string> } | null>(null); const resolver = useRef<((a: "continue" | "step" | "stop") => void) | null>(null);
  const go = useCallback(async () => {
    setOut([]); setState("running"); setStop(null);
    try {
      const src = await fs.readText(path); const bc = compileNxl(src);
      const dbg = debug ? { breakpoints: new Set(bp.split(",").map((x) => Number(x.trim())).filter(Boolean)), step: bp.trim() === "", onBreak: (line: number, fn: string, locals: Record<string, string>) => new Promise<"continue" | "step" | "stop">((res) => { setStop({ line, fn, locals }); resolver.current = (a) => { setStop(null); res(a); }; }) } : undefined;
      const v = new VM(bc, neuxHost((s) => setOut((o) => [...o, s]), dirname(path)), { debug: dbg }); vm.current = v; await v.run(); setState("done"); setOut((o) => [...o, `[finished — ${v.steps} VM steps]`]);
    } catch (e) { setState("error"); setOut((o) => [...o, (e as Error).message]); }
  }, [path, debug, bp]);
  useEffect(() => { if (path && !debug) void go(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [rev, path]);
  if (!path) return <Empty>Open a .wr or .nxl file to run it.</Empty>;
  return <div className="col" style={{ height: "100%", gap: 0 }}><div className="toolbar"><b className="grow small">{basename(path)}</b><label className="row small"><input type="checkbox" checked={debug} onChange={(e) => setDebug(e.target.checked)} />Debugger</label>{debug && <input className="input" style={{ width: 150 }} placeholder="breakpoints: 3,7 (empty = step)" value={bp} onChange={(e) => setBp(e.target.value)} aria-label="Breakpoints" />}<button className="btn sm primary" onClick={go} disabled={state === "running" && !stop}>Run</button><button className="btn sm" onClick={() => { vm.current?.stop(); resolver.current?.("stop"); }}>Stop</button></div>
    {stop && <div className="card small" style={{ margin: 8 }}><b>Paused at line {stop.line}</b> in {stop.fn}<div className="mono">{Object.entries(stop.locals).map(([k, v]) => <div key={k}>{k} = {v}</div>)}</div><div className="row"><button className="btn sm" onClick={() => resolver.current?.("step")}>Step</button><button className="btn sm" onClick={() => resolver.current?.("continue")}>Continue</button></div></div>}
    <div className="term grow scroll" role="log">{out.map((l, i) => <div key={i} style={{ color: /^\[(runtime|type|parse|lex|compile)\]/.test(l) ? "#ff7b7b" : undefined }}>{l}</div>)}{state === "running" && !stop && <span className="spinner" />}</div></div>;
}
void runNxl; void useMemo;
