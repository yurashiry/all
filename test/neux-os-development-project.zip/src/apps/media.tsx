"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { useFs, useWin, useShortcut, Empty, pickHostFiles, Switch } from "@/shell/ui";
import { basename, dirname, join, type FsNode } from "@/core/filesystem/neuxfs";
import { extOf, formatBytes, kindOf, uid } from "@/core/util";
import { readTags, type Tags } from "./media/tags";
import { parseLRC, activeLine, fetchOnlineLyrics, type Lyrics } from "./media/lyrics";
import { Glyph } from "@/shell/icons";
import { notify, pickFile, promptBox, confirmBox, alertBox, showMenu, setTitle } from "@/core/os";
import { useSetting } from "@/core/settings";
import { onDownloadComplete } from "@/core/networking/downloads";

interface Playlist { id: string; name: string; items: string[] }
interface Prefs { favorites: string[]; recent: string[]; resume: Record<string, number>; lyricsOnline: boolean; eq: number[]; eqOn: boolean; replayGain: boolean; compressor: boolean; gapless: boolean; presets: Record<string, number[]> }
const PREFS = "/Configuration/media.json"; const PL = "/Users/Default/Music/Playlists";
const BANDS = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
const EQ_PRESETS: Record<string, number[]> = { Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "Bass boost": [6, 5, 4, 2, 0, 0, 0, 0, 0, 0], "Treble boost": [0, 0, 0, 0, 0, 1, 2, 4, 5, 6], Vocal: [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1], Loudness: [5, 3, 0, -1, -1, 0, 0, 2, 4, 5] };
const DEF: Prefs = { favorites: [], recent: [], resume: {}, lyricsOnline: false, eq: Array(10).fill(0), eqOn: false, replayGain: false, compressor: false, gapless: true, presets: {} };
const fmt = (s: number) => (isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}` : "0:00");
const isMedia = (n: FsNode) => n.type === "file" && ["audio", "video"].includes(kindOf(n.name));
const tagCache = new Map<string, Tags>();
async function tagsFor(path: string): Promise<Tags> {
  const c = tagCache.get(path); if (c) return c;
  const n = await fs.stat(path); const blob = n.data!;
  const head = new Uint8Array(await blob.slice(0, 3_000_000).arrayBuffer());
  const t = kindOf(path) === "audio" ? readTags(head, n.name) : { tech: { codec: extOf(n.name).toUpperCase(), lossless: null } };
  if (kindOf(path) === "audio" && !t.lyrics) {
    const lrc = join(dirname(path), basename(path).replace(/\.[^.]+$/, "") + ".lrc");
    if (await fs.exists(lrc)) { const l = parseLRC(await fs.readText(lrc), "Sidecar .lrc file"); if (l) t.lyrics = l; }
  }
  tagCache.set(path, t); return t;
}
function Art({ tags, name, size, big }: { tags?: Tags; name: string; size?: number; big?: boolean }) {
  const [u, setU] = useState<string | null>(null);
  useEffect(() => { if (!tags?.art) { setU(null); return; } const x = URL.createObjectURL(tags.art); setU(x); return () => URL.revokeObjectURL(x); }, [tags]);
  const h = [...name].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 3);
  // eslint-disable-next-line @next/next/no-img-element
  return u ? <img src={u} alt="" style={{ width: big ? "100%" : size, height: big ? "100%" : size, objectFit: "cover", borderRadius: big ? 16 : 8, aspectRatio: "1" }} /> : <div style={{ width: big ? "100%" : size, height: big ? "100%" : size, aspectRatio: "1", borderRadius: big ? 16 : 8, background: `linear-gradient(135deg,hsl(${h} 60% 45%),hsl(${(h + 60) % 360} 60% 25%))`, display: "grid", placeItems: "center", color: "#fff", flexShrink: 0 }}><Glyph name={kindOf(name) === "video" ? "play" : "media"} size={big ? 64 : (size ?? 40) / 2} /></div>;
}

export default function Media() {
  const win = useWin(); const volume = useSetting("volume"); const muted = useSetting("muted");
  const [prefs, setPrefs] = useState<Prefs>(DEF); const prefsRef = useRef(prefs);
  const savePrefs = (p: Prefs) => { prefsRef.current = p; setPrefs(p); void fs.saveJson(PREFS, p); };
  useEffect(() => { fs.json<Partial<Prefs>>(PREFS, {}).then((p) => { const m = { ...DEF, ...p }; prefsRef.current = m; setPrefs(m); }); }, []);
  const [files] = useFs(async () => (await fs.all()).filter(isMedia), [], [] as FsNode[]);
  const [pls, reloadPls] = useFs(async () => { try { const out: Playlist[] = []; for (const n of await fs.list(PL)) if (n.name.endsWith(".json")) out.push(await fs.json<Playlist>(n.path, null as never)); return out.filter(Boolean).sort((a, b) => a.name.localeCompare(b.name)); } catch { return []; } }, [], [] as Playlist[]);
  const [view, setView] = useState("music"); const [q, setQ] = useState(""); const [plId, setPlId] = useState("");
  const [queue, setQueue] = useState<string[]>([]); const [idx, setIdx] = useState(-1); const [shuffle, setShuffle] = useState(false); const [repeat, setRepeat] = useState<"off" | "all" | "one">("off");
  const [playing, setPlaying] = useState(false); const [time, setTime] = useState(0); const [dur, setDur] = useState(0); const [rate, setRate] = useState(1); const [err, setErr] = useState("");
  const [tags, setTags] = useState<Tags | undefined>(); const [lyrics, setLyrics] = useState<Lyrics | null>(null); const [lyStatus, setLyStatus] = useState(""); const [nowOpen, setNowOpen] = useState(false); const [lyricsMode, setLyricsMode] = useState(false);
  const [subs, setSubs] = useState<string | null>(null); const [vinfo, setVinfo] = useState(""); const [libTags, setLibTags] = useState<Record<string, Tags>>({});
  const els = useRef<(HTMLVideoElement | null)[]>([null, null]); const cur = useRef(0); const urls = useRef<(string | null)[]>([null, null]); const loaded = useRef<(string | null)[]>([null, null]);
  const ctx = useRef<{ ac: AudioContext; filters: BiquadFilterNode[]; gain: GainNode; comp: DynamicsCompressorNode; srcs: (MediaElementAudioSourceNode | null)[] } | null>(null);
  const host = useRef<HTMLDivElement>(null); const lyBox = useRef<HTMLDivElement>(null); const qRef = useRef({ queue, idx, shuffle, repeat }); qRef.current = { queue, idx, shuffle, repeat };
  const path = queue[idx]; const isVideo = path ? kindOf(path) === "video" : false;
  const el = () => els.current[cur.current]!;

  // library tag scan (artwork/artist/album) lazily
  useEffect(() => { let on = true; (async () => { for (const f of files.filter((x) => kindOf(x.name) === "audio").slice(0, 300)) { if (!on) return; if (libTags[f.path]) continue; try { const t = await tagsFor(f.path); if (on) setLibTags((p) => ({ ...p, [f.path]: t })); } catch { /* unreadable */ } } })(); return () => { on = false; }; /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [files]);
  useEffect(() => onDownloadComplete((d) => { if (d.path && ["audio", "video"].includes(kindOf(d.path))) notify({ title: "Added to Media library", message: d.name, appId: "media" }); }), []);

  const buildGraph = useCallback(() => {
    if (ctx.current) return ctx.current;
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = new AC(); const filters = BANDS.map((f) => { const b = ac.createBiquadFilter(); b.type = "peaking"; b.frequency.value = f; b.Q.value = 1.1; return b; });
    const gain = ac.createGain(); const comp = ac.createDynamicsCompressor();
    const g = { ac, filters, gain, comp, srcs: [null, null] as (MediaElementAudioSourceNode | null)[] }; ctx.current = g; return g;
  }, []);
  const routeGraph = useCallback(() => {
    const p = prefsRef.current; if (!(p.eqOn || p.replayGain || p.compressor) && !ctx.current) return;
    const g = buildGraph();
    els.current.forEach((e, i) => { if (e && !g.srcs[i]) g.srcs[i] = g.ac.createMediaElementSource(e); });
    g.srcs.forEach((s) => { try { s?.disconnect(); } catch { /* */ } });
    [...g.filters, g.gain, g.comp].forEach((n) => { try { n.disconnect(); } catch { /* */ } });
    let node: AudioNode = g.filters[0]; g.srcs.forEach((s) => s?.connect(node));
    g.filters.forEach((f, i) => { f.gain.value = p.eqOn ? p.eq[i] : 0; if (i) g.filters[i - 1].connect(f); });
    node = g.filters[g.filters.length - 1]; node.connect(g.gain); node = g.gain;
    if (p.compressor) { node.connect(g.comp); node = g.comp; } node.connect(g.ac.destination);
    void g.ac.resume();
  }, [buildGraph]);
  useEffect(() => { if (prefs.eqOn || prefs.replayGain || prefs.compressor || ctx.current) routeGraph(); }, [prefs.eqOn, prefs.eq, prefs.replayGain, prefs.compressor, routeGraph]);

  const loadInto = useCallback(async (slot: number, p: string) => {
    if (loaded.current[slot] === p) return;
    const b = await fs.readBlob(p); if (urls.current[slot]) URL.revokeObjectURL(urls.current[slot]!);
    const u = URL.createObjectURL(new Blob([b], { type: b.type || (kindOf(p) === "video" ? "video/mp4" : "audio/mpeg") })); urls.current[slot] = u; loaded.current[slot] = p;
    const e = els.current[slot]!; e.src = u; e.load();
  }, []);
  const nextIndex = useCallback((dir = 1): number => {
    const { queue: qq, idx: i, shuffle: sh, repeat: rp } = qRef.current; if (!qq.length) return -1;
    if (rp === "one" && dir > 0) return i;
    if (sh && qq.length > 1) { let n = i; while (n === i) n = Math.floor(Math.random() * qq.length); return n; }
    const n = i + dir; if (n >= qq.length) return rp === "all" ? 0 : -1; if (n < 0) return rp === "all" ? qq.length - 1 : 0; return n;
  }, []);
  const playIndex = useCallback(async (i: number, q2?: string[]) => {
    const list = q2 ?? qRef.current.queue; const p = list[i]; if (!p) return; setErr("");
    try {
      if (q2) { setQueue(q2); qRef.current.queue = q2; }
      const other = 1 - cur.current; els.current[cur.current]?.pause();
      // use preloaded element if it already holds this path
      const slot = loaded.current[other] === p ? other : cur.current; if (slot === other) cur.current = other; else await loadInto(slot, p);
      setIdx(i); setSubs(null); setLyrics(null); setNowOpen(kindOf(p) === "video"); setLyricsMode(false); const e = el(); e.playbackRate = rate;
      const r = prefsRef.current.resume[p]; if (r && r > 3) e.currentTime = r; else e.currentTime = 0;
      await e.play(); setPlaying(true);
      const np = [p, ...prefsRef.current.recent.filter((x) => x !== p)].slice(0, 50); savePrefs({ ...prefsRef.current, recent: np });
    } catch (er) { setErr(`Cannot play ${basename(p)}: ${(er as Error).message}. The browser may not support this codec/container — see Capabilities.`); setPlaying(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadInto, rate]);
  const playNow = (paths: string[], start = 0) => playIndex(start, paths);

  // metadata + lyrics on track change
  useEffect(() => { if (!path) return; let on = true; setTags(undefined); setLyStatus(""); (async () => { try { const t = await tagsFor(path); if (!on) return; setTags(t); setLyrics(t.lyrics ?? null); setTitle(win.id, `Media — ${t.title ?? basename(path)}`); if (!t.lyrics && kindOf(path) === "audio") setLyStatus(prefsRef.current.lyricsOnline ? "No embedded lyrics. Looking online…" : "No embedded lyrics found."); if (!t.lyrics && prefsRef.current.lyricsOnline && kindOf(path) === "audio") void fetchLy(t); } catch { /* */ } })(); return () => { on = false; }; /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [path]);
  async function fetchLy(t: Tags | undefined = tags) {
    if (!path) return; if (!prefsRef.current.lyricsOnline) { if (!(await confirmBox("Online lyrics lookup", "Neux will send this track's title, artist and album to the public LRCLIB service (lrclib.net) to look for lyrics. Nothing else is sent. Enable?", false, "Enable"))) return; savePrefs({ ...prefsRef.current, lyricsOnline: true }); }
    setLyStatus("Searching LRCLIB…");
    try { const l = await fetchOnlineLyrics(t?.title ?? basename(path).replace(/\.[^.]+$/, ""), t?.artist ?? "", t?.album, el()?.duration); if (l) { setLyrics(l); setLyStatus(""); } else setLyStatus("Lyrics could not be found for this track."); } catch (e) { setLyStatus("Lyrics lookup failed: " + (e as Error).message); }
  }
  // wire media events
  useEffect(() => {
    const cleanups: (() => void)[] = [];
    els.current.forEach((e, slot) => { if (!e) return;
      const isCur = () => cur.current === slot;
      const tu = () => { if (!isCur()) return; setTime(e.currentTime); setDur(e.duration || 0); const p = loaded.current[slot]; if (p && Math.floor(e.currentTime) % 5 === 0 && e.currentTime > 3) prefsRef.current.resume[p] = e.currentTime;
        if (prefsRef.current.gapless && e.duration && e.duration - e.currentTime < 4) { const n = nextIndex(1); const np = n >= 0 ? qRef.current.queue[n] : undefined; if (np && n !== qRef.current.idx && loaded.current[1 - slot] !== np) void loadInto(1 - slot, np); } };
      const en = () => { if (!isCur()) return; const p = loaded.current[slot]; if (p) delete prefsRef.current.resume[p]; const n = nextIndex(1); if (n >= 0 && (n !== qRef.current.idx || qRef.current.repeat === "one")) void playIndex(n); else setPlaying(false); };
      const er = () => { if (isCur() && e.error) setErr(`Playback error (${e.error.code}): ${e.error.message || "unsupported or corrupt media"}`); };
      const pl = () => isCur() && setPlaying(true), pa = () => isCur() && setPlaying(false);
      e.addEventListener("timeupdate", tu); e.addEventListener("ended", en); e.addEventListener("error", er); e.addEventListener("play", pl); e.addEventListener("pause", pa); e.addEventListener("loadedmetadata", tu);
      cleanups.push(() => { e.removeEventListener("timeupdate", tu); e.removeEventListener("ended", en); e.removeEventListener("error", er); e.removeEventListener("play", pl); e.removeEventListener("pause", pa); e.removeEventListener("loadedmetadata", tu); });
    });
    return () => cleanups.forEach((c) => c());
  }, [nextIndex, playIndex, loadInto]);
  useEffect(() => { els.current.forEach((e) => { if (e) { e.volume = muted ? 0 : volume; } }); }, [volume, muted, nowOpen, view]);
  useEffect(() => { els.current.forEach((e) => { if (e) e.playbackRate = rate; }); }, [rate]);
  useEffect(() => { const g = ctx.current; if (g) { const rg = prefs.replayGain && tags ? 0 : 0; g.gain.gain.value = Math.pow(10, rg / 20); } }, [prefs.replayGain, tags]);
  useEffect(() => () => { els.current.forEach((e) => e?.pause()); urls.current.forEach((u) => u && URL.revokeObjectURL(u)); ctx.current?.ac.close().catch(() => {}); }, []);
  // video measured fps
  useEffect(() => { const e = el(); if (!e || !isVideo || !("requestVideoFrameCallback" in e)) { setVinfo(""); return; } let frames = 0, t0 = performance.now(), stop = false;
    const cb = (_n: number, m: { presentedFrames?: number }) => { if (stop) return; frames++; const now = performance.now(); if (now - t0 > 1500) { const q = e.getVideoPlaybackQuality?.(); setVinfo(`${e.videoWidth}×${e.videoHeight} · measured ${(frames / ((now - t0) / 1000)).toFixed(1)} fps${q ? ` · dropped ${q.droppedVideoFrames}/${q.totalVideoFrames}` : ""}`); frames = 0; t0 = now; } void m; (e as unknown as { requestVideoFrameCallback: (f: typeof cb) => void }).requestVideoFrameCallback(cb); };
    (e as unknown as { requestVideoFrameCallback: (f: typeof cb) => void }).requestVideoFrameCallback(cb); return () => { stop = true; }; /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [path, isVideo, playing]);
  // open file via association / add to playlist
  useEffect(() => { const p = win.params.path as string | undefined; if (p) { if (kindOf(p) === "audio" || kindOf(p) === "video") { const all = [p, ...queue.filter((x) => x !== p)]; void playNow(all, 0); } else setErr("Not a media file: " + basename(p)); } const a = win.params.addToPlaylist as string | undefined; if (a) void addToPlaylist([a]); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  // active lyric scroll
  const li = lyrics ? activeLine(lyrics, time) : -1;
  useEffect(() => { if (li >= 0) lyBox.current?.querySelector<HTMLElement>(`[data-i="${li}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }); }, [li, nowOpen, lyricsMode]);

  const toggle = () => { const e = el(); if (!path) return; if (e.paused) void e.play().catch((x) => setErr(String(x))); else e.pause(); };
  const seek = (t: number) => { el().currentTime = t; setTime(t); };
  const savePl = async (p: Playlist) => { await fs.writeFile(`${PL}/${p.id}.json`, JSON.stringify(p), { role: "root", mime: "application/json" }); reloadPls(); };
  const addToPlaylist = async (paths: string[], to?: string) => {
    let id = to; if (!id) { const choice = await promptBox("Add to playlist", pls.length ? `Type a playlist name (existing: ${pls.map((p) => p.name).join(", ")}) or a new name` : "Name for a new playlist", pls[0]?.name ?? "My Collection"); if (!choice) return; const ex = pls.find((p) => p.name === choice); if (ex) id = ex.id; else { const np = { id: uid(), name: choice, items: [] as string[] }; await savePl(np); id = np.id; } }
    const cur2 = (await fs.json<Playlist>(`${PL}/${id}.json`, null as never)); cur2.items.push(...paths.filter((p) => !cur2.items.includes(p))); await savePl(cur2); notify({ title: "Playlist updated", message: `${cur2.name}: ${cur2.items.length} item(s)` });
  };
  const hostImport = async () => { const picked = await pickHostFiles("audio/*,video/*,.flac,.mka,.mkv,.opus,.alac,.m4a", true); if (!picked.length) return; const added: string[] = []; for (const f of picked) { const k = kindOf(f.name); if (k !== "audio" && k !== "video") continue; const p = await fs.uniquePath(join(k === "audio" ? "/Users/Default/Music" : "/Users/Default/Videos", f.name)); await fs.writeFile(p, f); added.push(p); } notify({ title: "Imported", message: `${added.length} file(s) copied into NeuxFS (originals untouched)` }); };
  const fromNeux = async (to?: string) => { const p = await pickFile({ filter: "media", multiple: true, title: "Add media" }); if (p) await addToPlaylist(p, to); };
  const addSubs = async () => { const p = await pickFile({ filter: "all", title: "Choose .srt or .vtt subtitles" }); if (!p) return; const t = await fs.readText(p[0]); const vtt = extOf(p[0]) === "vtt" ? t : "WEBVTT\n\n" + t.replace(/\r/g, "").replace(/(\d+:\d+:\d+),(\d+)/g, "$1.$2"); setSubs(URL.createObjectURL(new Blob([vtt], { type: "text/vtt" }))); };
  useShortcut("gen.open", () => void fromNeux(), []);
  useShortcut("gen.delete", () => false, []);

  const lib = files.filter((f) => (view === "music" ? kindOf(f.name) === "audio" : view === "videos" ? kindOf(f.name) === "video" : true) && (!q || f.name.toLowerCase().includes(q.toLowerCase()) || (libTags[f.path]?.title ?? "").toLowerCase().includes(q.toLowerCase())));
  const titleOf = (p: string) => libTags[p]?.title ?? basename(p).replace(/\.[^.]+$/, "");
  const groups = (key: "album" | "artist") => { const m = new Map<string, string[]>(); files.filter((f) => kindOf(f.name) === "audio").forEach((f) => { const k = libTags[f.path]?.[key] ?? "Unknown " + key; m.set(k, [...(m.get(k) ?? []), f.path]); }); return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0])); };
  const pl = pls.find((p) => p.id === plId);
  const row = (p: string, i: number, list: string[], extra?: React.ReactNode) => (
    <div key={p + i} className={"frow" + (p === path ? " sel" : "")} onDoubleClick={() => playNow(list, i)} onContextMenu={(e) => showMenu(e, [{ label: "Play", action: () => playNow(list, i) }, { label: "Play next", action: () => setQueue((q2) => { const n = [...q2]; n.splice(idx + 1, 0, p); return n; }) }, { label: "Add to queue", action: () => setQueue((q2) => [...q2, p]) }, { label: "Add to playlist…", action: () => addToPlaylist([p]) }, { label: prefs.favorites.includes(p) ? "Remove favorite" : "Favorite", action: () => savePrefs({ ...prefs, favorites: prefs.favorites.includes(p) ? prefs.favorites.filter((x) => x !== p) : [...prefs.favorites, p] }) }])}>
      <Art tags={libTags[p]} name={p} size={36} /><div className="col grow" style={{ gap: 0, minWidth: 0 }}><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{titleOf(p)}</span><span className="dim small">{libTags[p]?.artist ?? (kindOf(p) === "video" ? "Video" : "Unknown artist")}{libTags[p]?.tech.lossless ? " · lossless" : ""}</span></div>
      {extra}<button className="btn sm ghost" aria-label="Play" onClick={() => playNow(list, i)}><Glyph name="play" size={14} /></button></div>);
  const nav = (id: string, l: string) => <button key={id} className={"side-item" + (view === id ? " active" : "")} onClick={() => { setView(id); setPlId(""); }}>{l}</button>;
  const tech = tags?.tech;
  const eqSet = (i: number, v: number) => { const e = [...prefs.eq]; e[i] = v; savePrefs({ ...prefs, eq: e, eqOn: true }); };
  const lyricsPane = (big: boolean) => (
    <div className="grow" style={{ display: "flex", gap: big ? 40 : 20, padding: big ? "3vh 4vw" : 16, minHeight: 0, height: "100%", background: "linear-gradient(135deg, rgba(0,0,0,.35), rgba(0,0,0,.6))" }}>
      <div style={{ flex: "0 0 38%", display: "grid", placeItems: "center", minWidth: 0 }}><div style={{ width: "100%", maxHeight: "100%", aspectRatio: "1", maxWidth: "min(100%, 70vh)" }}><Art tags={tags} name={path ?? "x"} big /></div></div>
      <div className="col" style={{ flex: 1, minWidth: 0, minHeight: 0 }}>
        <div className="row"><div className="grow"><div style={{ fontSize: big ? 28 : 20, fontWeight: 700 }}>{tags?.title ?? (path && basename(path))}</div><div className="dim">{tags?.artist}{tags?.album ? " — " + tags.album : ""}</div></div>
          <button className="btn sm" onClick={() => fetchLy()}>Refresh lyrics</button><button className="btn sm" onClick={() => (document.fullscreenElement ? document.exitFullscreen() : host.current?.requestFullscreen())}>Fullscreen</button><button className="btn sm" onClick={() => { setLyricsMode(false); setNowOpen(true); }}>Standard player</button></div>
        <div ref={lyBox} className="scroll grow" style={{ padding: "30vh 0", maskImage: "linear-gradient(transparent, #000 20%, #000 80%, transparent)" }}>
          {!lyrics ? <div className="dim" style={{ fontSize: 18 }}>{lyStatus || "No lyrics available for this track."}</div> : <>
            {!lyrics.synced && <div className="badge warn" style={{ marginBottom: 10 }}>Unsynchronized lyrics — no timestamps available</div>}
            {lyrics.lines.map((l, i) => <div key={i} data-i={i} className="hl-line" onClick={() => l.t !== null && seek(l.t)} style={{ fontSize: big ? 38 : 26, fontWeight: 800, lineHeight: 1.25, padding: "6px 0", cursor: l.t !== null ? "pointer" : "default", opacity: !lyrics.synced ? 0.9 : i === li ? 1 : i < li ? 0.35 : 0.55, transform: i === li ? "scale(1.02)" : "none", transformOrigin: "left", color: i === li ? "var(--accent)" : undefined }}>{l.text}</div>)}
            <div className="dim small" style={{ marginTop: 20 }}>Source: {lyrics.source}</div></>}
        </div>
      </div>
    </div>);
  return (
    <div ref={host} className="col" style={{ height: "100%", gap: 0, background: "var(--surface-solid)" }}>
      <div className="row grow" style={{ alignItems: "stretch", gap: 0, minHeight: 0 }}>
        <div className="sidebar" style={{ width: 180 }}>
          <input className="input" placeholder="Search library" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search library" />
          {nav("music", "Music")}{nav("videos", "Videos")}{nav("albums", "Albums")}{nav("artists", "Artists")}{nav("favorites", "Favorites")}{nav("recent", "Recently played")}{nav("queue", `Queue (${queue.length})`)}
          <hr className="sep" /><div className="row"><span className="dim small grow">Playlists</span><button className="btn sm ghost" aria-label="New playlist" onClick={async () => { const n = await promptBox("New playlist", "Name", "My Collection"); if (n) await savePl({ id: uid(), name: n, items: [] }); }}>+</button></div>
          {pls.map((p) => <button key={p.id} className={"side-item" + (view === "pl" && plId === p.id ? " active" : "")} onClick={() => { setView("pl"); setPlId(p.id); }}>{p.name}<span className="dim small" style={{ marginLeft: "auto" }}>{p.items.length}</span></button>)}
          <hr className="sep" />{nav("eq", "Equalizer & audio")}{nav("caps", "Capabilities")}
        </div>
        <div className="col grow" style={{ gap: 0, minWidth: 0 }}>
          {err && <div role="alert" className="card small" style={{ margin: 8, borderColor: "var(--danger)" }}>{err}</div>}
          <div className="scroll grow" style={{ padding: 10, position: "relative" }}>
            {(view === "music" || view === "videos") && <><div className="row" style={{ marginBottom: 8 }}><b className="grow">{view === "music" ? "Music" : "Videos"} · {lib.length}</b><button className="btn sm" onClick={() => playNow(lib.map((f) => f.path), 0)} disabled={!lib.length}>Play all</button><button className="btn sm" onClick={hostImport} title="Copies selected files from this device into NeuxFS; originals are not changed">Import from device…</button></div>
              {lib.length === 0 ? <Empty>No {view === "music" ? "music" : "videos"} in NeuxFS yet. Download files in Browser, import from your device, or copy them into NeuxFS/Users/Default/{view === "music" ? "Music" : "Videos"}.</Empty> : lib.map((f, i) => row(f.path, i, lib.map((x) => x.path), <span className="dim small">{formatBytes(f.size)}</span>))}</>}
            {(view === "albums" || view === "artists") && groups(view === "albums" ? "album" : "artist").map(([k, ps]) => <div key={k} className="card" style={{ marginBottom: 8 }}><div className="row"><Art tags={libTags[ps[0]]} name={k} size={56} /><div className="grow"><b>{k}</b><div className="dim small">{ps.length} track(s)</div></div><button className="btn sm" onClick={() => playNow(ps, 0)}>Play</button></div></div>)}
            {view === "favorites" && (prefs.favorites.length ? prefs.favorites.map((p, i) => row(p, i, prefs.favorites)) : <Empty>Right-click a track → Favorite.</Empty>)}
            {view === "recent" && (prefs.recent.length ? prefs.recent.map((p, i) => row(p, i, prefs.recent)) : <Empty>Nothing played yet.</Empty>)}
            {view === "queue" && (queue.length ? queue.map((p, i) => row(p, i, queue, <button className="btn sm ghost" aria-label="Remove from queue" onClick={() => setQueue((q2) => q2.filter((_, j) => j !== i))}>×</button>)) : <Empty>The queue is empty.</Empty>)}
            {view === "pl" && pl && <><div className="row" style={{ marginBottom: 8 }}><b className="grow">{pl.name}</b><button className="btn sm" onClick={() => playNow(pl.items, 0)} disabled={!pl.items.length}>Play</button><button className="btn sm" onClick={() => { setShuffle(true); playNow(pl.items, Math.floor(Math.random() * pl.items.length)); }} disabled={!pl.items.length}>Shuffle</button><button className="btn sm" onClick={() => fromNeux(pl.id)}>Add files…</button><button className="btn sm" onClick={async () => { const n = await promptBox("Rename playlist", "Name", pl.name); if (n) await savePl({ ...pl, name: n }); }}>Rename</button><button className="btn sm danger" onClick={async () => { if (await confirmBox("Delete playlist", `Delete “${pl.name}”? The media files stay.`, true, "Delete")) { await fs.remove(`${PL}/${pl.id}.json`, { role: "root" }); setView("music"); reloadPls(); } }}>Delete</button></div>
              {pl.items.length === 0 ? <Empty>Empty playlist. Mix music and video freely.</Empty> : pl.items.map((p, i) => row(p, i, pl.items, <span className="row"><button className="btn sm ghost" aria-label="Move up" disabled={!i} onClick={() => { const it = [...pl.items]; [it[i - 1], it[i]] = [it[i], it[i - 1]]; void savePl({ ...pl, items: it }); }}>↑</button><button className="btn sm ghost" aria-label="Move down" disabled={i === pl.items.length - 1} onClick={() => { const it = [...pl.items]; [it[i + 1], it[i]] = [it[i], it[i + 1]]; void savePl({ ...pl, items: it }); }}>↓</button><button className="btn sm ghost" aria-label="Remove" onClick={() => savePl({ ...pl, items: pl.items.filter((_, j) => j !== i) })}>×</button><span className="badge">{kindOf(p)}</span></span>))}</>}
            {view === "eq" && <div className="col"><div className="row wrap"><label className="row"><Switch label="Equalizer" checked={prefs.eqOn} onChange={(v) => savePrefs({ ...prefs, eqOn: v })} />Equalizer</label>
              <select className="input" style={{ width: 160 }} onChange={(e) => { const p = { ...EQ_PRESETS, ...prefs.presets }[e.target.value]; if (p) savePrefs({ ...prefs, eq: p, eqOn: true }); }} aria-label="Preset" defaultValue=""><option value="" disabled>Preset…</option>{Object.keys({ ...EQ_PRESETS, ...prefs.presets }).map((k) => <option key={k}>{k}</option>)}</select>
              <button className="btn sm" onClick={async () => { const n = await promptBox("Save preset", "Preset name"); if (n) savePrefs({ ...prefs, presets: { ...prefs.presets, [n]: prefs.eq } }); }}>Save preset</button></div>
              <div className="row" style={{ alignItems: "flex-end", height: 190, gap: 6 }}>{BANDS.map((f, i) => <div key={f} className="col" style={{ alignItems: "center", height: "100%" }}><span className="small">{prefs.eq[i] > 0 ? "+" : ""}{prefs.eq[i]}</span><input type="range" min={-12} max={12} step={1} value={prefs.eq[i]} onChange={(e) => eqSet(i, Number(e.target.value))} aria-label={`${f} Hz`} style={{ writingMode: "vertical-lr", direction: "rtl", height: 130, accentColor: "var(--accent)" }} /><span className="dim small">{f >= 1000 ? f / 1000 + "k" : f}</span></div>)}</div>
              <label className="row"><Switch label="Normalization limiter" checked={prefs.compressor} onChange={(v) => savePrefs({ ...prefs, compressor: v })} />Volume normalization (dynamics compressor — alters dynamics)</label>
              <label className="row"><Switch label="ReplayGain" checked={prefs.replayGain} onChange={(v) => savePrefs({ ...prefs, replayGain: v })} />ReplayGain (applies the REPLAYGAIN_TRACK_GAIN tag when present)</label>
              <label className="row"><Switch label="Gapless" checked={prefs.gapless} onChange={(v) => savePrefs({ ...prefs, gapless: v })} />Gapless: preloads the next track (best effort, not sample-accurate)</label>
              <div className="dim small">With every option off, audio plays directly through the browser&apos;s media pipeline with no processing by Neux (no transcoding, no enhancement). Enabling EQ/ReplayGain routes audio through Web Audio, which resamples to the device output rate; bit-perfect Hi-Res output to USB DACs needs the native Android/Windows/macOS adapters (not built yet).</div></div>}
            {view === "caps" && <Capabilities />}
          </div>
          <div className="solid" style={{ borderTop: "1px solid var(--border)", padding: "8px 12px" }}>
            <div className="row" style={{ gap: 12 }}>
              <div style={{ cursor: "pointer" }} onClick={() => path && setNowOpen(true)}><Art tags={tags} name={path ?? "Neux"} size={48} /></div>
              <div className="col grow" style={{ gap: 0, minWidth: 0 }}><b style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{path ? tags?.title ?? basename(path) : "Nothing playing"}</b><span className="dim small">{tags?.artist ?? ""}{tech?.sampleRate ? ` · ${tech.codec} ${tech.bitDepth ? tech.bitDepth + "-bit " : ""}${(tech.sampleRate / 1000).toFixed(tech.sampleRate % 1000 ? 1 : 0)} kHz` : tech ? " · " + tech.codec : ""}</span></div>
              <button className={"btn sm" + (shuffle ? " primary" : "")} aria-label="Shuffle" aria-pressed={shuffle} onClick={() => setShuffle(!shuffle)}><Glyph name="shuffle" size={16} /></button>
              <button className="btn sm" aria-label="Previous" onClick={() => { if (time > 3) seek(0); else { const n = nextIndex(-1); if (n >= 0) void playIndex(n); } }}><Glyph name="prev" size={16} /></button>
              <button className="btn primary" aria-label={playing ? "Pause" : "Play"} onClick={toggle} disabled={!path} style={{ minWidth: 44 }}><Glyph name={playing ? "pause" : "play"} size={18} /></button>
              <button className="btn sm" aria-label="Next" onClick={() => { const n = nextIndex(1); if (n >= 0) void playIndex(n); }}><Glyph name="next" size={16} /></button>
              <button className={"btn sm" + (repeat !== "off" ? " primary" : "")} aria-label={`Repeat ${repeat}`} onClick={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}><Glyph name="repeat" size={16} />{repeat === "one" ? "1" : ""}</button>
              <button className="btn sm" onClick={() => { setLyricsMode(true); setNowOpen(false); }} disabled={!path || isVideo}>Lyrics</button>
            </div>
            <div className="row small"><span style={{ width: 40 }}>{fmt(time)}</span><input type="range" className="range" min={0} max={dur || 0} step={0.1} value={Math.min(time, dur || 0)} onChange={(e) => seek(Number(e.target.value))} aria-label="Seek" disabled={!path} /><span style={{ width: 40 }}>{fmt(dur)}</span>
              <select className="input" style={{ width: 74, minHeight: 26, padding: "2px 6px" }} value={rate} onChange={(e) => setRate(Number(e.target.value))} aria-label="Playback speed">{[0.5, 0.75, 1, 1.25, 1.5, 2].map((r) => <option key={r} value={r}>{r}×</option>)}</select></div>
          </div>
        </div>
      </div>
      {/* media elements stay mounted: switching views never reloads playback */}
      <div style={nowOpen && isVideo ? { position: "absolute", inset: 0, background: "#000", zIndex: 20, display: "flex", flexDirection: "column" } : { position: "absolute", width: 1, height: 1, overflow: "hidden", opacity: 0, pointerEvents: "none" }}>
        {nowOpen && isVideo && <div className="toolbar" style={{ background: "var(--surface-solid)" }}><button className="btn sm" onClick={() => setNowOpen(false)}>← Back</button><b className="grow">{basename(path!)}</b><span className="dim small">{vinfo || (el()?.videoWidth ? `${el().videoWidth}×${el().videoHeight}` : "")}</span><button className="btn sm" onClick={addSubs}>Subtitles…</button><button className="btn sm" onClick={() => el().requestFullscreen?.()}>Fullscreen</button>{(el() as unknown as { audioTracks?: { length: number } })?.audioTracks && ((el() as unknown as { audioTracks: { length: number } }).audioTracks.length > 1 ? <span className="badge">{(el() as unknown as { audioTracks: { length: number } }).audioTracks.length} audio tracks</span> : null)}</div>}
        <div style={{ flex: 1, minHeight: 0, position: "relative" }}>{[0, 1].map((s) => <video key={s} ref={(e) => { els.current[s] = e; }} playsInline preload="auto" onClick={toggle} style={{ width: "100%", height: "100%", objectFit: "contain", display: s === cur.current ? "block" : "none", position: "absolute", inset: 0 }}>{s === cur.current && subs && <track kind="subtitles" src={subs} default label="Subtitles" />}</video>)}</div>
      </div>
      {nowOpen && !isVideo && path && <div style={{ position: "absolute", inset: 0, zIndex: 20, background: "var(--surface-solid)", display: "flex", flexDirection: "column" }}>
        <div className="toolbar"><button className="btn sm" onClick={() => setNowOpen(false)}>← Back</button><b className="grow">Now Playing</b><button className="btn sm" onClick={() => { setLyricsMode(true); setNowOpen(false); }}>Lyrics view</button></div>
        <div className="row grow" style={{ padding: 24, gap: 32, alignItems: "center", justifyContent: "center", flexWrap: "wrap", overflow: "auto" }}><div style={{ width: "min(340px,80%)" }}><Art tags={tags} name={path} big /></div>
          <div className="col" style={{ maxWidth: 360 }}><h2 style={{ margin: 0 }}>{tags?.title ?? basename(path)}</h2><div className="dim">{tags?.artist} {tags?.album && "— " + tags.album}</div>
            <table className="small"><tbody>{tech && <>{[["Codec", tech.codec], ["Lossless", tech.lossless === null ? "unknown" : tech.lossless ? "yes (source is lossless)" : "no (lossy source)"], ["Sample rate", tech.sampleRate ? tech.sampleRate + " Hz" : "n/a"], ["Bit depth", tech.bitDepth ? tech.bitDepth + "-bit" : "n/a"], ["Channels", tech.channels ?? "n/a"], ["Bitrate", tech.bitrate ? Math.round(tech.bitrate / 1000) + " kbps" : "n/a"]].map(([k, v]) => <tr key={String(k)}><td className="dim" style={{ paddingRight: 12 }}>{k}</td><td>{String(v)}</td></tr>)}</>}</tbody></table></div></div></div>}
      {lyricsMode && !isVideo && path && <div style={{ position: "absolute", inset: 0, zIndex: 20, background: "var(--surface-solid)" }}>{lyricsPane(!!document.fullscreenElement)}</div>}
    </div>
  );
}

function Capabilities() {
  const [rows, setRows] = useState<{ k: string; v: string }[]>([]); const [hz, setHz] = useState("measuring…");
  useEffect(() => { (async () => {
    const out: { k: string; v: string }[] = []; const v = document.createElement("video"); const a = document.createElement("audio");
    for (const [n, t] of [["MP3", "audio/mpeg"], ["AAC / M4A", 'audio/mp4; codecs="mp4a.40.2"'], ["FLAC", "audio/flac"], ["WAV (PCM)", "audio/wav"], ["Ogg Vorbis", 'audio/ogg; codecs="vorbis"'], ["Opus", 'audio/ogg; codecs="opus"'], ["ALAC", 'audio/mp4; codecs="alac"'], ["AIFF", "audio/aiff"]]) out.push({ k: "Audio " + n, v: a.canPlayType(t) || "not supported" });
    for (const [n, t] of [["H.264", 'video/mp4; codecs="avc1.640033"'], ["HEVC/H.265", 'video/mp4; codecs="hvc1.1.6.L153.B0"'], ["VP9", 'video/webm; codecs="vp09.00.51.08"'], ["AV1", 'video/mp4; codecs="av01.0.12M.08"'], ["Matroska", "video/x-matroska"], ["QuickTime MOV", "video/quicktime"]]) out.push({ k: "Video " + n, v: v.canPlayType(t) || "not supported" });
    const mc = (navigator as Navigator & { mediaCapabilities?: MediaCapabilities }).mediaCapabilities;
    if (mc) for (const [codec, ct] of [["H.264", 'avc1.640033'], ["VP9", "vp09.00.51.08"], ["AV1", "av01.0.12M.08"], ["HEVC", "hvc1.1.6.L153.B0"]]) for (const fps of [24, 30, 60, 90, 120]) {
      try { const r = await mc.decodingInfo({ type: "file", video: { contentType: `video/${codec === "VP9" ? "webm" : "mp4"}; codecs="${ct}"`, width: 3840, height: 2160, bitrate: 40_000_000, framerate: fps } }); out.push({ k: `4K ${codec} @${fps} fps`, v: r.supported ? `${r.smooth ? "smooth" : "may stutter"}, ${r.powerEfficient ? "hardware-accelerated (likely)" : "software decode"}` : "not supported" }); } catch { out.push({ k: `4K ${codec} @${fps} fps`, v: "query failed" }); }
    } else out.push({ k: "Media Capabilities API", v: "unavailable — 4K/90 fps support cannot be determined" });
    out.push({ k: "Screen", v: `${screen.width}×${screen.height} @ DPR ${devicePixelRatio}` }); setRows(out);
  })(); let n = 0, t0 = 0, on = true; const f = (t: number) => { if (!on) return; if (!t0) t0 = t; n++; if (t - t0 > 1000) { setHz(`≈ ${Math.round((n * 1000) / (t - t0))} Hz measured`); return; } requestAnimationFrame(f); }; requestAnimationFrame(f); return () => { on = false; }; }, []);
  return <div className="col"><div className="dim small">Detected live from this browser/device — never assumed. 4K and 90 fps are separate capabilities; a 4K/90 fps file plays only if its codec row above says supported. Display refresh: {hz}. Neux does not cap frame rate.</div><table className="tbl"><tbody>{rows.map((r) => <tr key={r.k}><td>{r.k}</td><td className="dim">{r.v}</td></tr>)}</tbody></table></div>;
}
void alertBox;
