"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { fs } from "@/core/kernel";
import { useWin, useShortcut, useFs, Empty, useObjectUrl, downloadBlob } from "@/shell/ui";
import { basename, dirname, join, type FsNode } from "@/core/filesystem/neuxfs";
import { extOf, formatBytes, kindOf } from "@/core/util";
import { promptBox, alertBox, pickFile, notify, openApp, confirmBox, setCloseGuard, setTitle, showMenu } from "@/core/os";
import { archivePaths, unarchive } from "@/core/filesystem/archive";
import { unzipSync } from "fflate";
import { useSetting, setSetting } from "@/core/settings";
import { HOLIDAYS } from "@/shell/wallpapers";
import { Glyph } from "@/shell/icons";

/* ---------- Calculator (own expression parser; no eval) ---------- */
type Tok = { t: "n"; v: number } | { t: "o"; v: string } | { t: "f"; v: string };
export function calc(src: string): number {
  const toks: Tok[] = []; const s = src.replace(/\s+/g, "").replace(/×/g, "*").replace(/÷/g, "/").replace(/π/g, "pi"); let i = 0;
  while (i < s.length) { const c = s[i]; if (/[0-9.]/.test(c)) { let j = i; while (j < s.length && /[0-9.]/.test(s[j])) j++; const v = Number(s.slice(i, j)); if (isNaN(v)) throw new Error("Bad number"); toks.push({ t: "n", v }); i = j; } else if (/[a-z]/.test(c)) { let j = i; while (j < s.length && /[a-z]/.test(s[j])) j++; const w = s.slice(i, j); if (w === "pi") toks.push({ t: "n", v: Math.PI }); else if (w === "e") toks.push({ t: "n", v: Math.E }); else if (["sqrt", "sin", "cos", "tan", "log", "ln", "abs"].includes(w)) toks.push({ t: "f", v: w }); else throw new Error("Unknown name " + w); i = j; } else if ("+-*/^%()".includes(c)) { toks.push({ t: "o", v: c }); i++; } else throw new Error("Unexpected " + c); }
  let p = 0; const peek = () => toks[p]; const isOp = (v: string) => peek()?.t === "o" && (peek() as { v: string }).v === v;
  const expr = (): number => { let a = term(); while (isOp("+") || isOp("-")) { const o = (toks[p++] as { v: string }).v; const b = term(); a = o === "+" ? a + b : a - b; } return a; };
  const term = (): number => { let a = unary(); while (isOp("*") || isOp("/") || isOp("%")) { const o = (toks[p++] as { v: string }).v; const b = unary(); if (o !== "*" && b === 0) throw new Error("Division by zero"); a = o === "*" ? a * b : o === "/" ? a / b : a % b; } return a; };
  const unary = (): number => { if (isOp("-")) { p++; return -unary(); } if (isOp("+")) { p++; return unary(); } return pow(); };
  const pow = (): number => { const a = atom(); if (isOp("^")) { p++; return Math.pow(a, unary()); } return a; };
  const atom = (): number => { const t = toks[p++]; if (!t) throw new Error("Unexpected end"); if (t.t === "n") return t.v; if (t.t === "f") { if (!isOp("(")) throw new Error("Expected ( after " + t.v); p++; const v = expr(); if (!isOp(")")) throw new Error("Missing )"); p++; const f: Record<string, (x: number) => number> = { sqrt: Math.sqrt, sin: Math.sin, cos: Math.cos, tan: Math.tan, log: Math.log10, ln: Math.log, abs: Math.abs }; if (t.v === "sqrt" && v < 0) throw new Error("sqrt of negative"); return f[t.v](v); } if (t.v === "(") { const v = expr(); if (!isOp(")")) throw new Error("Missing )"); p++; return v; } throw new Error("Unexpected " + t.v); };
  const r = expr(); if (p < toks.length) throw new Error("Unexpected input"); if (!isFinite(r)) throw new Error("Result is not finite"); return r;
}
export function Calculator() {
  const [e, setE] = useState(""); const [r, setR] = useState(""); const [h, setH] = useState<string[]>([]);
  const press = (k: string) => { if (k === "C") { setE(""); setR(""); } else if (k === "⌫") setE((x) => x.slice(0, -1)); else if (k === "=") { try { const v = calc(e); const out = String(Math.round(v * 1e12) / 1e12); setR(out); setH((x) => [`${e} = ${out}`, ...x].slice(0, 20)); setE(out); } catch (er) { setR((er as Error).message); } } else setE((x) => x + k); };
  const keys = ["C", "(", ")", "⌫", "sqrt(", "^", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "-", "1", "2", "3", "+", "π", "0", ".", "="];
  return <div className="col" style={{ padding: 12, height: "100%" }} onKeyDown={(ev) => { if (ev.key === "Enter") { ev.preventDefault(); press("="); } else if (ev.key === "Backspace") press("⌫"); else if (ev.key === "Escape") press("C"); else if (/^[0-9+\-*/().^%]$/.test(ev.key)) press(ev.key); }} tabIndex={0} aria-label="Calculator">
    <input className="input" readOnly value={e} aria-label="Expression" style={{ fontSize: 22, textAlign: "right" }} /><div className="dim" style={{ textAlign: "right", minHeight: 20 }} role="status">{r}</div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6 }}>{keys.map((k) => <button key={k} className={"btn" + (k === "=" ? " primary" : "")} style={{ minHeight: 42, fontSize: 16 }} onClick={() => press(k)}>{k}</button>)}</div>
    <div className="scroll small dim grow">{h.map((x, i) => <div key={i}>{x}</div>)}</div></div>;
}

/* ---------- Calendar ---------- */
interface Ev { id: string; date: string; title: string; time: string }
const CAL = "/Users/Default/Documents/calendar.json";
export function Calendar() {
  const [d, setD] = useState(() => new Date()); const [ev, reload] = useFs(() => fs.json<Ev[]>(CAL, []), [], [] as Ev[]); const [sel, setSel] = useState(() => new Date().toISOString().slice(0, 10)); const [title, setTitleS] = useState(""); const [time, setTime] = useState("09:00"); const region = useSetting("region");
  const y = d.getFullYear(), m = d.getMonth(); const first = new Date(y, m, 1).getDay(); const days = new Date(y, m + 1, 0).getDate(); const cells = Array.from({ length: Math.ceil((first + days) / 7) * 7 }, (_, i) => i - first + 1);
  const key = (n: number) => `${y}-${String(m + 1).padStart(2, "0")}-${String(n).padStart(2, "0")}`;
  const hol = (n: number) => (HOLIDAYS[region] ?? []).find((h) => h.m === m + 1 && h.d === n);
  const save = async (l: Ev[]) => { await fs.writeFile(CAL, JSON.stringify(l), { mime: "application/json" }); reload(); };
  return <div className="row" style={{ height: "100%", alignItems: "stretch" }}>
    <div className="col grow" style={{ padding: 12 }}><div className="row"><button className="btn sm" onClick={() => setD(new Date(y, m - 1, 1))} aria-label="Previous month">←</button><b className="grow" style={{ textAlign: "center" }}>{d.toLocaleDateString([], { month: "long", year: "numeric" })}</b><button className="btn sm" onClick={() => setD(new Date(y, m + 1, 1))} aria-label="Next month">→</button><button className="btn sm" onClick={() => setD(new Date())}>Today</button></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 3 }}>{["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((x) => <div key={x} className="dim small" style={{ textAlign: "center" }}>{x}</div>)}{cells.map((n, i) => n < 1 || n > days ? <div key={i} /> : <button key={i} className="btn" onClick={() => setSel(key(n))} style={{ minHeight: 56, alignItems: "flex-start", justifyContent: "flex-start", flexDirection: "column", outline: sel === key(n) ? "2px solid var(--accent)" : "none", background: key(n) === new Date().toISOString().slice(0, 10) ? "color-mix(in srgb, var(--accent) 30%, transparent)" : undefined }}><span>{n}</span>{ev.some((e) => e.date === key(n)) && <span style={{ color: "var(--accent)" }}>●</span>}{hol(n) && <span className="small" style={{ color: "var(--ok)", fontSize: 10 }}>{hol(n)!.name}</span>}</button>)}</div></div>
    <div className="col solid" style={{ width: 240, padding: 12, borderLeft: "1px solid var(--border)" }}><b>{sel}</b>{ev.filter((e) => e.date === sel).sort((a, b) => a.time.localeCompare(b.time)).map((e) => <div key={e.id} className="row card small"><span className="grow">{e.time} {e.title}</span><button className="btn sm ghost" aria-label="Delete event" onClick={() => save(ev.filter((x) => x.id !== e.id))}>×</button></div>)}
      <input className="input" placeholder="New event" value={title} onChange={(e) => setTitleS(e.target.value)} aria-label="Event title" /><input className="input" type="time" value={time} onChange={(e) => setTime(e.target.value)} aria-label="Time" /><button className="btn primary" disabled={!title.trim()} onClick={async () => { await save([...ev, { id: crypto.randomUUID(), date: sel, title: title.trim(), time }]); setTitleS(""); }}>Add event</button><div className="dim small">Holidays shown are fixed-date only for your selected region.</div></div></div>;
}

/* ---------- Notes ---------- */
const NOTES = "/Users/Default/Documents/Notes";
export function Notes() {
  const [list, reload] = useFs(async () => { try { return (await fs.list(NOTES)).filter((n) => n.type === "file").sort((a, b) => b.modified - a.modified); } catch { return []; } }, [], [] as FsNode[]);
  const [cur, setCur] = useState(""); const [text, setText] = useState(""); const t = useRef<ReturnType<typeof setTimeout> | null>(null);
  const open = async (p: string) => { setCur(p); setText(await fs.readText(p)); };
  const persist = (p: string, v: string) => { if (t.current) clearTimeout(t.current); t.current = setTimeout(() => { void fs.writeFile(p, v).then(reload); }, 400); };
  useEffect(() => { if (!cur && list[0]) void open(list[0].path); }, [list, cur]);
  return <div className="app"><div className="sidebar" style={{ width: 200 }}><button className="btn primary" onClick={async () => { const p = await fs.uniquePath(`${NOTES}/Note.md`); await fs.writeFile(p, "# New note\n"); reload(); await open(p); }}>+ New note</button>{list.map((n) => <button key={n.path} className={"side-item" + (cur === n.path ? " active" : "")} onClick={() => open(n.path)} onContextMenu={(e) => showMenu(e, [{ label: "Rename", action: async () => { const nn = await promptBox("Rename note", "Name", n.name); if (nn) { await fs.rename(n.path, nn.endsWith(".md") ? nn : nn + ".md"); reload(); setCur(""); } } }, { label: "Move to Trash", danger: true, action: async () => { await fs.trash(n.path); setCur(""); reload(); } }])}><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{n.name.replace(/\.md$/, "")}</span></button>)}{!list.length && <div className="dim small">No notes yet.</div>}</div>
    <div className="col grow" style={{ padding: 10 }}>{cur ? <><div className="dim small">{basename(cur)} · saved automatically to NeuxFS</div><textarea className="input grow" style={{ resize: "none" }} value={text} onChange={(e) => { setText(e.target.value); persist(cur, e.target.value); }} aria-label="Note text" /></> : <Empty>Create a note to begin.</Empty>}</div></div>;
}

/* ---------- Gallery ---------- */
export function Gallery() {
  const { params, rev } = useWin(); const [imgs] = useFs(async () => (await fs.all()).filter((n) => n.type === "file" && kindOf(n.name) === "image" && extOf(n.name) !== "wrphoto" && !n.path.startsWith("/Trash") && !n.path.startsWith("/Applications") && !n.path.startsWith("/System")).sort((a, b) => b.modified - a.modified), [], [] as FsNode[]);
  const [cur, setCur] = useState(""); const node = imgs.find((i) => i.path === cur); const url = useObjectUrl(node?.data); const [z, setZ] = useState(1);
  useEffect(() => { if (params.path) { setCur(String(params.path)); setZ(1); } }, [rev, params.path]);
  const idx = imgs.findIndex((i) => i.path === cur);
  useShortcut("gen.delete", () => { if (!node) return false; void fs.trash(node.path).then(() => setCur("")); }, [node]);
  if (node) return <div className="col" style={{ height: "100%", gap: 0, background: "#000" }}><div className="toolbar" style={{ background: "var(--surface-solid)" }}><button className="btn sm" onClick={() => setCur("")}>← Grid</button><button className="btn sm" disabled={idx <= 0} onClick={() => setCur(imgs[idx - 1].path)}>‹</button><button className="btn sm" disabled={idx >= imgs.length - 1} onClick={() => setCur(imgs[idx + 1].path)}>›</button><span className="small grow" style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{node.name} · {formatBytes(node.size)}</span><button className="btn sm" onClick={() => setZ((x) => Math.min(6, x * 1.3))}>+</button><button className="btn sm" onClick={() => setZ((x) => Math.max(0.2, x / 1.3))}>−</button><button className="btn sm" onClick={() => setZ(1)}>Fit</button><button className="btn sm primary" onClick={() => openApp("photo", { path: node.path })}>Edit in Photo</button><button className="btn sm" onClick={() => setSetting("wallpaper", "fs:" + node.path)}>Wallpaper</button><button className="btn sm danger" onClick={async () => { await fs.trash(node.path); setCur(""); }}>Trash</button></div>
    <div className="grow scroll" style={{ display: "grid", placeItems: "center" }}>{/* eslint-disable-next-line @next/next/no-img-element */}{url && <img src={url} alt={node.name} style={{ maxWidth: z === 1 ? "100%" : "none", maxHeight: z === 1 ? "100%" : "none", width: z === 1 ? undefined : `${z * 100}%`, objectFit: "contain" }} onError={() => alertBox("Cannot display", "This browser cannot decode " + node.name)} />}</div></div>;
  return <div className="scroll" style={{ padding: 12, height: "100%" }}>{imgs.length === 0 ? <Empty>No images yet. Download or import pictures into NeuxFS, or take a screenshot.</Empty> : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(130px,1fr))", gap: 8 }}>{imgs.map((n) => <Thumb key={n.path} n={n} onOpen={() => { setCur(n.path); setZ(1); }} />)}</div>}</div>;
}
function Thumb({ n, onOpen }: { n: FsNode; onOpen: () => void }) { const u = useObjectUrl(n.data); return <button className="card" style={{ padding: 0, overflow: "hidden", cursor: "pointer", aspectRatio: "1" }} onClick={onOpen} aria-label={n.name}>{/* eslint-disable-next-line @next/next/no-img-element */}{u && <img src={u} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />}</button>; }

/* ---------- Text editor ---------- */
export function TextEditor() {
  const win = useWin(); const [path, setPath] = useState(""); const [text, setText] = useState(""); const [saved, setSaved] = useState(""); const [err, setErr] = useState(""); const ro = !!win.params.readonly;
  const load = useCallback(async (p: string) => { try { const b = await fs.readBlob(p); if (b.size > 5_000_000) return setErr("File too large for the text editor (5 MB limit)."); setText(await b.text()); setSaved(await b.text()); setPath(p); setErr(""); setTitle(win.id, "Text Editor — " + basename(p)); } catch (e) { setErr((e as Error).message); } }, [win.id]);
  useEffect(() => { if (win.params.path) void load(String(win.params.path)); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  const dirty = text !== saved; useEffect(() => { setCloseGuard(win.id, () => !dirty || confirm("Discard unsaved changes?")); return () => setCloseGuard(win.id, null); }, [dirty, win.id]);
  const save = async () => { if (ro) return; if (!path) return void saveAs(); await fs.writeFile(path, text); setSaved(text); };
  const saveAs = async () => { const p = await pickFile({ mode: "save", title: "Save as", startPath: "/Users/Default/Documents", defaultName: path ? basename(path) : "Untitled.txt" }); if (!p) return; await fs.writeFile(p[0], text); setPath(p[0]); setSaved(text); setTitle(win.id, "Text Editor — " + basename(p[0])); };
  useShortcut("gen.save", save, [text, path]); useShortcut("gen.saveAs", saveAs, [text]); useShortcut("gen.open", async () => { const p = await pickFile({ filter: "code", title: "Open text file" }); if (p) await load(p[0]); }, []);
  return <div className="col" style={{ height: "100%", gap: 0 }}><div className="toolbar"><button className="btn sm" onClick={async () => { const p = await pickFile({ filter: "code", title: "Open text file" }); if (p) await load(p[0]); }}>Open…</button><button className="btn sm primary" disabled={ro || (!dirty && !!path)} onClick={save}>Save</button><button className="btn sm" onClick={saveAs} disabled={ro}>Save as…</button><span className="grow dim small">{path || "Untitled"}{dirty ? " ●" : ""}{ro ? " · read-only" : ""}</span><span className="dim small">{text.length} chars · {text.split(/\s+/).filter(Boolean).length} words</span></div>
    {err && <div role="alert" className="card small" style={{ margin: 8, borderColor: "var(--danger)" }}>{err}</div>}<textarea className="input grow mono" style={{ resize: "none", borderRadius: 0, border: 0 }} value={text} readOnly={ro} onChange={(e) => setText(e.target.value)} aria-label="Document" spellCheck={false} /></div>;
}

/* ---------- Screenshot ---------- */
export function Screenshot() {
  const [shot, setShot] = useState<Blob | null>(null); const url = useObjectUrl(shot); const [msg, setMsg] = useState("");
  const capture = async () => {
    try {
      const md = navigator.mediaDevices as MediaDevices & { getDisplayMedia?: (c?: object) => Promise<MediaStream> }; if (!md?.getDisplayMedia) return setMsg("Screen capture is not supported by this browser/device.");
      const st = await md.getDisplayMedia({ video: true, audio: false }); const v = document.createElement("video"); v.srcObject = st; v.muted = true; await v.play(); await new Promise((r) => setTimeout(r, 250));
      const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext("2d")!.drawImage(v, 0, 0); st.getTracks().forEach((t) => t.stop());
      const b = await new Promise<Blob | null>((r) => c.toBlob(r, "image/png")); if (b) { setShot(b); setMsg(`Captured ${c.width}×${c.height}. Not saved yet.`); }
    } catch (e) { setMsg((e as Error).name === "NotAllowedError" ? "Capture cancelled or permission denied." : (e as Error).message); }
  };
  return <div className="col" style={{ padding: 14, height: "100%" }}><div className="dim small">You choose a screen, window or tab in your browser&apos;s own picker; Neux cannot capture anything silently.</div><div className="row"><button className="btn primary" onClick={capture}>Take screenshot…</button><button className="btn" disabled={!shot} onClick={async () => { const p = await fs.uniquePath(`/Users/Default/Pictures/Screenshots/Screenshot ${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.png`); await fs.writeFile(p, shot!); setMsg("Saved " + p); notify({ title: "Screenshot saved", message: basename(p), appId: "gallery" }); }}>Save to Pictures</button><button className="btn" disabled={!shot} onClick={() => shot && downloadBlob(shot, "screenshot.png")}>Download</button><button className="btn" disabled={!shot} onClick={async () => { try { await navigator.clipboard.write([new ClipboardItem({ "image/png": shot! })]); setMsg("Copied to clipboard"); } catch (e) { setMsg((e as Error).message); } }}>Copy</button></div>{msg && <div role="status" className="small">{msg}</div>}<div className="grow scroll card" style={{ display: "grid", placeItems: "center" }}>{/* eslint-disable-next-line @next/next/no-img-element */}{url ? <img src={url} alt="Screenshot preview" style={{ maxWidth: "100%" }} /> : <span className="dim">No screenshot yet</span>}</div></div>;
}

/* ---------- Archive ---------- */
export function Archive() {
  const [msg, setMsg] = useState(""); const [entries, setEntries] = useState<{ path: string; name: string; entries: [string, number][] } | null>(null);
  return <div className="col scroll" style={{ padding: 16, height: "100%" }}><b>Create archive</b><div className="row"><button className="btn primary" onClick={async () => { const p = await pickFile({ filter: "all", multiple: true, title: "Choose files to archive" }); if (!p) return; const dest = await pickFile({ mode: "save", title: "Save archive as", defaultName: "archive.zip", startPath: dirname(p[0]) }); if (!dest) return; try { const n = await archivePaths(fs, p, dest[0].endsWith(".zip") ? dest[0] : dest[0] + ".zip"); setMsg(`Created archive with ${n} file(s)`); } catch (e) { setMsg((e as Error).message); } }}>Choose files…</button></div>
    <b>Open / extract</b><div className="row"><button className="btn" onClick={async () => { const p = await pickFile({ filter: "archive", title: "Choose a .zip" }); if (!p) return; try { const z = unzipSync(await fs.readBytes(p[0])); setEntries({ path: p[0], name: basename(p[0]), entries: Object.entries(z).map(([k, v]) => [k, v.length] as [string, number]) }); } catch (e) { setMsg("Not a valid ZIP: " + (e as Error).message); } }}>Open archive…</button></div>
    {entries && <div className="card col small"><b>{entries.name}</b> · {entries.entries.length} entries<div className="scroll" style={{ maxHeight: 200 }}>{entries.entries.map(([k, s]) => <div key={k} className="row"><span className="grow mono">{k}</span><span className="dim">{formatBytes(s)}</span></div>)}</div><button className="btn primary" style={{ alignSelf: "flex-start" }} onClick={async () => { try { const n = await unarchive(fs, entries.path); setMsg(`Extracted ${n} file(s) next to the archive`); } catch (e) { setMsg((e as Error).message); } }}>Extract here</button></div>}{msg && <div role="status">{msg}</div>}</div>;
}

/* ---------- Share ---------- */
export function Share() {
  const [path, setPath] = useState(""); const [msg, setMsg] = useState("");
  const share = async () => { try { const b = await fs.readBlob(path); const f = new File([b], basename(path), { type: b.type }); if (navigator.canShare?.({ files: [f] })) { await navigator.share({ files: [f], title: basename(path) }); setMsg("Shared via the system share sheet."); } else setMsg("This browser cannot share files. Use Download instead."); } catch (e) { setMsg((e as Error).name === "AbortError" ? "Share cancelled." : (e as Error).message); } };
  return <div className="col" style={{ padding: 16 }}><b>Share a file</b><div className="dim small">Uses your system&apos;s share sheet (Web Share API). Only the file you pick is sent, and only when you confirm in the system dialog.</div><div className="row"><button className="btn" onClick={async () => { const p = await pickFile({ filter: "all", title: "Choose a file to share" }); if (p) setPath(p[0]); }}>Choose file…</button><span className="small grow">{path || "No file"}</span></div><div className="row"><button className="btn primary" disabled={!path} onClick={share}>Share…</button><button className="btn" disabled={!path} onClick={async () => downloadBlob(await fs.readBlob(path), basename(path))}>Download copy</button></div>{msg && <div role="status" className="small">{msg}</div>}</div>;
}

/* ---------- PDF viewer ---------- */
export function PdfViewer() {
  const win = useWin(); const [path, setPath] = useState(String(win.params.path ?? "")); const [blob, setBlob] = useState<Blob | null>(null); const url = useObjectUrl(blob); const [err, setErr] = useState("");
  const load = useCallback(async (p: string) => { try { const b = await fs.readBlob(p); setBlob(new Blob([b], { type: "application/pdf" })); setPath(p); setTitle(win.id, "PDF Viewer — " + basename(p)); setErr(""); } catch (e) { setErr((e as Error).message); } }, [win.id]);
  useEffect(() => { if (win.params.path) void load(String(win.params.path)); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [win.rev]);
  useShortcut("gen.open", async () => { const p = await pickFile({ filter: "document", title: "Open PDF" }); if (p) await load(p[0]); }, []);
  return <div className="col" style={{ height: "100%", gap: 0 }}><div className="toolbar"><button className="btn sm" onClick={async () => { const p = await pickFile({ filter: "document", title: "Open PDF" }); if (p) await load(p[0]); }}>Open…</button><span className="small dim grow">{path}</span>{blob && <button className="btn sm" onClick={() => downloadBlob(blob, basename(path))}>Download</button>}</div>{err && <div role="alert" className="card small">{err}</div>}{url ? <iframe title="PDF" src={url} style={{ flex: 1, border: 0, background: "#444" }} sandbox="allow-same-origin allow-scripts allow-downloads" /> : <Empty>Open a PDF. Rendering uses your browser&apos;s built-in PDF viewer; some mobile browsers do not include one.</Empty>}</div>;
}
void Glyph; void useMemo; void join; void confirmBox;
