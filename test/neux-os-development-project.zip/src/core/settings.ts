import { createStore, useStore } from "./store";
import { fs } from "./kernel";

export interface Settings {
  theme: "dark" | "light" | "auto"; accent: string; wallpaper: string; blur: boolean; reduceMotion: boolean;
  highContrast: boolean; fontScale: number; language: string; secondaryLanguage: string; region: string;
  timezone: string; currency: string; setupDone: boolean; autoUpdate: boolean; channel: "stable" | "beta" | "developer";
  allowVM: boolean; isolation: boolean; volume: number; muted: boolean; pinned: string[];
  shortcuts: Record<string, string>; assoc: Record<string, string>; searchEngine: string; widgets: string[];
  beecoUrl: string; vmRegistry: string[]; extensionsEnabled: Record<string, boolean>; use24h: boolean;
}
export const DEFAULTS: Settings = {
  theme: "dark", accent: "#5b8cff", wallpaper: "aurora", blur: true, reduceMotion: false, highContrast: false,
  fontScale: 1, language: "en-US", secondaryLanguage: "", region: "", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
  currency: "USD", setupDone: false, autoUpdate: true, channel: "stable", allowVM: false, isolation: false, volume: 0.8, muted: false,
  pinned: [], shortcuts: {}, assoc: {}, searchEngine: "duckduckgo", widgets: ["clock"], beecoUrl: "", vmRegistry: [],
  extensionsEnabled: {}, use24h: true,
};
export const settingsStore = createStore<Settings>({ ...DEFAULTS });
const PATH = "/Configuration/settings.json";
let timer: ReturnType<typeof setTimeout> | null = null;

export async function loadSettings() {
  const saved = await fs.json<Partial<Settings>>(PATH, {});
  settingsStore.set({ ...DEFAULTS, ...saved });
}
export function setSetting<K extends keyof Settings>(k: K, v: Settings[K]) {
  settingsStore.set({ [k]: v } as Partial<Settings>);
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => { fs.saveJson(PATH, settingsStore.get()).catch(() => {}); }, 150);
}
export const getSetting = <K extends keyof Settings>(k: K): Settings[K] => settingsStore.get()[k];
export const useSetting = <K extends keyof Settings>(k: K): Settings[K] => useStore(settingsStore, (s) => s[k]);
export async function flushSettings() { if (timer) clearTimeout(timer); await fs.saveJson(PATH, settingsStore.get()); }

export const LANGUAGES: [string, string][] = [
  ["en-US", "English (United States)"], ["ru", "Русский"], ["uk", "Українська"], ["sr-Cyrl", "Српски (ћирилица)"],
  ["sr-Latn", "Srpski (latinica)"], ["pl", "Polski"], ["ro", "Română"], ["fr", "Français"], ["de", "Deutsch"],
  ["es", "Español"], ["pt", "Português"], ["it", "Italiano"], ["tr", "Türkçe"], ["hi", "हिन्दी"], ["ja", "日本語"], ["zh-Hans", "简体中文"],
];

/** Regions: US and Ukraine pinned, the rest alphabetical. Choosing a region never implies identity or citizenship. */
const OTHER_REGIONS = ["Argentina","Australia","Austria","Belgium","Brazil","Bulgaria","Canada","China","Croatia","Czechia","Denmark","Egypt","Estonia","Finland","France","Germany","Greece","Hungary","India","Ireland","Israel","Italy","Japan","Kazakhstan","Latvia","Lithuania","Mexico","Netherlands","New Zealand","Norway","Poland","Portugal","Romania","Serbia","Slovakia","Slovenia","South Africa","South Korea","Spain","Sweden","Switzerland","Turkey","United Kingdom"].sort((a, b) => a.localeCompare(b));
export const REGIONS = { pinned: ["United States", "Ukraine"], others: OTHER_REGIONS };

export function applyUkraineSuggestions() {
  setSetting("language", "uk"); setSetting("secondaryLanguage", "en-US");
  setSetting("currency", "UAH"); setSetting("timezone", "Europe/Kyiv"); setSetting("region", "Ukraine");
}

const T: Record<string, Record<string, string>> = {
  "en-US": { start: "Start", search: "Search apps, files, settings…", settings: "Settings", lock: "Lock", allApps: "All apps", pinned: "Pinned", notifications: "Notifications", noNotifs: "No notifications", desktop: "Desktop", open: "Open", cancel: "Cancel", install: "Install", uninstall: "Uninstall", save: "Save" },
  uk: { start: "Пуск", search: "Пошук програм, файлів, налаштувань…", settings: "Налаштування", lock: "Заблокувати", allApps: "Усі програми", pinned: "Закріплені", notifications: "Сповіщення", noNotifs: "Немає сповіщень", desktop: "Стіл", open: "Відкрити", cancel: "Скасувати", install: "Встановити", uninstall: "Видалити", save: "Зберегти" },
  ru: { start: "Пуск", search: "Поиск приложений, файлов, настроек…", settings: "Настройки", lock: "Заблокировать", allApps: "Все приложения", pinned: "Закреплённые", notifications: "Уведомления", noNotifs: "Нет уведомлений", desktop: "Рабочий стол", open: "Открыть", cancel: "Отмена", install: "Установить", uninstall: "Удалить", save: "Сохранить" },
  de: { start: "Start", search: "Apps, Dateien, Einstellungen suchen…", settings: "Einstellungen", lock: "Sperren", allApps: "Alle Apps", pinned: "Angeheftet", notifications: "Benachrichtigungen", noNotifs: "Keine Benachrichtigungen", desktop: "Desktop", open: "Öffnen", cancel: "Abbrechen", install: "Installieren", uninstall: "Deinstallieren", save: "Speichern" },
  fr: { start: "Démarrer", search: "Rechercher apps, fichiers, réglages…", settings: "Réglages", lock: "Verrouiller", allApps: "Toutes les apps", pinned: "Épinglées", notifications: "Notifications", noNotifs: "Aucune notification", desktop: "Bureau", open: "Ouvrir", cancel: "Annuler", install: "Installer", uninstall: "Désinstaller", save: "Enregistrer" },
  es: { start: "Inicio", search: "Buscar apps, archivos, ajustes…", settings: "Ajustes", lock: "Bloquear", allApps: "Todas las apps", pinned: "Fijadas", notifications: "Notificaciones", noNotifs: "Sin notificaciones", desktop: "Escritorio", open: "Abrir", cancel: "Cancelar", install: "Instalar", uninstall: "Desinstalar", save: "Guardar" },
  pl: { start: "Start", search: "Szukaj aplikacji, plików, ustawień…", settings: "Ustawienia", lock: "Zablokuj", allApps: "Wszystkie aplikacje", pinned: "Przypięte", notifications: "Powiadomienia", noNotifs: "Brak powiadomień", desktop: "Pulpit", open: "Otwórz", cancel: "Anuluj", install: "Zainstaluj", uninstall: "Odinstaluj", save: "Zapisz" },
};
/** Translate; languages without a table fall back to English (see docs/LOCALIZATION notes in SETUP_ASSISTANT_SPECIFICATION.md). */
export function useT() {
  const lang = useSetting("language");
  const d = T[lang] ?? T[lang.split("-")[0]] ?? T["en-US"];
  return (k: string) => d[k] ?? T["en-US"][k] ?? k;
}
export const translatedLanguages = Object.keys(T);
