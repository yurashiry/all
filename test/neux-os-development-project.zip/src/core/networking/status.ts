import { createStore } from "../store";
import { BeecoClient, BeecoServer, memoryPair, websocketTransport } from "../../protocols/beeco";

export interface NetState {
  online: boolean; connection: string;
  beeco: { state: "disconnected" | "connecting" | "connected" | "error"; detail: string; server?: string; mode?: "network" | "loopback"; latency?: number };
  vpn: { state: "off" | "on"; detail: string };
}
export const net = createStore<NetState>({
  online: true, connection: "unknown",
  beeco: { state: "disconnected", detail: "Not connected" },
  vpn: { state: "off", detail: "No VPN active (Web edition cannot create a device VPN)" },
});
let client: BeecoClient | null = null;
let loopbackServer: BeecoServer | null = null;
export const getBeecoClient = () => client;
export const getLoopbackServer = () => loopbackServer;

export function startNetworkMonitor() {
  const upd = () => {
    const c = (navigator as Navigator & { connection?: { effectiveType?: string; type?: string } }).connection;
    net.set({ online: navigator.onLine, connection: c?.type ?? c?.effectiveType ?? "n/a" });
    if (!navigator.onLine && net.get().beeco.mode === "network") { client?.close(); net.set({ beeco: { state: "disconnected", detail: "Host has no internet connection" } }); }
  };
  upd(); window.addEventListener("online", upd); window.addEventListener("offline", upd);
}
export async function connectBeeco(url: string, deviceId: string, secret: string) {
  if (!navigator.onLine) { net.set({ beeco: { state: "disconnected", detail: "No internet connection on the host. Retry when online." } }); return; }
  net.set({ beeco: { state: "connecting", detail: `Connecting to ${url}…` } });
  try {
    const t = await websocketTransport(url);
    const c = new BeecoClient(t, deviceId, secret);
    c.onClosed = () => net.set({ beeco: { state: "disconnected", detail: "Connection closed" } });
    await c.connect();
    client = c;
    const latency = await c.ping();
    net.set({ beeco: { state: "connected", detail: "Authenticated BEECO/1 session", server: c.serverName, mode: "network", latency } });
  } catch (e) { client = null; net.set({ beeco: { state: "error", detail: (e as Error).message } }); }
}
/** In-page loopback node: exercises the real protocol stack but involves no network traffic. */
export async function startLoopback(deviceId = "neux-local") {
  const secret = Array.from(crypto.getRandomValues(new Uint8Array(8))).map((b) => b.toString(16).padStart(2, "0")).join("");
  loopbackServer = new BeecoServer({ name: "BEECO Local (in-page)", secrets: { [deviceId]: secret } });
  const [a, b] = memoryPair(); loopbackServer.accept(b);
  const c = new BeecoClient(a, deviceId, secret);
  await c.connect(); client = c;
  net.set({ beeco: { state: "connected", detail: "Loopback only — protocol exercised in this page, no network traffic", server: c.serverName, mode: "loopback", latency: await c.ping() } });
}
export function disconnectBeeco() { client?.close(); client = null; net.set({ beeco: { state: "disconnected", detail: "Disconnected by user" } }); }
