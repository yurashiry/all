import { createStore } from "../store";
import { fs } from "../kernel";
import { notify } from "../os";
import { uid, mimeFor } from "../util";
import { join } from "../filesystem/neuxfs";

export type DlState = "downloading" | "paused" | "done" | "failed" | "canceled";
export interface Download { id: string; url: string; name: string; state: DlState; received: number; total: number | null; started: number; finished?: number; path?: string; mime: string; resumable: boolean; error?: string }
export const downloads = createStore<{ items: Download[] }>({ items: [] });
const HIST = "/Configuration/downloads.json";
const ctl = new Map<string, { ac: AbortController; chunks: Uint8Array[] }>();
const listeners = new Set<(d: Download) => void>();
export const onDownloadComplete = (fn: (d: Download) => void) => { listeners.add(fn); return () => { listeners.delete(fn); }; };

const patch = (id: string, p: Partial<Download>) => downloads.set((s) => ({ items: s.items.map((d) => (d.id === id ? { ...d, ...p } : d)) }));
const persist = () => fs.saveJson(HIST, downloads.get().items.filter((d) => d.state === "done" || d.state === "failed" || d.state === "canceled")).catch(() => {});
export async function loadDownloadHistory() { downloads.set({ items: await fs.json<Download[]>(HIST, []) }); }

export function nameFromUrl(url: string): string {
  try { const u = new URL(url); const n = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() ?? ""); return n || u.hostname; } catch { return "download"; }
}
export function startDownload(url: string, name?: string): string {
  const id = uid();
  const d: Download = { id, url, name: name || nameFromUrl(url), state: "downloading", received: 0, total: null, started: Date.now(), mime: mimeFor(name || nameFromUrl(url)), resumable: false };
  downloads.set((s) => ({ items: [d, ...s.items] }));
  void run(id);
  return id;
}
async function run(id: string) {
  const d = downloads.get().items.find((x) => x.id === id)!;
  const prev = ctl.get(id);
  const c = { ac: new AbortController(), chunks: prev?.chunks ?? [] };
  ctl.set(id, c);
  const start = c.chunks.reduce((a, x) => a + x.length, 0);
  patch(id, { state: "downloading", error: undefined });
  try {
    const { fetchBytes } = await import("./fetch");
    const r = await fetchBytes(d.url, { signal: c.ac.signal, start, prefix: c.chunks, onProgress: (p) => patch(id, { received: p.received, total: p.total }) });
    const unique = await fs.uniquePath(join("/Users/Default/Downloads", d.name));
    const node = await fs.writeFile(unique, r.bytes, { mime: r.contentType.split(";")[0] || d.mime, meta: { sourceUrl: d.url, downloadedAt: Date.now() } });
    ctl.delete(id);
    patch(id, { state: "done", received: r.bytes.length, total: r.bytes.length, finished: Date.now(), path: node.path, resumable: false });
    persist();
    notify({ title: "Download complete", message: node.name, appId: "explorer" });
    const done = downloads.get().items.find((x) => x.id === id)!;
    listeners.forEach((l) => l(done));
  } catch (e) {
    const partial = (e as { partial?: Uint8Array[] }).partial;
    if (partial) c.chunks = partial;
    if (c.ac.signal.aborted) return; // pause/cancel handled by caller
    const msg = e instanceof TypeError ? "Network error or the server does not allow cross-origin downloads (CORS)." : (e as Error).message;
    patch(id, { state: "failed", error: msg });
    persist();
  }
}
export function pauseDownload(id: string) {
  const c = ctl.get(id);
  if (!c) return;
  // keep what we have by snapshotting through a controlled abort: fetchBytes attaches partial on error, so abort and mark paused
  c.ac.abort();
  patch(id, { state: "paused" });
}
export function resumeDownload(id: string) { void run(id); }
export function cancelDownload(id: string) { ctl.get(id)?.ac.abort(); ctl.delete(id); patch(id, { state: "canceled" }); persist(); }
export function retryDownload(id: string) { const d = downloads.get().items.find((x) => x.id === id); if (!d) return; ctl.delete(id); patch(id, { received: 0, total: null, error: undefined }); void run(id); }
export function removeDownload(id: string) { ctl.get(id)?.ac.abort(); ctl.delete(id); downloads.set((s) => ({ items: s.items.filter((d) => d.id !== id) })); persist(); }
