import { fs } from "../kernel";
import { uid } from "../util";

export interface VpnServer { name: string; proto: string; host: string; port: number }
export interface Subscription { id: string; name: string; secret: string; servers: VpnServer[]; updated: number; kind: "url" | "file" }
const PATH = "/Configuration/vpn.json";
const KEYDB = "neux-keys";
const b64 = (u: Uint8Array) => btoa(String.fromCharCode(...u));
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

function keyDb(): Promise<IDBDatabase> {
  return new Promise((res, rej) => { const r = indexedDB.open(KEYDB, 1); r.onupgradeneeded = () => r.result.createObjectStore("k"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}
async function getKey(): Promise<CryptoKey> {
  const db = await keyDb();
  const ex = await new Promise<CryptoKey | undefined>((res) => { const q = db.transaction("k").objectStore("k").get("vpn"); q.onsuccess = () => res(q.result); q.onerror = () => res(undefined); });
  if (ex) return ex;
  const k = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]); // non-extractable
  await new Promise<void>((res) => { const t = db.transaction("k", "readwrite"); t.objectStore("k").put(k, "vpn"); t.oncomplete = () => res(); });
  return k;
}
export async function encryptSecret(s: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await getKey(), new TextEncoder().encode(s)));
  return b64(iv) + ":" + b64(ct);
}
export async function decryptSecret(s: string): Promise<string> {
  const [iv, ct] = s.split(":");
  return new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(iv) as BufferSource }, await getKey(), unb64(ct) as BufferSource));
}
export function parseSubscription(text: string): VpnServer[] {
  let t = text.trim();
  if (!/^[a-z0-9]+:\/\//i.test(t.split("\n")[0])) { try { t = atob(t.replace(/\s/g, "")); } catch { /* maybe plain */ } }
  const out: VpnServer[] = [];
  for (const line of t.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)) {
    const m = line.match(/^(vless|vmess|trojan|ss|hysteria2|hy2|tuic|wireguard):\/\/(.+)$/i);
    if (!m) continue;
    const proto = m[1].toLowerCase();
    try {
      if (proto === "vmess") { const j = JSON.parse(atob(m[2])); out.push({ name: j.ps || j.add, proto, host: j.add, port: Number(j.port) }); continue; }
      const u = new URL(line);
      if (u.hostname) out.push({ name: decodeURIComponent(u.hash.slice(1)) || u.hostname, proto, host: u.hostname, port: Number(u.port) || 0 });
    } catch { /* skip malformed line */ }
  }
  return out;
}
export const listSubscriptions = () => fs.json<Subscription[]>(PATH, []);
export async function addSubscription(name: string, kind: "url" | "file", source: string, content: string): Promise<Subscription> {
  const servers = parseSubscription(content);
  if (!servers.length) throw new Error("No supported server entries found (vless, vmess, trojan, ss, hysteria2, tuic, wireguard).");
  const sub: Subscription = { id: uid(), name: name || "Subscription", kind, secret: await encryptSecret(source), servers, updated: Date.now() };
  await fs.saveJson(PATH, [...(await listSubscriptions()), sub]);
  return sub;
}
export async function refreshSubscription(id: string) {
  const subs = await listSubscriptions();
  const s = subs.find((x) => x.id === id);
  if (!s || s.kind !== "url") throw new Error("Only URL subscriptions can be refreshed");
  const url = await decryptSecret(s.secret);
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const servers = parseSubscription(await r.text());
  if (!servers.length) throw new Error("Refreshed subscription contained no servers");
  s.servers = servers; s.updated = Date.now();
  await fs.saveJson(PATH, subs);
}
export async function removeSubscription(id: string) { await fs.saveJson(PATH, (await listSubscriptions()).filter((s) => s.id !== id)); }
