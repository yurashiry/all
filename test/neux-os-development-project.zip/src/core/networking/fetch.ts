/** Streaming fetch with real byte-level progress. Never fabricates progress. */
export interface FetchProgress { received: number; total: number | null }
export interface FetchResult { bytes: Uint8Array; status: number; acceptRanges: boolean; total: number | null; contentType: string }
export async function fetchBytes(url: string, o: { signal?: AbortSignal; onProgress?: (p: FetchProgress) => void; start?: number; prefix?: Uint8Array[]; fallbackTotal?: number } = {}): Promise<FetchResult> {
  const headers: Record<string, string> = {};
  if (o.start) headers.Range = `bytes=${o.start}-`;
  const res = await fetch(url, { signal: o.signal, headers, cache: "no-store" });
  if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status} ${res.statusText}`);
  const resumed = res.status === 206 && !!o.start;
  const base = resumed ? o.start! : 0;
  const len = Number(res.headers.get("content-length"));
  let total: number | null = null;
  const cr = res.headers.get("content-range")?.match(/\/(\d+)$/);
  if (cr) total = Number(cr[1]); else if (len > 0) total = base + len; else if (o.fallbackTotal) total = o.fallbackTotal;
  const chunks: Uint8Array[] = resumed && o.prefix ? [...o.prefix] : [];
  let received = base;
  if (!res.body) {
    const b = new Uint8Array(await res.arrayBuffer());
    o.onProgress?.({ received: b.length, total: b.length });
    return { bytes: b, status: res.status, acceptRanges: false, total: b.length, contentType: res.headers.get("content-type") ?? "" };
  }
  const r = res.body.getReader();
  try {
    for (;;) {
      const { done, value } = await r.read();
      if (done) break;
      chunks.push(value); received += value.length;
      o.onProgress?.({ received, total });
    }
  } catch (e) {
    (e as { partial?: Uint8Array[] }).partial = chunks;
    throw e;
  }
  const out = new Uint8Array(received);
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.length; }
  return { bytes: out, status: res.status, acceptRanges: res.headers.get("accept-ranges") === "bytes" || resumed, total: total ?? received, contentType: res.headers.get("content-type") ?? "" };
}
