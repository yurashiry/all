import { fs, NEUX_VERSION } from "./kernel";
import { DEFAULT_TREE } from "./filesystem/neuxfs";
import { refreshInstalled, validateManifest } from "./applications/wrapp";
import { sha256Hex } from "./util";

export interface Check { name: string; ok: boolean; detail: string }
/** Application-level integrity check (NOT host recovery). With repair=true missing system folders are recreated. */
export async function runIntegrityCheck(repair: boolean): Promise<Check[]> {
  const out: Check[] = [];
  let missing = 0;
  for (const d of DEFAULT_TREE) if (!(await fs.exists(d))) { missing++; if (repair) await fs.mkdir(d, { role: "root" }, true); }
  out.push({ name: "System folder tree", ok: missing === 0 || repair, detail: missing ? (repair ? `${missing} missing folder(s) recreated` : `${missing} folder(s) missing`) : `${DEFAULT_TREE.length} folders present` });
  for (const f of ["/Configuration/settings.json", "/Configuration/users.json", "/Configuration/security.json", "/Configuration/permissions.json"]) {
    if (!(await fs.exists(f))) { out.push({ name: f, ok: true, detail: "not created yet (defaults in use)" }); continue; }
    try { const t = await fs.readText(f); JSON.parse(t); out.push({ name: f, ok: true, detail: "valid JSON, sha256 " + (await sha256Hex(new TextEncoder().encode(t))).slice(0, 16) + "…" }); }
    catch { out.push({ name: f, ok: false, detail: "corrupted JSON — restore a backup or use Factory Reset" }); }
  }
  let dirs: { path: string; type: string; name: string }[] = [];
  try { dirs = await fs.list("/Applications"); } catch { /* none */ }
  let bad = 0;
  for (const d of dirs.filter((x) => x.type === "dir")) {
    try { const m = validateManifest(JSON.parse(await fs.readText(`${d.path}/manifest.json`))); if (!(await fs.exists(`${d.path}/${m.icon}`))) throw new Error("icon missing"); if (m.type === "html" && !(await fs.exists(`${d.path}/${m.entry}`))) throw new Error("entry missing"); }
    catch (e) { bad++; out.push({ name: `App ${d.name}`, ok: false, detail: (e as Error).message + (repair ? " — removed" : "") }); if (repair) await fs.remove(d.path, { role: "root" }); }
  }
  out.push({ name: "Installed applications", ok: bad === 0 || repair, detail: `${dirs.length - bad} healthy, ${bad} damaged` });
  if (repair) await refreshInstalled();
  try { const p = "/Temporary/.storage-check"; const probe = crypto.getRandomValues(new Uint8Array(1024)); await fs.writeFile(p, probe, { role: "root" }); const back = await fs.readBytes(p); const same = back.length === 1024 && back.every((b, i) => b === probe[i]); await fs.remove(p, { role: "root" }); out.push({ name: "Storage read/write check", ok: same, detail: same ? "1 KiB round trip verified" : "mismatch!" }); }
  catch (e) { out.push({ name: "Storage read/write check", ok: false, detail: (e as Error).message }); }
  out.push({ name: "Neux version", ok: true, detail: NEUX_VERSION });
  return out;
}
