import type { Permission } from "../permissions";

export interface AppMeta {
  id: string; name: string; title?: string; category: string; w: number; h: number; singleton?: boolean;
  instanceKey?: (p: Record<string, unknown>) => unknown; builtin: boolean; description?: string; icon?: string; system?: boolean;
}
const B = (id: string, name: string, category: string, w: number, h: number, extra: Partial<AppMeta> = {}): AppMeta =>
  ({ id, name, category, w, h, builtin: true, singleton: false, ...extra });

export const BUILTIN: AppMeta[] = [
  B("explorer", "Explorer", "System", 900, 580, { description: "Files and folders in NeuxFS" }),
  B("browser", "Browser", "Internet", 1000, 650, { description: "Tabs, bookmarks, history, downloads" }),
  B("store", "Store", "System", 960, 640, { singleton: true, description: "Install apps from the Neux catalog" }),
  B("settings", "Settings", "System", 960, 640, { singleton: true, system: true, description: "System settings" }),
  B("developer", "Developer", "Developer", 1040, 660, { description: "Code editor, preview and NXL" }),
  B("console", "Console", "Developer", 760, 460, { description: "Neux command line" }),
  B("media", "Media", "Media", 1080, 680, { singleton: true, description: "Music, video, lyrics, playlists" }),
  B("calculator", "Calculator", "Utilities", 340, 480, { singleton: true }),
  B("calendar", "Calendar", "Utilities", 760, 560, { singleton: true }),
  B("notes", "Notes", "Utilities", 760, 520, { singleton: true }),
  B("gallery", "Gallery", "Media", 900, 600, { singleton: true }),
  B("texteditor", "Text Editor", "Utilities", 760, 520),
  B("screenshot", "Screenshot", "Utilities", 620, 480, { singleton: true }),
  B("sysmonitor", "System Monitor", "System", 720, 520, { singleton: true }),
  B("archive", "Archive", "Utilities", 640, 480, { singleton: true }),
  B("share", "Share", "Utilities", 520, 420, { singleton: true }),
  B("backup", "Backup", "System", 620, 460, { singleton: true }),
  B("diagnostics", "Diagnostics", "System", 760, 560, { singleton: true }),
  B("themes", "Themes", "System", 760, 520, { singleton: true }),
  B("widgets", "Widgets", "System", 560, 440, { singleton: true }),
  B("appbuilder", "App Builder", "Developer", 760, 600, { singleton: true }),
  B("taskmanager", "Task Manager", "System", 700, 480, { singleton: true, system: true }),
  B("photo", "Photo", "Media", 1120, 700, { title: "Neux Photo" }),
  B("secure", "Secure Center", "Security", 860, 620, { singleton: true, system: true, description: "WR Security Centre" }),
  B("recovery", "Recovery", "System", 760, 560, { singleton: true, system: true }),
  B("pdf", "PDF Viewer", "Utilities", 820, 640),
  B("vpn", "VPN Manager", "Network", 820, 580, { singleton: true }),
  B("beeco", "BEECO", "Network", 820, 580, { singleton: true, description: "BEECO/1 network layer" }),
  B("installer", "Package Installer", "System", 560, 520, { system: true }),
  B("runtime", "Runtime", "Developer", 640, 440, { description: "Runs .wr / NXL programs" }),
  B("picker", "File Picker", "System", 780, 520, { system: true }),
  B("openwith", "Open With", "System", 460, 420, { system: true }),
];

export interface InstalledMeta { id: string; name: string; category: string; type: "web" | "html"; w: number; h: number; description: string; permissions: Permission[] }
const installed = new Map<string, InstalledMeta>();
export function setInstalledMeta(list: InstalledMeta[]) { installed.clear(); list.forEach((m) => installed.set(m.id, m)); }

export function getAppMeta(id: string, params: Record<string, unknown> = {}): AppMeta | undefined {
  const b = BUILTIN.find((a) => a.id === id);
  if (b) return b;
  if (id === "pkg") {
    const m = installed.get(String(params.pkgId));
    if (!m) return undefined;
    return { id: "pkg", name: m.name, title: m.name, category: m.category, w: m.w, h: m.h, builtin: false, singleton: true, instanceKey: (p) => p.pkgId };
  }
  return undefined;
}
export const isLaunchable = (id: string) => BUILTIN.some((b) => b.id === id && !["picker", "openwith", "installer"].includes(b.id));
