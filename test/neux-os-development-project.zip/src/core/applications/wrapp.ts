import { unzipSync, zipSync, strToU8 } from "fflate";
import { fs } from "../kernel";
import { createStore } from "../store";
import { ALL_PERMISSIONS, type Permission, grantMany, resetPermissionCache } from "../permissions";
import { setInstalledMeta, type InstalledMeta } from "./registry";
import { sha256Hex } from "../util";
import { logEvent } from "../security";
import { NEUX_VERSION } from "../kernel";

export interface Manifest {
  id: string; name: string; version: string; category: string; description: string; publisher: string;
  type: "web" | "html"; url?: string; entry?: string; icon: string; permissions: Permission[];
  window: { width: number; height: number }; compat: { platforms: string[]; minNeux: string }; verified?: boolean; channel?: string;
}
export interface InstalledApp { manifest: Manifest; iconSvg: string; installedAt: number; sha256: string; source: string }
export const installedStore = createStore<{ apps: InstalledApp[] }>({ apps: [] });
const MAX_PKG = 25 * 1024 * 1024;

export class PackageError extends Error {}
export function validateManifest(m: unknown): Manifest {
  if (!m || typeof m !== "object") throw new PackageError("manifest.json is not an object");
  const x = m as Record<string, unknown>;
  const str = (k: string, max = 400) => { if (typeof x[k] !== "string" || !(x[k] as string).trim() || (x[k] as string).length > max) throw new PackageError(`manifest.${k} missing or invalid`); return x[k] as string; };
  const id = str("id", 64);
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(id)) throw new PackageError("manifest.id must match [a-z0-9._-]");
  if (["pkg", "picker", "settings", "explorer"].includes(id)) throw new PackageError("manifest.id is reserved");
  const version = str("version", 32);
  if (!/^\d+\.\d+\.\d+([-+][\w.]+)?$/.test(version)) throw new PackageError("manifest.version must be semver");
  const type = x.type;
  if (type !== "web" && type !== "html") throw new PackageError("manifest.type must be 'web' or 'html'");
  let url: string | undefined;
  if (type === "web") {
    url = str("url", 500);
    let u: URL;
    try { u = new URL(url); } catch { throw new PackageError("manifest.url is not a valid URL"); }
    if (u.protocol !== "https:") throw new PackageError("Web apps must use https:// URLs");
  }
  const perms = Array.isArray(x.permissions) ? x.permissions : [];
  for (const p of perms) if (!(ALL_PERMISSIONS as readonly string[]).includes(p as string)) throw new PackageError(`Unknown permission: ${String(p)}`);
  const win = (x.window ?? {}) as { width?: number; height?: number };
  const compat = (x.compat ?? {}) as { platforms?: string[]; minNeux?: string };
  return { id, name: str("name", 80), version, category: str("category", 40), description: str("description", 600), publisher: typeof x.publisher === "string" ? x.publisher : "Unknown",
    type, url, entry: typeof x.entry === "string" ? x.entry : "index.html", icon: typeof x.icon === "string" ? x.icon : "assets/icon.svg", permissions: perms as Permission[],
    window: { width: Math.min(Math.max(Number(win.width) || 900, 320), 2400), height: Math.min(Math.max(Number(win.height) || 600, 240), 1600) },
    compat: { platforms: compat.platforms ?? ["web"], minNeux: compat.minNeux ?? "0.1.0" }, verified: x.verified === true, channel: typeof x.channel === "string" ? x.channel : "stable" };
}

export interface ParsedPackage { manifest: Manifest; files: Record<string, Uint8Array>; sha256: string }
export async function parseWrapp(bytes: Uint8Array, expectedSha?: string): Promise<ParsedPackage> {
  if (bytes.length > MAX_PKG) throw new PackageError("Package exceeds 25 MB limit");
  const sha256 = await sha256Hex(bytes);
  if (expectedSha && sha256 !== expectedSha) throw new PackageError(`Integrity check failed: expected ${expectedSha.slice(0, 12)}…, got ${sha256.slice(0, 12)}…`);
  let files: Record<string, Uint8Array>;
  try { files = unzipSync(bytes); } catch { throw new PackageError("Not a valid .wrapp (ZIP) archive"); }
  for (const k of Object.keys(files)) if (k.includes("..") || k.startsWith("/") || k.includes("\\")) throw new PackageError(`Unsafe path in package: ${k}`);
  const mf = files["manifest.json"];
  if (!mf) throw new PackageError("manifest.json missing");
  let json: unknown;
  try { json = JSON.parse(new TextDecoder().decode(mf)); } catch { throw new PackageError("manifest.json is not valid JSON"); }
  const manifest = validateManifest(json);
  if (!manifest.compat.platforms.includes("web") && !manifest.compat.platforms.includes("all")) throw new PackageError("Package does not declare Web compatibility");
  if (manifest.type === "html" && !files[manifest.entry ?? "index.html"]) throw new PackageError(`Entry file ${manifest.entry} missing`);
  if (!files[manifest.icon]) throw new PackageError(`Icon ${manifest.icon} missing`);
  return { manifest, files, sha256 };
}

export interface InstallHooks { onFile?: (done: number, total: number) => void; source: string; approvePermissions?: boolean }
export async function installParsed(p: ParsedPackage, h: InstallHooks) {
  const base = `/Applications/${p.manifest.id}`;
  const entries = Object.entries(p.files).filter(([k]) => !k.endsWith("/"));
  if (await fs.exists(base)) await fs.remove(base, { role: "root" });
  let i = 0;
  for (const [k, v] of entries) {
    await fs.writeFile(`${base}/${k}`, v, { role: "root" });
    h.onFile?.(++i, entries.length);
  }
  await fs.writeFile(`${base}/install.json`, JSON.stringify({ installedAt: Date.now(), sha256: p.sha256, source: h.source }), { role: "root" });
  await fs.mkdir(`${base}/data`, { role: "root" });
}
export async function registerPermissions(m: Manifest) { await grantMany(m.id, m.permissions.filter((p) => p !== "camera" && p !== "microphone" && p !== "clipboard")); }

export async function refreshInstalled(): Promise<InstalledApp[]> {
  const out: InstalledApp[] = [];
  let dirs: { path: string; type: string }[] = [];
  try { dirs = await fs.list("/Applications"); } catch { /* none */ }
  for (const d of dirs) {
    if (d.type !== "dir") continue;
    try {
      const m = validateManifest(JSON.parse(await fs.readText(`${d.path}/manifest.json`)));
      const info = await fs.json<{ installedAt: number; sha256: string; source: string }>(`${d.path}/install.json`, { installedAt: 0, sha256: "", source: "unknown" });
      let iconSvg = "";
      try { iconSvg = await fs.readText(`${d.path}/${m.icon}`); } catch { /* none */ }
      out.push({ manifest: m, iconSvg, ...info });
    } catch { /* corrupted entries are reported by Recovery's integrity check */ }
  }
  out.sort((a, b) => a.manifest.name.localeCompare(b.manifest.name));
  installedStore.set({ apps: out });
  setInstalledMeta(out.map<InstalledMeta>((a) => ({ id: a.manifest.id, name: a.manifest.name, category: a.manifest.category, type: a.manifest.type, w: a.manifest.window.width, h: a.manifest.window.height, description: a.manifest.description, permissions: a.manifest.permissions })));
  return out;
}
export const svgDataUrl = (svg: string) => svg ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}` : "";
export async function uninstallApp(id: string) {
  if (!/^[a-z0-9._-]+$/.test(id)) throw new Error("bad id");
  await fs.remove(`/Applications/${id}`, { role: "root" });
  const { getSetting, setSetting } = await import("../settings");
  setSetting("pinned", getSetting("pinned").filter((p) => p !== "pkg:" + id));
  resetPermissionCache();
  await logEvent("uninstall", id);
  await refreshInstalled();
}
export async function installFromBytes(bytes: Uint8Array, source: string, expectedSha?: string): Promise<Manifest> {
  const p = await parseWrapp(bytes, expectedSha);
  await installParsed(p, { source });
  await registerPermissions(p.manifest);
  await refreshInstalled();
  await logEvent("install", p.manifest.id, `${p.manifest.version} sha256 ${p.sha256.slice(0, 16)}… from ${source}`);
  return p.manifest;
}
export function buildWrapp(files: Record<string, string | Uint8Array>): Uint8Array {
  const o: Record<string, Uint8Array> = {};
  for (const [k, v] of Object.entries(files)) o[k] = typeof v === "string" ? strToU8(v) : v;
  return zipSync(o);
}
void NEUX_VERSION;
