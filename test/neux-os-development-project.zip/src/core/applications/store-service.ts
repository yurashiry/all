import { createStore } from "../store";
import { fetchBytes } from "../networking/fetch";
import { parseWrapp, installParsed, registerPermissions, refreshInstalled, installedStore, PackageError } from "./wrapp";
import { notify } from "../os";
import { fs } from "../kernel";
import { uid } from "../util";
import { logEvent } from "../security";

export interface CatalogEntry {
  id: string; name: string; version: string; category: string; description: string; publisher: string; type: "web" | "html";
  url?: string; packageUrl: string; sha256: string; size: number; channel: "stable" | "beta" | "developer"; verified: boolean;
  regions: string[]; permissions: string[]; changelog: string; compat: string[]; icon: string; screenshots: string[]; host?: string;
}
export interface Catalog { generated: string; entries: CatalogEntry[] }
export type JobState = "queued" | "downloading" | "verifying" | "installing" | "finishing" | "installed" | "failed" | "canceled";
export interface Job { id: string; appId: string; name: string; state: JobState; received: number; total: number | null; percent: number; step: string; error?: string; started: number; filesDone: number; filesTotal: number }
export interface HistoryItem { ts: number; appId: string; name: string; version: string; result: "installed" | "failed" | "canceled"; detail: string }
export const jobs = createStore<{ list: Job[]; history: HistoryItem[]; catalog: Catalog | null; catalogError: string | null }>({ list: [], history: [], catalog: null, catalogError: null });
const controllers = new Map<string, AbortController>();
const MAX_PARALLEL = 2;
const HPATH = "/Configuration/install-history.json";

export async function loadCatalog() {
  try {
    const r = await fetch("./store/catalog.json", { cache: "no-store" });
    if (!r.ok) throw new Error(`catalog.json: HTTP ${r.status}`);
    jobs.set({ catalog: (await r.json()) as Catalog, catalogError: null });
  } catch (e) { jobs.set({ catalogError: (e as Error).message }); }
  jobs.set({ history: await fs.json<HistoryItem[]>(HPATH, []) });
}
const patch = (id: string, p: Partial<Job>) => jobs.set((s) => ({ list: s.list.map((j) => (j.id === id ? { ...j, ...p } : j)) }));
async function addHistory(h: HistoryItem) { const hist = [h, ...jobs.get().history].slice(0, 200); jobs.set({ history: hist }); await fs.saveJson(HPATH, hist); }

export function enqueueInstall(e: CatalogEntry): string {
  const ex = jobs.get().list.find((j) => j.appId === e.id && !["installed", "failed", "canceled"].includes(j.state));
  if (ex) return ex.id;
  const id = uid();
  const j: Job = { id, appId: e.id, name: e.name, state: "queued", received: 0, total: e.size, percent: 0, step: "Waiting in queue", started: Date.now(), filesDone: 0, filesTotal: 0 };
  jobs.set((s) => ({ list: [j, ...s.list.filter((x) => x.appId !== e.id)] }));
  pump();
  return id;
}
function pump() {
  const s = jobs.get();
  const running = s.list.filter((j) => ["downloading", "verifying", "installing", "finishing"].includes(j.state)).length;
  let slots = MAX_PARALLEL - running;
  for (const j of [...s.list].reverse()) {
    if (slots <= 0) break;
    if (j.state === "queued") { slots--; const e = s.catalog?.entries.find((x) => x.id === j.appId); if (e) void runJob(j.id, e); else patch(j.id, { state: "failed", error: "Catalog entry vanished" }); }
  }
}
/* percent is derived from real quantities: download bytes (0–70), verification done (+10), files written (+15), registration (+5) */
async function runJob(id: string, e: CatalogEntry) {
  const ac = new AbortController();
  controllers.set(id, ac);
  try {
    patch(id, { state: "downloading", step: "Downloading package" });
    const r = await fetchBytes(new URL(e.packageUrl, document.baseURI).toString(), { signal: ac.signal, fallbackTotal: e.size,
      onProgress: (p) => patch(id, { received: p.received, total: p.total, percent: p.total ? Math.min(70, (p.received / p.total) * 70) : 0 }) });
    patch(id, { state: "verifying", step: "Verifying integrity and manifest", percent: 70, received: r.bytes.length, total: r.bytes.length });
    const parsed = await parseWrapp(r.bytes, e.sha256);
    if (parsed.manifest.id !== e.id) throw new PackageError("Package id does not match catalog entry");
    if (ac.signal.aborted) throw new DOMException("aborted", "AbortError");
    patch(id, { state: "installing", step: "Installing files", percent: 80 });
    await installParsed(parsed, { source: "Neux Store (" + e.channel + ")", onFile: (d, t) => patch(id, { filesDone: d, filesTotal: t, percent: 80 + (d / t) * 15 }) });
    patch(id, { state: "finishing", step: "Registering application", percent: 95 });
    await registerPermissions(parsed.manifest);
    await refreshInstalled();
    await logEvent("install", e.id, `${e.version} sha256 ${e.sha256.slice(0, 16)}… (Store)`);
    patch(id, { state: "installed", step: "Installed", percent: 100 });
    await addHistory({ ts: Date.now(), appId: e.id, name: e.name, version: e.version, result: "installed", detail: `${r.bytes.length} bytes` });
    notify({ title: `${e.name} installed`, message: "Find it in the Start Menu.", appId: "store" });
  } catch (err) {
    const aborted = (err as Error).name === "AbortError";
    patch(id, { state: aborted ? "canceled" : "failed", step: aborted ? "Canceled" : "Failed", error: aborted ? undefined : (err as Error).message });
    await addHistory({ ts: Date.now(), appId: e.id, name: e.name, version: e.version, result: aborted ? "canceled" : "failed", detail: aborted ? "canceled by user" : (err as Error).message });
    // partially written files are cleaned so a failed install leaves nothing registered
    if (!aborted) try { if (!installedStore.get().apps.some((a) => a.manifest.id === e.id && a.manifest.version === e.version)) await fs.remove(`/Applications/${e.id}`, { role: "root" }); } catch { /* none */ }
    await refreshInstalled();
  } finally { controllers.delete(id); pump(); }
}
export function cancelJob(id: string) {
  const ac = controllers.get(id);
  if (ac) ac.abort(); else patch(id, { state: "canceled", step: "Canceled" });
}
export function retryJob(id: string) {
  const j = jobs.get().list.find((x) => x.id === id);
  const e = jobs.get().catalog?.entries.find((x) => x.id === j?.appId);
  if (e) enqueueInstall(e);
}
export const jobFor = (appId: string) => jobs.get().list.find((j) => j.appId === appId);
export function updatesAvailable(): CatalogEntry[] {
  const c = jobs.get().catalog;
  if (!c) return [];
  const cmp = (a: string, b: string) => { const x = a.split(/[.-]/).map(Number), y = b.split(/[.-]/).map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
  return c.entries.filter((e) => installedStore.get().apps.some((a) => a.manifest.id === e.id && cmp(e.version, a.manifest.version) > 0));
}
