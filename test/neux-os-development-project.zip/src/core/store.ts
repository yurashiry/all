import { useSyncExternalStore } from "react";

export interface Store<T> { get(): T; set(p: Partial<T> | ((s: T) => Partial<T>)): void; subscribe(fn: () => void): () => void }
export function createStore<T extends object>(initial: T): Store<T> {
  let state = initial;
  const subs = new Set<() => void>();
  return {
    get: () => state,
    set(p) {
      const patch = typeof p === "function" ? p(state) : p;
      state = { ...state, ...patch };
      subs.forEach((s) => s());
    },
    subscribe(fn) { subs.add(fn); return () => { subs.delete(fn); }; },
  };
}
export function useStore<T extends object, R>(store: Store<T>, sel: (s: T) => R): R {
  return useSyncExternalStore(store.subscribe, () => sel(store.get()), () => sel(store.get()));
}
