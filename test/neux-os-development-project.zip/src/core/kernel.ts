import { IDBBackend, MemoryBackend, NeuxFS } from "./filesystem/neuxfs";

/** The single NeuxFS instance of this Neux session. Web adapter: IndexedDB. */
export const fs = new NeuxFS(typeof indexedDB !== "undefined" ? new IDBBackend("neuxfs") : new MemoryBackend());
export const NEUX_VERSION = "0.1.0-alpha";
export const NEUX_BUILD = "web";
