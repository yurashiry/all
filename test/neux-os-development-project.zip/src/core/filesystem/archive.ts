import { zipSync, unzipSync, strToU8, type Zippable } from "fflate";
import type { NeuxFS } from "./neuxfs";
import { basename, dirname, join, norm } from "./neuxfs";

/** Create a zip archive from NeuxFS paths (files and folders). */
export async function archivePaths(fs: NeuxFS, paths: string[], destZip: string): Promise<number> {
  const z: Zippable = {};
  let count = 0;
  for (const p of paths) {
    const base = dirname(p);
    const n = await fs.stat(p);
    const items = n.type === "dir" ? (await fs.all()).filter((x) => x.path === n.path || x.path.startsWith(n.path + "/")) : [n];
    for (const it of items) {
      if (it.type !== "file") continue;
      z[it.path.slice(base.length === 1 ? 1 : base.length + 1)] = new Uint8Array(await it.data!.arrayBuffer());
      count++;
    }
  }
  if (!count) throw new Error("Nothing to archive");
  await fs.writeFile(destZip, zipSync(z), { mime: "application/zip" });
  return count;
}

export async function unarchive(fs: NeuxFS, zipPath: string, destDir?: string): Promise<number> {
  const bytes = await fs.readBytes(zipPath);
  const files = unzipSync(bytes);
  const stem = basename(zipPath).replace(/\.[^.]+$/, "");
  const dest = destDir ?? (await fs.uniquePath(join(dirname(zipPath), stem)));
  let n = 0;
  for (const [name, data] of Object.entries(files)) {
    if (name.endsWith("/")) continue;
    const target = norm(dest + "/" + name);
    if (!target.startsWith(norm(dest) + "/")) throw new Error(`Unsafe path in archive: ${name}`); // zip-slip guard
    await fs.writeFile(target, data);
    n++;
  }
  return n;
}

/** Whole-filesystem backup as zip (all Neux-owned files). Directory structure is rebuilt on restore. */
export async function backupAll(fs: NeuxFS): Promise<Uint8Array> {
  const z: Zippable = {};
  const index: { path: string; type: string; mime: string; meta?: unknown }[] = [];
  for (const n of await fs.all()) {
    if (n.path === "/" || n.path.startsWith("/Temporary")) continue;
    index.push({ path: n.path, type: n.type, mime: n.mime, meta: n.meta });
    if (n.type === "file") z["files" + n.path] = new Uint8Array(await n.data!.arrayBuffer());
  }
  z["neux-backup.json"] = strToU8(JSON.stringify({ format: "neux-backup/1", created: Date.now(), index }));
  return zipSync(z);
}

export async function restoreBackup(fs: NeuxFS, bytes: Uint8Array): Promise<number> {
  const files = unzipSync(bytes);
  const idx = files["neux-backup.json"];
  if (!idx) throw new Error("Not a Neux backup (neux-backup.json missing)");
  const j = JSON.parse(new TextDecoder().decode(idx));
  if (j.format !== "neux-backup/1") throw new Error("Unsupported backup format " + j.format);
  let n = 0;
  for (const e of j.index as { path: string; type: string; mime: string; meta?: Record<string, unknown> }[]) {
    if (e.type === "dir") { await fs.mkdir(e.path, { role: "root" }, true); continue; }
    const d = files["files" + e.path];
    if (d) { await fs.writeFile(e.path, d, { role: "root", mime: e.mime, meta: e.meta }); n++; }
  }
  return n;
}
