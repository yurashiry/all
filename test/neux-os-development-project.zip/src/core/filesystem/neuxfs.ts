import { extOf, mimeFor, uid } from "../util";

export type NodeType = "file" | "dir";
export interface FsNode {
  path: string; name: string; parent: string; type: NodeType; mime: string; size: number;
  created: number; modified: number; data?: Blob; meta?: Record<string, unknown>;
}
export type Role = "user" | "admin" | "root";
export interface FsOpts { role?: Role }

/** Storage backend. Web uses IndexedDB; tests use memory; native adapters may provide SQLite. */
export interface KVBackend {
  get(path: string): Promise<FsNode | undefined>;
  put(node: FsNode): Promise<void>;
  del(path: string): Promise<void>;
  all(): Promise<FsNode[]>;
  clear(): Promise<void>;
}

export class MemoryBackend implements KVBackend {
  m = new Map<string, FsNode>();
  async get(p: string) { return this.m.get(p); }
  async put(n: FsNode) { this.m.set(n.path, n); }
  async del(p: string) { this.m.delete(p); }
  async all() { return [...this.m.values()]; }
  async clear() { this.m.clear(); }
}

export class IDBBackend implements KVBackend {
  private dbp: Promise<IDBDatabase> | null = null;
  constructor(private name = "neuxfs") {}
  private db() {
    if (!this.dbp) {
      this.dbp = new Promise((res, rej) => {
        const r = indexedDB.open(this.name, 1);
        r.onupgradeneeded = () => r.result.createObjectStore("nodes", { keyPath: "path" });
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
      });
    }
    return this.dbp;
  }
  private async tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.db();
    return new Promise((res, rej) => {
      const t = db.transaction("nodes", mode);
      const r = fn(t.objectStore("nodes"));
      t.oncomplete = () => res(r.result);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  }
  get(p: string) { return this.tx<FsNode | undefined>("readonly", (s) => s.get(p)); }
  async put(n: FsNode) { await this.tx("readwrite", (s) => s.put(n)); }
  async del(p: string) { await this.tx("readwrite", (s) => s.delete(p)); }
  all() { return this.tx<FsNode[]>("readonly", (s) => s.getAll()); }
  async clear() { await this.tx("readwrite", (s) => s.clear()); }
  /** Delete the whole database (used by full reset). */
  async destroy() {
    if (this.dbp) { (await this.dbp).close(); this.dbp = null; }
    await new Promise<void>((res) => {
      const r = indexedDB.deleteDatabase(this.name);
      r.onsuccess = r.onerror = r.onblocked = () => res();
    });
  }
}

export const DEFAULT_TREE = [
  "/System/Core", "/System/Shell", "/System/Services", "/System/Drivers", "/System/Recovery", "/System/Quarantine",
  "/Users/Default/Desktop", "/Users/Default/Documents", "/Users/Default/Downloads", "/Users/Default/Pictures",
  "/Users/Default/Pictures/Neux Photo Projects", "/Users/Default/Pictures/Exports",
  "/Users/Default/Music", "/Users/Default/Videos", "/Users/Default/Projects", "/Users/Guest",
  "/Applications", "/Store", "/Themes", "/Temporary", "/Trash", "/Configuration",
];
export const PROTECTED_ROOTS = ["/System", "/Configuration"];

export const norm = (p: string): string => {
  const out: string[] = [];
  for (const s of p.split("/")) {
    if (!s || s === ".") continue;
    if (s === "..") out.pop(); else out.push(s);
  }
  return "/" + out.join("/");
};
export const join = (a: string, b: string) => norm(b.startsWith("/") ? b : a + "/" + b);
export const dirname = (p: string) => { const n = norm(p); return n.slice(0, n.lastIndexOf("/")) || "/"; };
export const basename = (p: string) => { const n = norm(p); return n.slice(n.lastIndexOf("/") + 1); };

export class FsError extends Error {
  constructor(public code: "ENOENT" | "EEXIST" | "EACCES" | "ENOTDIR" | "EISDIR" | "EINVAL", msg: string) { super(msg); }
}

type Data = Blob | string | ArrayBuffer | Uint8Array;
const toBlob = (d: Data, mime: string): Blob =>
  d instanceof Blob ? d : typeof d === "string" ? new Blob([d], { type: mime }) : new Blob([d as BlobPart], { type: mime });

export class NeuxFS {
  private listeners = new Set<() => void>();
  constructor(public backend: KVBackend) {}
  subscribe(fn: () => void) { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }
  private emit() { this.listeners.forEach((l) => l()); }

  async init() {
    if (!(await this.backend.get("/"))) await this.backend.put(this.mk("/", "dir"));
    for (const d of DEFAULT_TREE) await this.mkdir(d, { role: "root" }, true);
  }
  private mk(path: string, type: NodeType, data?: Blob, mime?: string): FsNode {
    const now = Date.now();
    return { path, name: path === "/" ? "NeuxFS" : basename(path), parent: dirname(path), type,
      mime: type === "dir" ? "inode/directory" : mime ?? mimeFor(path), size: data?.size ?? 0, created: now, modified: now, data };
  }
  private guard(path: string, role: Role = "user") {
    const p = norm(path);
    if (role !== "root" && PROTECTED_ROOTS.some((r) => p === r || p.startsWith(r + "/")))
      throw new FsError("EACCES", `Permission denied: ${p} is protected (root required)`);
    if (role !== "root" && p === "/") throw new FsError("EACCES", "Cannot modify filesystem root");
  }

  async stat(path: string): Promise<FsNode> {
    const n = await this.backend.get(norm(path));
    if (!n) throw new FsError("ENOENT", `No such file or directory: ${norm(path)}`);
    return n;
  }
  async exists(path: string) { return !!(await this.backend.get(norm(path))); }
  async list(path: string): Promise<FsNode[]> {
    const p = norm(path);
    const n = await this.stat(p);
    if (n.type !== "dir") throw new FsError("ENOTDIR", `Not a directory: ${p}`);
    return (await this.backend.all()).filter((x) => x.parent === p && x.path !== "/");
  }
  async mkdir(path: string, o: FsOpts = {}, silent = false) {
    const p = norm(path);
    this.guard(p, o.role);
    const parts = p.split("/").filter(Boolean);
    let cur = "";
    for (const s of parts) {
      cur += "/" + s;
      const ex = await this.backend.get(cur);
      if (ex) { if (ex.type !== "dir") throw new FsError("ENOTDIR", `${cur} is a file`); continue; }
      await this.backend.put(this.mk(cur, "dir"));
    }
    if (!silent) this.emit();
  }
  async writeFile(path: string, data: Data, o: FsOpts & { mime?: string; meta?: Record<string, unknown> } = {}) {
    const p = norm(path);
    this.guard(p, o.role);
    if (p === "/") throw new FsError("EINVAL", "Invalid path");
    const ex = await this.backend.get(p);
    if (ex?.type === "dir") throw new FsError("EISDIR", `${p} is a directory`);
    await this.mkdir(dirname(p), { role: o.role }, true);
    const blob = toBlob(data, o.mime ?? mimeFor(p));
    const node = this.mk(p, "file", blob, o.mime);
    if (ex) node.created = ex.created;
    node.meta = o.meta ?? ex?.meta;
    await this.backend.put(node);
    this.emit();
    return node;
  }
  async readBlob(path: string): Promise<Blob> {
    const n = await this.stat(path);
    if (n.type === "dir") throw new FsError("EISDIR", `${n.path} is a directory`);
    return n.data ?? new Blob([]);
  }
  async readText(path: string) { return (await this.readBlob(path)).text(); }
  async readBytes(path: string) { return new Uint8Array(await (await this.readBlob(path)).arrayBuffer()); }
  async setMeta(path: string, meta: Record<string, unknown>) {
    const n = await this.stat(path);
    await this.backend.put({ ...n, meta: { ...n.meta, ...meta } });
    this.emit();
  }
  private async subtree(path: string): Promise<FsNode[]> {
    const p = norm(path);
    return (await this.backend.all()).filter((n) => n.path === p || n.path.startsWith(p === "/" ? "/" : p + "/"));
  }
  async uniquePath(path: string): Promise<string> {
    let p = norm(path);
    if (!(await this.exists(p))) return p;
    const d = dirname(p), b = basename(p), e = extOf(b);
    const stem = e ? b.slice(0, -(e.length + 1)) : b;
    for (let i = 2; ; i++) {
      const c = join(d, e ? `${stem} (${i}).${e}` : `${stem} (${i})`);
      if (!(await this.exists(c))) return c;
    }
  }
  async copy(src: string, dest: string, o: FsOpts = {}) {
    const s = norm(src), d = norm(dest);
    this.guard(d, o.role);
    if (d === s || d.startsWith(s + "/")) throw new FsError("EINVAL", "Cannot copy a folder into itself");
    if (await this.exists(d)) throw new FsError("EEXIST", `Already exists: ${d}`);
    await this.mkdir(dirname(d), { role: o.role }, true);
    for (const n of await this.subtree(s)) {
      const np = d + n.path.slice(s.length);
      await this.backend.put({ ...n, path: np, name: basename(np), parent: dirname(np), created: Date.now(), modified: Date.now() });
    }
    this.emit();
    return d;
  }
  async move(src: string, dest: string, o: FsOpts = {}) {
    const s = norm(src), d = norm(dest);
    this.guard(s, o.role); this.guard(d, o.role);
    if (d === s) return d;
    if (d.startsWith(s + "/")) throw new FsError("EINVAL", "Cannot move a folder into itself");
    if (await this.exists(d)) throw new FsError("EEXIST", `Already exists: ${d}`);
    await this.stat(s);
    await this.mkdir(dirname(d), { role: o.role }, true);
    for (const n of await this.subtree(s)) {
      const np = d + n.path.slice(s.length);
      await this.backend.put({ ...n, path: np, name: basename(np), parent: dirname(np), modified: Date.now() });
      await this.backend.del(n.path);
    }
    this.emit();
    return d;
  }
  rename(path: string, newName: string, o: FsOpts = {}) {
    if (!newName || /[\/\\]/.test(newName)) throw new FsError("EINVAL", "Invalid name");
    return this.move(path, join(dirname(path), newName), o);
  }
  /** Move to Trash (recoverable). */
  async trash(path: string, o: FsOpts = {}) {
    const p = norm(path);
    this.guard(p, o.role);
    if (p === "/Trash" || p.startsWith("/Trash/")) { await this.remove(p, o); return p; }
    const target = await this.uniquePath(join("/Trash", basename(p)));
    await this.move(p, target, { role: "root" });
    await this.setMeta(target, { originalPath: p, trashedAt: Date.now() });
    return target;
  }
  async restore(trashPath: string) {
    const n = await this.stat(trashPath);
    const orig = n.meta?.originalPath as string | undefined;
    if (!orig) throw new FsError("EINVAL", "No original location recorded");
    const dest = await this.uniquePath(orig);
    await this.move(trashPath, dest, { role: "root" });
    const m = await this.stat(dest);
    const meta = { ...m.meta }; delete meta.originalPath; delete meta.trashedAt;
    await this.backend.put({ ...m, meta });
    return dest;
  }
  async remove(path: string, o: FsOpts = {}) {
    const p = norm(path);
    this.guard(p, o.role);
    await this.stat(p);
    for (const n of await this.subtree(p)) await this.backend.del(n.path);
    this.emit();
  }
  async emptyTrash() { for (const n of await this.list("/Trash")) await this.remove(n.path, { role: "root" }); }
  async search(query: string, root = "/", limit = 200): Promise<FsNode[]> {
    const q = query.toLowerCase();
    const r = norm(root);
    return (await this.backend.all())
      .filter((n) => n.path !== "/" && (r === "/" || n.path.startsWith(r + "/")) && n.name.toLowerCase().includes(q))
      .slice(0, limit);
  }
  async all() { return this.backend.all(); }
  async usage() { return (await this.backend.all()).reduce((a, n) => a + n.size, 0); }
  /** Erase ALL Neux-owned data in this backend, then recreate the empty tree. Never touches host files. */
  async wipe(destroy = false) {
    await this.backend.clear();
    if (destroy && this.backend instanceof IDBBackend) await this.backend.destroy();
    this.emit();
  }
  async json<T>(path: string, fallback: T): Promise<T> {
    try { return JSON.parse(await this.readText(path)) as T; } catch { return fallback; }
  }
  async saveJson(path: string, v: unknown) { return this.writeFile(path, JSON.stringify(v, null, 1), { role: "root", mime: "application/json" }); }
  newId() { return uid(); }
}
