import { fs } from "../kernel";
export const ALL_PERMISSIONS = ["notifications", "storage", "clipboard", "network", "files.read", "files.write", "media", "camera", "microphone"] as const;
export type Permission = (typeof ALL_PERMISSIONS)[number];
const PATH = "/Configuration/permissions.json";
type Grants = Record<string, Permission[]>;
let cache: Grants | null = null;
async function load() { return (cache ??= await fs.json<Grants>(PATH, {})); }
export async function grants(appId: string) { return (await load())[appId] ?? []; }
export async function has(appId: string, p: Permission) { return (await grants(appId)).includes(p); }
export async function setGrant(appId: string, p: Permission, on: boolean) {
  const g = await load();
  const cur = new Set(g[appId] ?? []);
  on ? cur.add(p) : cur.delete(p);
  g[appId] = [...cur];
  await fs.saveJson(PATH, g);
}
export async function grantMany(appId: string, ps: Permission[]) { for (const p of ps) await setGrant(appId, p, true); }
export function resetPermissionCache() { cache = null; }
