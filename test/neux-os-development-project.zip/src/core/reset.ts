import { fs } from "./kernel";
import { os, closeWin } from "./os";
import { IDBBackend } from "./filesystem/neuxfs";

/** Keys/dbs/caches that BELONG to Neux. The reset touches only these exact names — never other data of the same origin. */
export const NEUX_IDB = ["neuxfs", "neux-keys"];
export const LS_PREFIX = "neux:";
const PENDING = "neux:reset-pending";

/** Complete Neux wipe. Interrupt-safe: a pending flag is written first and boot resumes an interrupted wipe. */
export async function resetAllNeuxData(progress: (s: string) => void = () => {}) {
  localStorage.setItem(PENDING, "1");
  await wipeOwnedStorage(progress);
  localStorage.removeItem(PENDING);
}
export async function wipeOwnedStorage(progress: (s: string) => void = () => {}) {
  progress("Stopping running Neux applications…");
  for (const w of [...os.get().windows]) closeWin(w.id, true);
  progress("Erasing NeuxFS (files, apps, accounts, profiles, settings, playlists, browser data)…");
  if (fs.backend instanceof IDBBackend) { try { await fs.backend.clear(); } catch { /* db may not exist */ } await fs.backend.destroy(); } else await fs.wipe();
  progress("Erasing key storage…");
  await new Promise<void>((res) => { const r = indexedDB.deleteDatabase("neux-keys"); r.onsuccess = r.onerror = r.onblocked = () => res(); });
  progress("Clearing Neux local settings…");
  for (const k of Object.keys(localStorage)) if (k.startsWith(LS_PREFIX) && k !== PENDING) localStorage.removeItem(k);
  for (const k of Object.keys(sessionStorage)) if (k.startsWith(LS_PREFIX)) sessionStorage.removeItem(k);
  progress("Clearing Neux caches…");
  if ("caches" in window) for (const k of await caches.keys()) if (k.startsWith("neux-")) await caches.delete(k);
}
export const resetPending = () => typeof localStorage !== "undefined" && localStorage.getItem(PENDING) === "1";
export async function resumeInterruptedReset() { if (resetPending()) { await resetAllNeuxData(); return true; } return false; }
