import { fs } from "../kernel";
import type { Role } from "../filesystem/neuxfs";

export interface User { name: string; role: Role; salt?: string; hash?: string; iterations?: number; created: number }
const PATH = "/Configuration/users.json";
const b64 = (u: Uint8Array) => btoa(String.fromCharCode(...u));
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export async function hashPassword(pw: string, salt: Uint8Array, iterations = 210_000): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pw), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations }, key, 256);
  return b64(new Uint8Array(bits));
}
export const listUsers = () => fs.json<User[]>(PATH, []);
export async function createUser(name: string, role: Role, password?: string): Promise<User> {
  name = name.trim();
  if (!/^[\p{L}\p{N}_ .-]{1,32}$/u.test(name)) throw new Error("Invalid user name (1–32 letters, digits, space, _ . -)");
  const users = await listUsers();
  if (users.some((u) => u.name.toLowerCase() === name.toLowerCase())) throw new Error("User already exists");
  if (password !== undefined && password !== "" && password.length < 4) throw new Error("Password must be at least 4 characters");
  const u: User = { name, role, created: Date.now() };
  if (password) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    u.salt = b64(salt); u.iterations = 210_000; u.hash = await hashPassword(password, salt, u.iterations);
  }
  await fs.saveJson(PATH, [...users, u]);
  if (users.length > 0) await fs.mkdir(`/Users/${name}/Documents`, { role: "root" }); // first account uses the standard /Users/Default profile
  return u;
}
export async function verifyUser(name: string, password: string): Promise<User | null> {
  const u = (await listUsers()).find((x) => x.name === name);
  if (!u) return null;
  if (!u.hash) return u;
  const h = await hashPassword(password, unb64(u.salt!), u.iterations);
  return h === u.hash ? u : null;
}
export async function setPassword(name: string, password: string) {
  const users = await listUsers();
  const u = users.find((x) => x.name === name);
  if (!u) throw new Error("No such user");
  if (password.length < 4) throw new Error("Password must be at least 4 characters");
  const salt = crypto.getRandomValues(new Uint8Array(16));
  u.salt = b64(salt); u.iterations = 210_000; u.hash = await hashPassword(password, salt, u.iterations);
  await fs.saveJson(PATH, users);
}
export async function deleteUser(name: string) {
  const users = await listUsers();
  const u = users.find((x) => x.name === name);
  if (!u) throw new Error("No such user");
  if (u.role === "root" || users.filter((x) => x.role !== "user").length <= 1 && u.role !== "user") throw new Error("Cannot delete the last administrator");
  await fs.saveJson(PATH, users.filter((x) => x.name !== name));
}
