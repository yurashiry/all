import { fs } from "./kernel";
import { notify, openApp } from "./os";
import { getSetting } from "./settings";
import { openFile } from "./file-associations";
import { join } from "./filesystem/neuxfs";

export interface ConsoleBus { type?: (s: string) => void; exec?: (s: string) => void }
export const consoleBus: ConsoleBus = {};
const pending: { cmd?: string; run?: string } = {};
export const takePendingConsole = () => { const p = { ...pending }; pending.cmd = pending.run = undefined; return p; };

/** open console(neuxos):command=help | open console(neuxos):runcommand=system info */
export function handleNeuxUri(input: string): boolean {
  const m = input.trim().match(/^open\s+console\(neuxos\):(command|runcommand)=(.*)$/i);
  if (!m) return false;
  const val = m[2].trim();
  if (m[1].toLowerCase() === "command") { if (val && val !== "null") pending.cmd = val; } else pending.run = val;
  openApp("console", { uriRev: Date.now() });
  setTimeout(() => { if (pending.cmd && consoleBus.type) { consoleBus.type(pending.cmd); pending.cmd = undefined; } if (pending.run && consoleBus.exec) { consoleBus.exec(pending.run); pending.run = undefined; } }, 50);
  return true;
}
export function installNeuxApi() {
  const api = {
    console: { open: () => openApp("console"), type: (s: string) => { if (consoleBus.type) consoleBus.type(s); else { pending.cmd = s; openApp("console"); } }, execute: (s: string) => { if (consoleBus.exec) consoleBus.exec(s); else { pending.run = s; openApp("console"); } } },
    notifications: { show: (o: { title: string; message: string }) => notify(o) },
    files: { open: (p: string) => openFile(p.startsWith("/") ? p : join("/Users/Default", p)), read: (p: string) => fs.readText(p), list: (p: string) => fs.list(p) },
    settings: { get: (k: string) => (getSetting as (k: string) => unknown)(k) },
    apps: { open: (id: string) => openApp(id) },
  };
  (window as unknown as { Neux: typeof api }).Neux = Object.freeze(api);
}
