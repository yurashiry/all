import { getSetting, setSetting } from "../settings";
import { detectPlatform } from "../../adapters/web/platform";
import { logEvent } from "../security";

export interface VmSupport { supported: boolean; hypervisor: string; reasons: string[] }
/** Virtualization is its own subsystem (not VPN). The toggle only grants permission; real VM support needs a native adapter. */
export function vmSupport(): VmSupport {
  const p = detectPlatform();
  if (!p.native) return { supported: false, hypervisor: "none", reasons: ["Web edition has no access to hardware virtualization (VT-x/AMD-V/ARM virtualization).", "WebAssembly-based emulators are possible in principle but none is bundled, and GitHub Pages cannot provide cross-origin isolation headers."] };
  return { supported: false, hypervisor: "native shell", reasons: [`The ${p.edition} shell has no hypervisor adapter implemented yet (see NEUX_VIRTUALIZATION_SPECIFICATION.md).`] };
}
export const vmAllowed = () => getSetting("allowVM");
export function canRegisterVm(): { ok: boolean; reason?: string } {
  if (!vmAllowed()) return { ok: false, reason: "Blocked: Settings → VPN → Allow adding VM is OFF." };
  return { ok: true };
}
export function registerVm(appId: string): { ok: boolean; reason?: string } {
  const c = canRegisterVm();
  if (!c.ok) return c;
  const reg = getSetting("vmRegistry");
  if (!reg.includes(appId)) setSetting("vmRegistry", [...reg, appId]);
  void logEvent("vm-register", appId);
  return { ok: true };
}
export function startVm(appId: string): { ok: boolean; reason: string } {
  if (!vmAllowed()) return { ok: false, reason: "Blocked: Allow adding VM is OFF. Existing VM data is preserved." };
  const s = vmSupport();
  if (!s.supported) return { ok: false, reason: "No virtualization adapter available: " + s.reasons[0] };
  return { ok: true, reason: "started" };
}
export function setAllowVm(on: boolean) { setSetting("allowVM", on); void logEvent(on ? "vm-allow" : "vm-deny", "Allow adding VM"); }
