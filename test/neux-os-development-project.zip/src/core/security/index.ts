import { fs } from "../kernel";
import { settingsStore, setSetting } from "../settings";
import { extOf, kindOf, sha256Hex } from "../util";
import { basename, join } from "../filesystem/neuxfs";
import { unzipSync } from "fflate";

export interface SecEvent { ts: number; action: string; target: string; detail: string }
interface SecState { trusted: string[]; history: SecEvent[] }
const PATH = "/Configuration/security.json";
const QDIR = "/System/Quarantine";
const HOST_EXEC = ["exe", "msi", "bat", "cmd", "com", "scr", "ps1", "apk", "dmg", "pkg", "sh", "app", "jar", "vbs", "lnk"];
const SCRIPTLIKE = ["wr", "wrapp", "html", "htm", "js", "nxl", "nxb", "nxe", "svg"];

const load = () => fs.json<SecState>(PATH, { trusted: [], history: [] });
export async function logEvent(action: string, target: string, detail = "") {
  const s = await load();
  s.history = [{ ts: Date.now(), action, target, detail }, ...s.history].slice(0, 500);
  await fs.saveJson(PATH, s);
}
export const getHistory = async () => (await load()).history;
export const isolationOn = () => settingsStore.get().isolation;
export const setIsolation = async (on: boolean) => { setSetting("isolation", on); await logEvent(on ? "isolation-on" : "isolation-off", "File Isolation Protection"); };

export interface Inspection { path: string; size: number; sha256: string; ext: string; kind: string; magic: string; warnings: string[]; manifest?: unknown; entries?: string[]; note: string }
export async function inspect(path: string): Promise<Inspection> {
  const n = await fs.stat(path);
  const bytes = await fs.readBytes(path);
  const ext = extOf(n.name);
  const head = Array.from(bytes.slice(0, 4)).map((b) => b.toString(16).padStart(2, "0")).join("");
  let magic = "unknown";
  if (head.startsWith("4d5a")) magic = "PE executable (MZ)";
  else if (head === "7f454c46") magic = "ELF executable";
  else if (head.startsWith("504b")) magic = "ZIP container";
  else if (head.startsWith("25504446")) magic = "PDF";
  else if (head.startsWith("89504e47")) magic = "PNG";
  else if (head.startsWith("ffd8ff")) magic = "JPEG";
  else if (["cafebabe", "cffaedfe", "feedface", "feedfacf"].includes(head)) magic = "Mach-O / Java class";
  const warnings: string[] = [];
  if (HOST_EXEC.includes(ext)) warnings.push("Host executable type. Neux never executes host programs.");
  if (/executable|Mach-O/.test(magic) && !HOST_EXEC.includes(ext)) warnings.push(`Content looks like ${magic} but the extension is .${ext || "none"} (disguised executable).`);
  if (magic === "PNG" && ext !== "png" || magic === "JPEG" && !["jpg", "jpeg"].includes(ext) || magic === "PDF" && ext !== "pdf") warnings.push(`Extension .${ext} does not match content (${magic}).`);
  let manifest: unknown, entries: string[] | undefined;
  if (magic === "ZIP container") {
    try {
      const z = unzipSync(bytes);
      entries = Object.keys(z);
      if (z["manifest.json"]) manifest = JSON.parse(new TextDecoder().decode(z["manifest.json"]));
      if (entries.some((e) => e.includes("..") || e.startsWith("/"))) warnings.push("Archive contains path-traversal entries.");
      if (entries.some((e) => HOST_EXEC.includes(extOf(e)))) warnings.push("Archive contains host executables.");
    } catch { warnings.push("ZIP structure could not be parsed."); }
  }
  return { path: n.path, size: n.size, sha256: await sha256Hex(bytes), ext, kind: kindOf(n.name), magic, warnings, manifest, entries,
    note: "Heuristic inspection only (type, magic bytes, archive contents, hash). Passing it does NOT prove a file is safe. Secure Center is not an antivirus." };
}

export interface OpenDecision { allowed: boolean; reason?: string; canQuarantine?: boolean }
/** Enforced at the service boundary — every open/run goes through this. */
export async function checkOpen(path: string, intent: "view" | "run" = "view"): Promise<OpenDecision> {
  const name = basename(path);
  const ext = extOf(name);
  if (HOST_EXEC.includes(ext)) return { allowed: false, reason: `.${ext} is a host executable. Neux never executes host programs automatically. You can inspect or quarantine it.`, canQuarantine: true };
  if (path.startsWith(QDIR + "/")) return { allowed: false, reason: "This file is in quarantine. Restore it from Secure Center first.", canQuarantine: false };
  if (intent === "run" && isolationOn() && SCRIPTLIKE.includes(ext) && !["svg"].includes(ext)) {
    const h = await sha256Hex(await fs.readBytes(path));
    if (!(await load()).trusted.includes(h)) return { allowed: false, reason: "File Isolation Protection is ON: executable content is blocked unless you add it to trusted exceptions in Secure Center.", canQuarantine: true };
  }
  return { allowed: true };
}
export async function quarantine(path: string) {
  const n = await fs.stat(path);
  const h = n.type === "file" ? await sha256Hex(await fs.readBytes(path)) : "";
  const dest = await fs.uniquePath(join(QDIR, n.name + ".quarantined"));
  await fs.move(path, dest, { role: "root" });
  await fs.setMeta(dest, { originalPath: n.path, sha256: h, quarantinedAt: Date.now() });
  await logEvent("quarantine", n.path, `sha256 ${h.slice(0, 16)}…`);
  return dest;
}
export async function listQuarantine() { return fs.list(QDIR); }
export async function restoreQuarantine(path: string) {
  const n = await fs.stat(path);
  const orig = (n.meta?.originalPath as string) ?? join("/Users/Default/Downloads", n.name.replace(/\.quarantined$/, ""));
  const dest = await fs.uniquePath(orig);
  await fs.move(path, dest, { role: "root" });
  await logEvent("restore", dest, "restored from quarantine");
  return dest;
}
export async function trust(path: string) {
  const h = await sha256Hex(await fs.readBytes(path));
  const s = await load(); if (!s.trusted.includes(h)) s.trusted.push(h);
  await fs.saveJson(PATH, s); await logEvent("trust", path, `sha256 ${h.slice(0, 16)}…`);
}
export const trustedHashes = async () => (await load()).trusted;
export async function untrust(h: string) { const s = await load(); s.trusted = s.trusted.filter((x) => x !== h); await fs.saveJson(PATH, s); await logEvent("untrust", h.slice(0, 16)); }

/** Honest list of which protections exist in this (web) build. */
export function protectionMatrix(): { name: string; available: boolean; note: string }[] {
  return [
    { name: "Host executable blocking", available: true, note: "Executables (.exe, .apk, .dmg, scripts…) are never launched by Neux." },
    { name: "Run-block for untrusted scripts/packages (Isolation ON)", available: true, note: "Enforced in security.checkOpen() before the runtime starts anything." },
    { name: "Sandboxed package runtime", available: true, note: "Packages run in a cross-origin sandboxed iframe (no same-origin, no top navigation) behind a permission-checked bridge." },
    { name: "Clipboard/camera/microphone for apps (Isolation ON)", available: true, note: "Denied via iframe Permissions-Policy while isolation is on." },
    { name: "Separate per-app storage", available: true, note: "Package apps can only touch /Applications/<id>/data via the bridge." },
    { name: "Package integrity (SHA-256)", available: true, note: "Store packages are verified against catalog hashes. Manual packages show their hash." },
    { name: "Package signatures (public-key)", available: false, note: "No signing PKI exists yet. Hash-pinned catalog only." },
    { name: "OS process isolation / seccomp / AppContainer", available: false, note: "Not available to a web app. Planned for native shells (see PLATFORM_SPECIFICATION.md)." },
    { name: "Per-app network restrictions", available: false, note: "Browsers do not allow per-iframe firewalling. Sandbox restricts capabilities only." },
    { name: "Malware detection (antivirus)", available: false, note: "Not implemented. Heuristic inspection only." },
  ];
}
