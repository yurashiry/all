export const uid = (): string =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2) + Date.now().toString(36);

export function formatBytes(n: number): string {
  if (!isFinite(n) || n < 0) return "—";
  if (n < 1024) return `${n} B`;
  const u = ["KB", "MB", "GB", "TB"];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return `${n.toFixed(n >= 100 ? 0 : 1)} ${u[i]}`;
}

export function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i <= 0 ? "" : name.slice(i + 1).toLowerCase();
}

const MIME: Record<string, string> = {
  mp3: "audio/mpeg", flac: "audio/flac", wav: "audio/wav", aac: "audio/aac", m4a: "audio/mp4", alac: "audio/mp4",
  ogg: "audio/ogg", opus: "audio/ogg", aiff: "audio/aiff", aif: "audio/aiff",
  mp4: "video/mp4", mkv: "video/x-matroska", mov: "video/quicktime", webm: "video/webm",
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", avif: "image/avif", gif: "image/gif",
  bmp: "image/bmp", tif: "image/tiff", tiff: "image/tiff", svg: "image/svg+xml",
  pdf: "application/pdf", txt: "text/plain", md: "text/markdown", html: "text/html", htm: "text/html",
  css: "text/css", js: "text/javascript", json: "application/json", lrc: "text/plain", csv: "text/csv",
  zip: "application/zip", wr: "text/plain", wrapp: "application/zip", nxe: "application/zip",
  wrphoto: "application/json", nxl: "text/plain", nxb: "application/octet-stream",
};
export const mimeFor = (name: string) => MIME[extOf(name)] ?? "application/octet-stream";

export type FileKind = "audio" | "video" | "image" | "document" | "archive" | "app" | "code" | "other";
const KINDS: Record<string, FileKind> = {};
const add = (k: FileKind, ...e: string[]) => e.forEach((x) => (KINDS[x] = k));
add("audio", "mp3", "flac", "wav", "aac", "m4a", "alac", "ogg", "opus", "aiff", "aif");
add("video", "mp4", "mkv", "mov", "webm");
add("image", "png", "jpg", "jpeg", "webp", "avif", "gif", "bmp", "tif", "tiff", "svg", "wrphoto");
add("document", "pdf", "txt", "md", "lrc", "csv");
add("archive", "zip", "nxe");
add("app", "wr", "wrapp", "exe", "apk", "dmg", "msi", "bat", "sh", "app");
add("code", "html", "htm", "css", "js", "json", "nxl");
export const kindOf = (name: string): FileKind => KINDS[extOf(name)] ?? "other";

export async function sha256Hex(data: ArrayBuffer | Uint8Array): Promise<string> {
  const buf = data instanceof Uint8Array ? (data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer) : data;
  const h = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
