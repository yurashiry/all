import { fs } from "../kernel";
import { NEUX_VERSION } from "../kernel";
import { getSetting, setSetting, settingsStore, DEFAULTS, type Settings } from "../settings";
import { os, openApp, closeWin, confirmBox, notify } from "../os";
import { BUILTIN } from "../applications/registry";
import { installedStore, uninstallApp, installFromBytes } from "../applications/wrapp";
import { listUsers, createUser, setPassword, deleteUser } from "../users";
import { basename, join, norm, type Role } from "../filesystem/neuxfs";
import { net } from "../networking/status";
import { runNxl, compileNxl, serializeBytecode, NxlError } from "../../nxl";
import { formatBytes } from "../util";
import { detectPlatform } from "../../adapters/web/platform";
import { backupAll } from "../filesystem/archive";
import { vmSupport, startVm, registerVm } from "../virtualization";
import { logEvent } from "../security";
import { runIntegrityCheck } from "../recovery";

export interface ConsoleCtx { cwd: string; role: Role; env: Record<string, string>; user: string }
export type Out = (s: string) => void;
export interface Command { name: string; usage: string; help: string; min?: Role; priv?: boolean; run(args: string[], flags: Record<string, string | true>, ctx: ConsoleCtx, out: Out): Promise<void> | void }
const RANK: Record<Role, number> = { user: 0, admin: 1, root: 2 };

export function tokenize(line: string): string[] {
  const out: string[] = []; let cur = "", q: string | null = null, has = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) { if (c === q) q = null; else if (c === "\\" && q === '"' && i + 1 < line.length) cur += line[++i]; else cur += c; }
    else if (c === '"' || c === "'") { q = c; has = true; }
    else if (/\s/.test(c)) { if (cur || has) out.push(cur); cur = ""; has = false; }
    else { cur += c; has = true; }
  }
  if (q) throw new Error("Unterminated quote");
  if (cur || has) out.push(cur);
  return out;
}
const history: string[] = [];
export const consoleHistory = () => history;
const registry = new Map<string, Command>();
export const registerCommand = (c: Command) => registry.set(c.name, c);
export const commands = () => [...registry.values()];
const p = (ctx: ConsoleCtx, a: string) => (a.startsWith("/") ? norm(a) : join(ctx.cwd, a));
const fsOpts = (ctx: ConsoleCtx) => ({ role: ctx.role });

async function audit(ctx: ConsoleCtx, line: string, result: string) {
  try {
    const old = await fs.exists("/System/Services/audit.log") ? await fs.readText("/System/Services/audit.log") : "";
    const lines = (old + JSON.stringify({ ts: new Date().toISOString(), user: ctx.user, role: ctx.role, cmd: line, result }) + "\n").split("\n").slice(-1000).join("\n");
    await fs.writeFile("/System/Services/audit.log", lines, { role: "root", mime: "text/plain" });
  } catch { /* audit must not break the console */ }
}

export async function execute(line: string, ctx: ConsoleCtx, out: Out): Promise<boolean> {
  line = line.trim();
  if (!line) return true;
  history.push(line); if (history.length > 500) history.shift();
  let toks: string[];
  try { toks = tokenize(line); } catch (e) { out(`error: ${(e as Error).message}`); return false; }
  // support "system info" style subcommands: longest registered name wins
  let name = "", n = 0;
  for (let k = Math.min(3, toks.length); k >= 1; k--) { const cand = toks.slice(0, k).join(" "); if (registry.has(cand)) { name = cand; n = k; break; } }
  if (!name) { out(`error: unknown command '${toks[0]}'. Type 'help'.`); await audit(ctx, line, "unknown"); return false; }
  const cmd = registry.get(name)!;
  if (RANK[ctx.role] < RANK[cmd.min ?? "user"]) { out(`error: '${name}' requires ${cmd.min} privileges (you are ${ctx.role}).`); await audit(ctx, line, "denied"); return false; }
  const args: string[] = [], flags: Record<string, string | true> = {};
  for (let i = n; i < toks.length; i++) {
    const t = toks[i];
    if (t.startsWith("--")) { const [k, ...v] = t.slice(2).split("="); flags[k] = v.length ? v.join("=") : true; } else args.push(t);
  }
  if (cmd.priv && !flags.yes && !(await confirmBox("Privileged command", `Run '${line}'? This changes Neux system data.`, true, "Run"))) { out("Cancelled."); await audit(ctx, line, "cancelled"); return false; }
  try { await cmd.run(args, flags, ctx, out); await audit(ctx, line, "ok"); return true; }
  catch (e) { out(`error: ${(e as Error).message}`); await audit(ctx, line, "error: " + (e as Error).message); return false; }
}

const C = (name: string, usage: string, help: string, run: Command["run"], extra: Partial<Command> = {}) => registerCommand({ name, usage, help, run, ...extra });
export function installCommands() {
  if (registry.size) return;
  C("help", "help [command]", "List commands or show usage", (a, _f, _c, out) => {
    if (a[0]) { const c = [...registry.values()].find((x) => x.name === a.join(" ")); if (!c) throw new Error("No such command"); out(`${c.usage}\n  ${c.help}${c.min ? `\n  requires: ${c.min}` : ""}`); return; }
    for (const c of [...registry.values()].sort((x, y) => x.name.localeCompare(y.name))) out(`  ${c.name.padEnd(18)} ${c.help}`);
  });
  C("version", "version", "Show Neux version", (_a, _f, _c, out) => out(`Neux OS ${NEUX_VERSION} — HAORÏK Laboratory`));
  C("echo", "echo <text>", "Print text", (a, _f, _c, out) => out(a.join(" ")));
  C("whoami", "whoami", "Current user", (_a, _f, c, out) => out(`${c.user} (${c.role})`));
  C("history", "history", "Command history", (_a, _f, _c, out) => history.forEach((h, i) => out(`${String(i + 1).padStart(4)}  ${h}`)));
  C("system info", "system info", "Platform, storage and runtime information", async (_a, _f, _c, out) => {
    const pi = detectPlatform(); const used = await fs.usage();
    const est = await navigator.storage?.estimate?.();
    out(`Neux OS ${NEUX_VERSION} (${pi.edition} edition)\nHost OS:     ${pi.host}\nUser agent:  ${pi.ua}\nCPU threads: ${navigator.hardwareConcurrency}\nMemory hint: ${(navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? "n/a"} GB\nNeuxFS used: ${formatBytes(used)}${est?.quota ? ` of ~${formatBytes(est.quota)} browser quota` : ""}\nLanguage:    ${getSetting("language")}   Region: ${getSetting("region") || "not set"}`);
  });
  C("system status", "system status", "Running windows, network, protection", (_a, _f, _c, out) => {
    const s = os.get(); out(`Windows: ${s.windows.length}   Desktops: ${s.desktops}\nOnline: ${net.get().online}   BEECO: ${net.get().beeco.state}   VPN: ${net.get().vpn.state}\nFile isolation: ${getSetting("isolation") ? "ON" : "off"}   Allow adding VM: ${getSetting("allowVM") ? "ON" : "off"}`);
  });
  C("system repair", "system repair", "Run integrity check and recreate missing system folders", async (_a, _f, _c, out) => { const r = await runIntegrityCheck(true); r.forEach((x) => out(`${x.ok ? "ok  " : "FIXED/FAIL"} ${x.name}: ${x.detail}`)); }, { min: "admin", priv: true });
  C("fs pwd", "fs pwd", "Print working directory", (_a, _f, c, out) => out(c.cwd));
  C("fs ls", "fs ls [path]", "List a directory", async (a, f, c, out) => {
    const list = (await fs.list(a[0] ? p(c, a[0]) : c.cwd)).sort((x, y) => (x.type === y.type ? x.name.localeCompare(y.name) : x.type === "dir" ? -1 : 1));
    if (!list.length) out("(empty)");
    for (const n of list) out(f.l ? `${n.type === "dir" ? "d" : "-"} ${formatBytes(n.size).padStart(9)} ${new Date(n.modified).toISOString().slice(0, 16)} ${n.name}` : n.name + (n.type === "dir" ? "/" : ""));
  });
  C("fs cd", "fs cd <path>", "Change directory", async (a, _f, c) => { const t = p(c, a[0] ?? "/Users/Default"); if ((await fs.stat(t)).type !== "dir") throw new Error("Not a directory"); c.cwd = t; });
  C("fs mkdir", "fs mkdir <path>", "Create a directory", async (a, _f, c) => { if (!a[0]) throw new Error("usage: fs mkdir <path>"); await fs.mkdir(p(c, a[0]), fsOpts(c)); });
  C("fs touch", "fs touch <path>", "Create an empty file", async (a, _f, c) => { if (!a[0]) throw new Error("usage: fs touch <path>"); const t = p(c, a[0]); if (!(await fs.exists(t))) await fs.writeFile(t, "", fsOpts(c)); });
  C("fs cat", "fs cat <path>", "Print a text file", async (a, _f, c, out) => { const b = await fs.readBlob(p(c, a[0] ?? "")); if (b.size > 1_000_000) throw new Error("File too large for cat"); out(await b.text()); });
  C("fs write", "fs write <path> <text>", "Write text to a file", async (a, _f, c) => { if (a.length < 2) throw new Error("usage: fs write <path> <text>"); await fs.writeFile(p(c, a[0]), a.slice(1).join(" "), fsOpts(c)); });
  C("fs delete", "fs delete <path> [--permanent]", "Move to Trash (or delete permanently)", async (a, f, c, out) => {
    const t = p(c, a[0] ?? ""); if (f.permanent) await fs.remove(t, fsOpts(c)); else await fs.trash(t, fsOpts(c));
    if (t.startsWith("/System")) await logEvent("protected-delete", t, `by ${c.user}`);
    out(f.permanent ? "Deleted permanently." : "Moved to Trash.");
  });
  C("fs copy", "fs copy <src> <dest>", "Copy", async (a, _f, c) => { await fs.copy(p(c, a[0] ?? ""), p(c, a[1] ?? ""), fsOpts(c)); });
  C("fs move", "fs move <src> <dest>", "Move", async (a, _f, c) => { await fs.move(p(c, a[0] ?? ""), p(c, a[1] ?? ""), fsOpts(c)); });
  C("fs rename", "fs rename <path> <name>", "Rename", async (a, _f, c) => { await fs.rename(p(c, a[0] ?? ""), a[1] ?? "", fsOpts(c)); });
  C("fs find", "fs find <text>", "Search by name", async (a, _f, c, out) => { const r = await fs.search(a.join(" "), "/"); r.forEach((n) => out(n.path)); if (!r.length) out("No matches."); void c; });
  C("fs stat", "fs stat <path>", "Show metadata", async (a, _f, c, out) => { const n = await fs.stat(p(c, a[0] ?? "")); out(`${n.path}\n  type ${n.type}  mime ${n.mime}  size ${formatBytes(n.size)}\n  created ${new Date(n.created).toISOString()}\n  modified ${new Date(n.modified).toISOString()}`); });
  C("user list", "user list", "List local users", async (_a, _f, _c, out) => (await listUsers()).forEach((u) => out(`${u.name.padEnd(20)} ${u.role}${u.hash ? "" : "  (no password)"}`)));
  C("user create", "user create <name> [--role=user|admin] [--password=...]", "Create a local user", async (a, f) => { await createUser(a[0] ?? "", (f.role as Role) === "admin" ? "admin" : "user", typeof f.password === "string" ? f.password : undefined); }, { min: "admin", priv: true });
  C("user password", "user password <name> <new-password>", "Change a password", async (a, _f, c) => { if (c.role === "user" && a[0] !== c.user) throw new Error("You can only change your own password"); await setPassword(a[0] ?? "", a[1] ?? ""); }, { priv: true });
  C("user delete", "user delete <name>", "Delete a user", async (a) => { await deleteUser(a[0] ?? ""); }, { min: "admin", priv: true });
  C("app list", "app list", "Built-in and installed apps", (_a, _f, _c, out) => { BUILTIN.filter((b) => !b.system || ["settings", "secure", "recovery", "taskmanager"].includes(b.id)).forEach((b) => out(`${b.id.padEnd(14)} ${b.name}  [built-in]`)); installedStore.get().apps.forEach((a) => out(`${("pkg:" + a.manifest.id).padEnd(14)} ${a.manifest.name} ${a.manifest.version}  [installed]`)); });
  C("app open", "app open <id>", "Open an app", (a) => { const id = a[0] ?? ""; if (id.startsWith("pkg:")) openApp("pkg", { pkgId: id.slice(4) }); else if (!openApp(id)) throw new Error("Unknown app"); });
  C("app install", "app install <path.wrapp>", "Install a .wrapp from NeuxFS", async (a, _f, c, out) => { const m = await installFromBytes(await fs.readBytes(p(c, a[0] ?? "")), "console"); out(`Installed ${m.name} ${m.version}`); }, { min: "admin", priv: true });
  C("app uninstall", "app uninstall <package-id>", "Uninstall an installed app", async (a, _f, _c, out) => { await uninstallApp(a[0] ?? ""); out("Uninstalled."); }, { min: "admin", priv: true });
  C("net status", "net status", "Connectivity", (_a, _f, _c, out) => { const n = net.get(); out(`online: ${n.online}\nconnection: ${n.connection}\nvpn: ${n.vpn.state} — ${n.vpn.detail}`); });
  C("net beeco status", "net beeco status", "BEECO state", (_a, _f, _c, out) => { const b = net.get().beeco; out(`BEECO/1: ${b.state}${b.mode ? ` (${b.mode})` : ""}\n${b.detail}${b.server ? `\nserver: ${b.server}` : ""}${b.latency ? `\nlatency: ${b.latency.toFixed(1)} ms` : ""}`); });
  C("process list", "process list", "Open windows", (_a, _f, _c, out) => os.get().windows.forEach((w) => out(`${w.id.slice(0, 8)}  ${w.appId.padEnd(12)} ${w.state.padEnd(10)} desktop ${w.desktop + 1}  ${w.title}`)));
  C("process kill", "process kill <id-prefix>", "Close a window", (a) => { const w = os.get().windows.find((x) => x.id.startsWith(a[0] ?? "\0")); if (!w) throw new Error("No such process"); closeWin(w.id, true); });
  C("settings list", "settings list", "All settings", (_a, _f, _c, out) => Object.entries(settingsStore.get()).forEach(([k, v]) => out(`${k} = ${JSON.stringify(v)}`)));
  C("settings get", "settings get <key>", "Read a setting", (a, _f, _c, out) => { if (!(a[0] in DEFAULTS)) throw new Error("Unknown setting"); out(JSON.stringify(getSetting(a[0] as keyof Settings))); });
  C("settings set", "settings set <key> <value>", "Change a setting (JSON or plain string)", (a) => {
    const k = a[0] as keyof Settings; if (!(k in DEFAULTS)) throw new Error("Unknown setting");
    let v: unknown = a.slice(1).join(" "); try { v = JSON.parse(String(v)); } catch { /* string */ }
    if (typeof v !== typeof DEFAULTS[k]) throw new Error(`Expected ${typeof DEFAULTS[k]} for ${k}`);
    if (k === "allowVM" || k === "isolation") throw new Error(`Change ${k} from Settings / Secure Center (security-sensitive)`);
    setSetting(k, v as never);
  }, { min: "user" });
  C("wr run", "wr run <file.wr|.nxl|.nxb>", "Compile and run an NXL program", async (a, _f, c, out) => {
    const path = p(c, a[0] ?? ""); const src = await fs.readText(path);
    try { const r = await runNxl(src, { print: out, fs: { read: (x) => fs.readText(p(c, x)), write: async (x, d) => void (await fs.writeFile(p(c, x), d, fsOpts(c))), list: async (x) => (await fs.list(p(c, x))).map((n) => n.name) }, fetchText: async (u) => (await fetch(u)).text() }); out(`[exit ok — ${r.steps} VM steps]`); }
    catch (e) { if (e instanceof NxlError) throw e; throw e; }
  });
  C("wr build", "wr build <file.wr>", "Compile to .nxb bytecode", async (a, _f, c, out) => { const path = p(c, a[0] ?? ""); const bc = compileNxl(await fs.readText(path)); const dest = path.replace(/\.[^.]+$/, "") + ".nxb"; await fs.writeFile(dest, serializeBytecode(bc), fsOpts(c)); out(`Wrote ${dest} (${bc.funcs.length} functions, ${bc.consts.length} constants)`); });
  C("wr serve", "wr serve [--port=8080]", "Local server", (_a, f, _c, out) => { out(`Cannot bind http://localhost:${f.port ?? 8080} — the Web edition cannot open listening sockets.\nUse Neux Developer's sandboxed Preview (real, but not a network server), or a native Neux edition.`); throw new Error("not supported on this platform"); });
  C("vm list", "vm list", "VM registry and support", (_a, _f, _c, out) => { const s = vmSupport(); out(`Allow adding VM: ${getSetting("allowVM") ? "ON" : "off"}\nHypervisor: ${s.hypervisor} (supported: ${s.supported})`); s.reasons.forEach((r) => out(" - " + r)); getSetting("vmRegistry").forEach((v) => out("registered: " + v)); });
  C("vm register", "vm register <app-id>", "Register a VM application", (a, _f, _c, out) => { const r = registerVm(a[0] ?? ""); if (!r.ok) throw new Error(r.reason); out("Registered."); }, { min: "admin" });
  C("vm start", "vm start <app-id>", "Start a VM", (a) => { const r = startVm(a[0] ?? ""); if (!r.ok) throw new Error(r.reason); });
  C("recovery status", "recovery status", "Integrity status", async (_a, _f, _c, out) => (await runIntegrityCheck(false)).forEach((x) => out(`${x.ok ? "ok  " : "FAIL"} ${x.name}: ${x.detail}`)));
  C("recovery backup", "recovery backup [name]", "Create a backup zip in Documents", async (a, _f, c, out) => { const dest = await fs.uniquePath(join("/Users/Default/Documents", (a[0] ?? "neux-backup") + ".zip")); await fs.writeFile(dest, await backupAll(fs), fsOpts(c)); out("Backup written to " + dest); }, { min: "admin" });
  C("open", "open <app-id>", "Open an application window", (a) => { if (!openApp(a[0] ?? "")) throw new Error("Unknown app"); });
  C("notify", "notify <text>", "Show a notification", (a) => notify({ title: "Console", message: a.join(" ") }));
  C("audit", "audit [lines]", "Show the audit log (root)", async (a, _f, _c, out) => { const t = (await fs.readText("/System/Services/audit.log")).trim().split("\n"); t.slice(-(Number(a[0]) || 20)).forEach(out); }, { min: "root" });
  void basename;
}
