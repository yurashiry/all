import { createStore } from "./store";
import { getSetting } from "./settings";
import type { User } from "./users";
import { uid } from "./util";
import { getAppMeta } from "./applications/registry";

export type WinState = "normal" | "minimized" | "maximized" | "fullscreen";
export interface Win {
  id: string; appId: string; title: string; x: number; y: number; w: number; h: number; state: WinState;
  desktop: number; z: number; params: Record<string, unknown>; prev?: { x: number; y: number; w: number; h: number };
  snap?: "left" | "right"; startedAt: number; rev: number; restoreTo?: WinState;
}
export interface Notif { id: string; title: string; message: string; ts: number; appId?: string; read: boolean }
export interface Dialog { id: string; kind: "alert" | "confirm" | "prompt"; title: string; message: string; value?: string; danger?: boolean; ok?: string; resolve: (v: unknown) => void }
export interface OsState {
  windows: Win[]; desktops: number; current: number; activeId: string | null; z: number;
  startOpen: boolean; quickOpen: boolean; notifOpen: boolean; searchOpen: boolean; switcherOpen: boolean;
  locked: boolean; user: User | null; booted: boolean; notifications: Notif[]; toasts: Notif[]; dialogs: Dialog[]; menu: ContextMenuState | null;
}
export interface MenuItem { label: string; action?: () => void; danger?: boolean; disabled?: boolean; separator?: boolean; submenu?: MenuItem[] }
export interface ContextMenuState { x: number; y: number; items: MenuItem[] }

export const os = createStore<OsState>({
  windows: [], desktops: 1, current: 0, activeId: null, z: 10, startOpen: false, quickOpen: false, notifOpen: false,
  searchOpen: false, switcherOpen: false, locked: false, user: null, booted: false, notifications: [], toasts: [], dialogs: [], menu: null,
});

const closeGuards = new Map<string, () => boolean>();
export const setCloseGuard = (id: string, fn: (() => boolean) | null) => { fn ? closeGuards.set(id, fn) : closeGuards.delete(id); };

function patchWin(id: string, p: Partial<Win>) {
  os.set((s) => ({ windows: s.windows.map((w) => (w.id === id ? { ...w, ...p } : w)) }));
}
export function openApp(appId: string, params: Record<string, unknown> = {}): string | null {
  const meta = getAppMeta(appId, params);
  if (!meta) { notify({ title: "Cannot open", message: `Unknown application: ${appId}` }); return null; }
  const s = os.get();
  closeMenus();
  if (meta.singleton) {
    const ex = s.windows.find((w) => w.appId === appId && (meta.instanceKey ? meta.instanceKey(w.params) === meta.instanceKey(params) : true));
    if (ex) { patchWin(ex.id, { params: { ...ex.params, ...params }, rev: ex.rev + 1, desktop: s.current }); restoreWin(ex.id); focusWin(ex.id); return ex.id; }
  }
  const n = s.windows.filter((w) => w.desktop === s.current).length;
  const vw = typeof window !== "undefined" ? window.innerWidth : 1200, vh = typeof window !== "undefined" ? window.innerHeight : 800;
  const w = Math.min(meta.w, vw - 20), h = Math.min(meta.h, vh - 90);
  const id = uid();
  const win: Win = { id, appId, title: meta.title ?? meta.name, w, h, x: Math.max(8, Math.min(vw - w - 8, 60 + (n % 8) * 32)), y: Math.max(8, 40 + (n % 8) * 28),
    state: "normal", desktop: s.current, z: s.z + 1, params, startedAt: Date.now(), rev: 0 };
  os.set({ windows: [...s.windows, win], z: s.z + 1, activeId: id });
  return id;
}
export function setTitle(id: string, title: string) { patchWin(id, { title }); }
export function focusWin(id: string) {
  const s = os.get();
  const w = s.windows.find((x) => x.id === id);
  if (!w) return;
  const z = s.z + 1;
  os.set({ z, activeId: id, windows: s.windows.map((x) => (x.id === id ? { ...x, z, state: x.state === "minimized" ? x.restoreTo ?? "normal" : x.state } : x)) });
}
export function restoreWin(id: string) {
  const w = os.get().windows.find((x) => x.id === id);
  if (!w) return;
  if (w.state === "minimized") patchWin(id, { state: w.restoreTo ?? "normal" });
  else if (w.state === "maximized" || w.state === "fullscreen") toggleMaximize(id, true);
}
export function minimizeWin(id: string) {
  const cw = os.get().windows.find((x) => x.id === id);
  patchWin(id, { state: "minimized", restoreTo: cw && cw.state !== "minimized" ? cw.state : cw?.restoreTo });
  const s = os.get();
  if (s.activeId === id) {
    const next = s.windows.filter((w) => w.id !== id && w.state !== "minimized" && w.desktop === s.current).sort((a, b) => b.z - a.z)[0];
    os.set({ activeId: next?.id ?? null });
  }
}
export function toggleMaximize(id: string, forceRestore = false) {
  const w = os.get().windows.find((x) => x.id === id);
  if (!w) return;
  if (w.state === "maximized" || w.state === "fullscreen" || forceRestore) {
    const p = w.prev ?? { x: 80, y: 60, w: 800, h: 520 };
    patchWin(id, { state: "normal", ...p, prev: undefined, snap: undefined });
  } else patchWin(id, { state: "maximized", prev: { x: w.x, y: w.y, w: w.w, h: w.h } });
  focusWin(id);
}
export function toggleWinFullscreen(id: string) {
  const w = os.get().windows.find((x) => x.id === id);
  if (!w) return;
  if (w.state === "fullscreen") patchWin(id, { state: w.prev ? "normal" : "maximized", ...(w.prev ?? {}), prev: undefined });
  else patchWin(id, { state: "fullscreen", prev: w.state === "normal" ? { x: w.x, y: w.y, w: w.w, h: w.h } : w.prev });
}
export function snapWin(id: string, dir: "left" | "right") {
  const w = os.get().windows.find((x) => x.id === id);
  if (!w) return;
  const vw = window.innerWidth, vh = window.innerHeight - 70;
  patchWin(id, { state: "normal", prev: w.state === "normal" && !w.snap ? { x: w.x, y: w.y, w: w.w, h: w.h } : w.prev, x: dir === "left" ? 0 : vw / 2, y: 0, w: vw / 2, h: vh, snap: dir });
  focusWin(id);
}
export function setBounds(id: string, b: Partial<Pick<Win, "x" | "y" | "w" | "h">>) { patchWin(id, { ...b, snap: undefined }); }
/** Request close (apps may veto through a close guard, e.g. unsaved changes). */
export function closeWin(id: string, force = false): boolean {
  const g = closeGuards.get(id);
  if (!force && g && !g()) return false;
  closeGuards.delete(id);
  const s = os.get();
  const w = s.windows.find((x) => x.id === id);
  const rest = s.windows.filter((x) => x.id !== id);
  const next = rest.filter((x) => x.state !== "minimized" && x.desktop === s.current).sort((a, b) => b.z - a.z)[0];
  os.set({ windows: rest, activeId: s.activeId === id ? next?.id ?? null : s.activeId });
  if (w?.appId === "picker" && w.params.reqId) resolvePicker(String(w.params.reqId), null);
  return true;
}
export function addDesktop() { const s = os.get(); os.set({ desktops: s.desktops + 1, current: s.desktops }); notify({ title: "Virtual desktop", message: `Desktop ${s.desktops + 1} created` }, true); }
export function switchDesktop(i: number) { const s = os.get(); if (i < 0 || i >= s.desktops) return; os.set({ current: i, activeId: s.windows.filter((w) => w.desktop === i && w.state !== "minimized").sort((a, b) => b.z - a.z)[0]?.id ?? null }); }
export function removeDesktop(i: number) {
  const s = os.get();
  if (s.desktops <= 1) return;
  os.set({ desktops: s.desktops - 1, current: Math.max(0, Math.min(s.current, s.desktops - 2)),
    windows: s.windows.map((w) => ({ ...w, desktop: w.desktop === i ? Math.max(0, i - 1) : w.desktop > i ? w.desktop - 1 : w.desktop })) });
}
export function cycleWindows(dir = 1) {
  const s = os.get();
  const list = s.windows.filter((w) => w.desktop === s.current).sort((a, b) => a.startedAt - b.startedAt);
  if (list.length < 2) return;
  const i = list.findIndex((w) => w.id === s.activeId);
  focusWin(list[(i + dir + list.length) % list.length].id);
}
export function closeMenus() { os.set({ startOpen: false, quickOpen: false, notifOpen: false, searchOpen: false, menu: null }); }
export function toggleStart() { const o = os.get().startOpen; closeMenus(); os.set({ startOpen: !o }); }
export function showMenu(e: { clientX: number; clientY: number; preventDefault(): void; stopPropagation(): void }, items: MenuItem[]) {
  e.preventDefault(); e.stopPropagation();
  os.set({ menu: { x: e.clientX, y: e.clientY, items }, startOpen: false, quickOpen: false, notifOpen: false });
}

export function notify(n: { title: string; message: string; appId?: string }, toastOnly = false) {
  const item: Notif = { id: uid(), ts: Date.now(), read: false, ...n };
  os.set((s) => ({ notifications: toastOnly ? s.notifications : [item, ...s.notifications].slice(0, 100), toasts: [...s.toasts, item] }));
  setTimeout(() => os.set((s) => ({ toasts: s.toasts.filter((t) => t.id !== item.id) })), 5000);
}

function dialog<T>(d: Omit<Dialog, "id" | "resolve">): Promise<T> {
  return new Promise((resolve) => { os.set((s) => ({ dialogs: [...s.dialogs, { ...d, id: uid(), resolve: resolve as (v: unknown) => void }] })); });
}
export const alertBox = (title: string, message: string) => dialog<void>({ kind: "alert", title, message });
export const confirmBox = (title: string, message: string, danger = false, ok = "OK") => dialog<boolean>({ kind: "confirm", title, message, danger, ok });
export const promptBox = (title: string, message: string, value = "") => dialog<string | null>({ kind: "prompt", title, message, value });
export function closeDialog(id: string, v: unknown) {
  const d = os.get().dialogs.find((x) => x.id === id);
  os.set((s) => ({ dialogs: s.dialogs.filter((x) => x.id !== id) }));
  d?.resolve(v);
}

/* ---------- Universal file picker ---------- */
export type PickerFilter = "all" | "audio" | "video" | "media" | "image" | "document" | "archive" | "app" | "wr" | "user" | "code";
export interface PickerOptions { mode?: "open" | "save" | "folder"; filter?: PickerFilter; multiple?: boolean; title?: string; startPath?: string; defaultName?: string; extensions?: string[] }
const pickers = new Map<string, (v: string[] | null) => void>();
export const pickerOptions = new Map<string, PickerOptions>();
export function pickFile(opts: PickerOptions = {}): Promise<string[] | null> {
  return new Promise((resolve) => {
    const reqId = uid();
    pickers.set(reqId, resolve); pickerOptions.set(reqId, opts);
    openApp("picker", { reqId, title: opts.title ?? (opts.mode === "save" ? "Save as" : "Open") });
  });
}
export function resolvePicker(reqId: string, v: string[] | null) {
  const r = pickers.get(reqId);
  if (!r) return;
  pickers.delete(reqId); pickerOptions.delete(reqId);
  r(v);
}
