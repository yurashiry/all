import { unzipSync } from "fflate";
import { fs } from "./kernel";
import { getSetting, setSetting } from "./settings";
import { logEvent } from "./security";

export interface ExtManifest { id: string; name: string; version: string; type: "theme"; description?: string; vars: Record<string, string>; publisher?: string }
const SAFE_VALUE = /^[#\w\s.,%()/-]{1,80}$/; // no url(), no ; no quotes — values cannot load remote resources
const ALLOWED = /^--(bg|surface|surface-solid|surface-2|surface-3|border|text|text-dim|accent|danger|ok|warn|radius|radius-sm|blur)$/;

export function validateExtension(files: Record<string, Uint8Array>): ExtManifest {
  const mf = files["manifest.json"];
  if (!mf) throw new Error("manifest.json missing");
  const m = JSON.parse(new TextDecoder().decode(mf)) as Partial<ExtManifest>;
  if (!m.id || !/^[a-z0-9._-]{2,64}$/.test(m.id)) throw new Error("manifest.id invalid");
  if (!m.name || !m.version) throw new Error("manifest.name/version required");
  if (m.type !== "theme") throw new Error(`Extension type '${String(m.type)}' is not supported yet (only 'theme')`);
  if (!files["extension.nxl"]) throw new Error("extension.nxl missing (required by the .nxe format)");
  for (const k of Object.keys(files)) if (k.includes("..") || k.startsWith("/")) throw new Error("Unsafe path " + k);
  const vars = m.vars ?? {};
  for (const [k, v] of Object.entries(vars)) { if (!ALLOWED.test(k)) throw new Error(`Variable ${k} is not allowed`); if (!SAFE_VALUE.test(v)) throw new Error(`Value for ${k} is not allowed`); }
  return { id: m.id, name: m.name, version: m.version, type: "theme", description: m.description, vars, publisher: m.publisher };
}
export async function installExtension(path: string) {
  const files = unzipSync(await fs.readBytes(path));
  const m = validateExtension(files);
  for (const [k, v] of Object.entries(files)) if (!k.endsWith("/")) await fs.writeFile(`/Themes/${m.id}/${k}`, v, { role: "root" });
  await logEvent("extension-install", m.id);
  return m;
}
export async function listExtensions(): Promise<ExtManifest[]> {
  const out: ExtManifest[] = [];
  try { for (const d of await fs.list("/Themes")) if (d.type === "dir") { try { out.push(JSON.parse(await fs.readText(d.path + "/manifest.json"))); } catch { /* skip */ } } } catch { /* none */ }
  return out;
}
export async function removeExtension(id: string) { await fs.remove(`/Themes/${id}`, { role: "root" }); const e = { ...getSetting("extensionsEnabled") }; delete e[id]; setSetting("extensionsEnabled", e); await applyExtensions(); }
export async function applyExtensions() {
  const enabled = getSetting("extensionsEnabled");
  let css = "";
  for (const m of await listExtensions()) if (enabled[m.id]) css += Object.entries(m.vars).filter(([k, v]) => ALLOWED.test(k) && SAFE_VALUE.test(v)).map(([k, v]) => `${k}:${v} !important;`).join("");
  let el = document.getElementById("neux-ext-style") as HTMLStyleElement | null;
  if (!el) { el = document.createElement("style"); el.id = "neux-ext-style"; document.head.appendChild(el); }
  el.textContent = css ? `:root, [data-theme]{${css}}` : "";
}
