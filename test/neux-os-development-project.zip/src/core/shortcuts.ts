import { getSetting } from "./settings";

export type Scope = "system" | "app" | "editor" | "input";
export interface ShortcutDef { id: string; label: string; category: string; keys: string; alt?: string; scope: Scope; app?: string; reserved?: string; note?: string }
const D = (id: string, label: string, category: string, keys: string, scope: Scope, extra: Partial<ShortcutDef> = {}): ShortcutDef => ({ id, label, category, keys, scope, ...extra });
const BR = "Reserved by most web browsers; works in native Neux builds and installed PWA windows only.";
const OS_RES = "Reserved by the host OS; cannot be intercepted by a regular app. Use the alternative binding.";

export const SHORTCUTS: ShortcutDef[] = [
  D("sys.fullscreen", "Toggle fullscreen", "Global", "Ctrl+F", "system"),
  D("sys.start", "Open Start Menu", "Global", "Ctrl+Space", "system", { note: "On macOS, Ctrl+Space may be taken by input-source switching." }),
  D("sys.explorer", "Open Explorer", "Global", "Ctrl+E", "system"),
  D("sys.settings", "Open Settings", "Global", "Ctrl+,", "system"),
  D("sys.console", "Open Console", "Global", "Ctrl+Alt+T", "system"),
  D("sys.taskmgr", "Open Task Manager", "Global", "Ctrl+Shift+Escape", "system"),
  D("sys.newDesktop", "Create virtual desktop", "Global", "Ctrl+Shift+N", "system", { note: "Overridden by Developer's 'New project' while Developer is focused." }),
  D("sys.prevDesktop", "Previous virtual desktop", "Global", "Ctrl+Alt+ArrowLeft", "system", { note: "May be intercepted by some Linux/Windows graphics drivers." }),
  D("sys.nextDesktop", "Next virtual desktop", "Global", "Ctrl+Alt+ArrowRight", "system"),
  D("sys.lock", "Lock Neux", "Global", "Ctrl+Shift+Q", "system", { note: "Ctrl+Shift+Q quits some browsers (Firefox/Chrome on Linux)." }),
  D("sys.search", "Search", "Global", "Ctrl+K", "system"),
  D("win.switch", "Switch applications", "Windows", "Alt+Tab", "system", { reserved: OS_RES, alt: "Alt+Q" }),
  D("win.close", "Close active window", "Windows", "Alt+F4", "system", { reserved: OS_RES, alt: "Alt+Shift+W" }),
  D("win.closeTab", "Close tab / document", "Windows", "Ctrl+W", "app", { reserved: BR }),
  D("win.new", "New window", "Windows", "Ctrl+N", "app", { reserved: BR }),
  D("win.snapLeft", "Snap window left", "Windows", "Meta+ArrowLeft", "system", { reserved: OS_RES, alt: "Alt+Shift+ArrowLeft" }),
  D("win.snapRight", "Snap window right", "Windows", "Meta+ArrowRight", "system", { reserved: OS_RES, alt: "Alt+Shift+ArrowRight" }),
  D("win.maximize", "Maximize window", "Windows", "Meta+ArrowUp", "system", { reserved: OS_RES, alt: "Alt+Shift+ArrowUp" }),
  D("win.restore", "Restore / minimize window", "Windows", "Meta+ArrowDown", "system", { reserved: OS_RES, alt: "Alt+Shift+ArrowDown" }),
  D("gen.save", "Save", "General", "Ctrl+S", "editor"), D("gen.saveAs", "Save as", "General", "Ctrl+Shift+S", "editor"),
  D("gen.open", "Open", "General", "Ctrl+O", "app"), D("gen.undo", "Undo", "General", "Ctrl+Z", "input", { note: "Native in text fields." }),
  D("gen.redo", "Redo", "General", "Ctrl+Y", "input"), D("gen.delete", "Delete", "General", "Delete", "app"), D("gen.rename", "Rename", "General", "F2", "app"),
  D("gen.copy", "Copy", "General", "Ctrl+C", "input"), D("gen.cut", "Cut", "General", "Ctrl+X", "input"), D("gen.paste", "Paste", "General", "Ctrl+V", "input"), D("gen.selectAll", "Select all", "General", "Ctrl+A", "input"),
  D("browser.newTab", "New tab", "Browser", "Ctrl+T", "app", { app: "browser", reserved: BR, alt: "Alt+T" }),
  D("browser.restoreTab", "Restore closed tab", "Browser", "Ctrl+Shift+T", "app", { app: "browser", reserved: BR }),
  D("browser.nextTab", "Next tab", "Browser", "Ctrl+Tab", "app", { app: "browser", reserved: BR, alt: "Alt+ArrowRight" }),
  D("browser.prevTab", "Previous tab", "Browser", "Ctrl+Shift+Tab", "app", { app: "browser", reserved: BR, alt: "Alt+ArrowLeft" }),
  D("browser.address", "Address bar", "Browser", "Ctrl+L", "app", { app: "browser" }),
  D("browser.reload", "Refresh", "Browser", "Ctrl+R", "app", { app: "browser" }),
  D("browser.bookmark", "Bookmark", "Browser", "Ctrl+D", "app", { app: "browser" }),
  D("browser.history", "History", "Browser", "Ctrl+H", "app", { app: "browser" }),
  D("browser.downloads", "Downloads", "Browser", "Ctrl+J", "app", { app: "browser" }),
  D("browser.find", "Find on page", "Browser", "Ctrl+Shift+F", "app", { app: "browser", note: "Cross-origin pages cannot be searched from a web app; searches Neux pages only." }),
  D("photo.open", "Open image", "Photo", "Ctrl+O", "app", { app: "photo" }), D("photo.save", "Save project", "Photo", "Ctrl+S", "app", { app: "photo" }),
  D("photo.export", "Export / save as", "Photo", "Ctrl+Shift+S", "app", { app: "photo" }),
  D("photo.undo", "Undo", "Photo", "Ctrl+Z", "app", { app: "photo" }), D("photo.redo", "Redo", "Photo", "Ctrl+Y", "app", { app: "photo" }),
  D("photo.zoomIn", "Zoom in", "Photo", "Ctrl+=", "app", { app: "photo", alt: "Ctrl++" }), D("photo.zoomOut", "Zoom out", "Photo", "Ctrl+-", "app", { app: "photo" }),
  D("photo.fit", "Fit image", "Photo", "Ctrl+0", "app", { app: "photo" }), D("photo.view", "Image viewing mode", "Photo", "f", "app", { app: "photo" }),
  D("photo.brushDown", "Smaller brush", "Photo", "[", "app", { app: "photo" }), D("photo.brushUp", "Larger brush", "Photo", "]", "app", { app: "photo" }),
  D("photo.panels", "Hide/show panels", "Photo", "Tab", "app", { app: "photo" }),
  D("dev.newFile", "New file", "Developer", "Ctrl+N", "app", { app: "developer" }), D("dev.newProject", "New project", "Developer", "Ctrl+Shift+N", "app", { app: "developer" }),
  D("dev.comment", "Comment line", "Developer", "Ctrl+/", "editor", { app: "developer" }),
  D("dev.palette", "Command palette", "Developer", "Ctrl+Shift+P", "app", { app: "developer", reserved: "Chrome/Firefox may use this for private windows." }),
  D("dev.sidebar", "Toggle sidebar", "Developer", "Ctrl+B", "app", { app: "developer" }),
  D("dev.run", "Run", "Developer", "F5", "app", { app: "developer" }), D("dev.stop", "Stop", "Developer", "Shift+F5", "app", { app: "developer" }),
  D("dev.tools", "Developer tools", "Developer", "F12", "app", { app: "developer", note: "Opens Neux's output/inspector panel; browser DevTools are separate." }),
];

export function normalizeCombo(c: string): string {
  const parts = c.split("+").map((p) => p.trim());
  const key = parts.pop() || "+";
  const mods = new Set(parts.map((m) => (m.toLowerCase() === "cmd" || m.toLowerCase() === "win" ? "Meta" : m.charAt(0).toUpperCase() + m.slice(1).toLowerCase())));
  const k = key.length === 1 ? key.toLowerCase() : key === "Esc" ? "Escape" : key;
  return [...["Ctrl", "Alt", "Shift", "Meta"].filter((m) => mods.has(m)), k].join("+");
}
export function comboFromEvent(e: KeyboardEvent): string {
  let k = e.key;
  if (["Control", "Shift", "Alt", "Meta"].includes(k)) return "";
  if (k === " ") k = "Space";
  if (k.length === 1) k = k.toLowerCase();
  if (e.shiftKey && k === "+") k = "+";
  if (e.key === "Dead") k = e.code;
  return [e.ctrlKey && "Ctrl", e.altKey && "Alt", e.shiftKey && "Shift", e.metaKey && "Meta", k].filter(Boolean).join("+");
}
export const bindingOf = (s: ShortcutDef) => normalizeCombo(getSetting("shortcuts")[s.id] ?? s.keys);
export function conflictsFor(id: string, combo: string, map: Record<string, string> = getSetting("shortcuts")): ShortcutDef[] {
  const me = SHORTCUTS.find((s) => s.id === id)!;
  const c = normalizeCombo(combo);
  return SHORTCUTS.filter((o) => o.id !== id && normalizeCombo(map[o.id] ?? o.keys) === c &&
    (o.scope === "system" || me.scope === "system" || o.app === me.app || !o.app || !me.app));
}
export function matches(e: KeyboardEvent): ShortcutDef[] {
  const c = comboFromEvent(e);
  if (!c) return [];
  const map = getSetting("shortcuts");
  return SHORTCUTS.filter((s) => normalizeCombo(map[s.id] ?? s.keys) === normalizeCombo(c) || (s.alt && !map[s.id] && normalizeCombo(s.alt) === normalizeCombo(c)));
}
type H = () => void | boolean;
const handlers = new Map<string, Set<H>>();
export function onShortcut(id: string, h: H) { (handlers.get(id) ?? handlers.set(id, new Set()).get(id)!).add(h); return () => { handlers.get(id)?.delete(h); }; }
/** Dispatch: app-scoped bindings for the focused app first, then system ones. Returns true if consumed. */
export function dispatchShortcut(e: KeyboardEvent, activeAppId: string | null, activeWinId: string | null): boolean {
  const list = matches(e);
  const inText = e.target instanceof HTMLElement && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.isContentEditable);
  const rank = (x: ShortcutDef) => (x.app && x.app === activeAppId ? 0 : x.scope !== "system" ? 1 : 2);
  const ordered = [...list].sort((a, b) => rank(a) - rank(b));
  for (const s of ordered) {
    if (s.scope === "input") continue; // native text editing is never intercepted
    if (s.scope !== "system" && s.app && s.app !== activeAppId) continue;
    if (inText && s.scope === "app" && !e.ctrlKey && !e.altKey && !e.metaKey && s.keys.length <= 3) continue; // plain keys inside text fields
    const hs = handlers.get(s.id);
    const key = s.app ? s.id : s.id + "@" + activeWinId;
    void key;
    if (hs && hs.size) {
      let consumed = false;
      for (const h of [...hs].reverse()) if (h() !== false) { consumed = true; break; } // latest-registered (focused app) wins
      if (consumed) { e.preventDefault(); e.stopPropagation(); return true; }
    }
  }
  return false;
}
