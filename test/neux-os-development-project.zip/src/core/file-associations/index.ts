import { getSetting, setSetting } from "../settings";
import { extOf, kindOf } from "../util";
import { openApp, alertBox } from "../os";
import { checkOpen, logEvent } from "../security";
import { basename } from "../filesystem/neuxfs";
import { fs } from "../kernel";

export const DEFAULT_ASSOC: Record<string, string> = {};
const set = (app: string, ...exts: string[]) => exts.forEach((e) => (DEFAULT_ASSOC[e] = app));
set("media", "mp3", "flac", "wav", "aac", "alac", "m4a", "ogg", "opus", "aiff", "aif", "mp4", "mkv", "mov", "webm");
set("gallery", "png", "jpg", "jpeg", "webp", "tif", "tiff", "avif", "gif", "bmp");
set("pdf", "pdf"); set("texteditor", "txt", "md", "lrc", "csv", "json", "css", "js", "nxl");
set("browser", "html", "htm"); set("runtime", "wr"); set("installer", "wrapp", "nxe"); set("photo", "wrphoto"); set("archive", "zip");

export const defaultAppFor = (name: string) => getSetting("assoc")[extOf(name)] ?? DEFAULT_ASSOC[extOf(name)];
export const setAssociation = (ext: string, appId: string) => setSetting("assoc", { ...getSetting("assoc"), [ext.toLowerCase()]: appId });
export const resetAssociations = () => setSetting("assoc", {});

/** Apps able to open a given file (capability registry). */
export function compatibleApps(name: string): string[] {
  const k = kindOf(name), e = extOf(name);
  const out = new Set<string>();
  if (defaultAppFor(name)) out.add(defaultAppFor(name)!);
  if (k === "audio" || k === "video") out.add("media");
  if (k === "image") { out.add("gallery"); if (e !== "wrphoto") out.add("photo"); else out.add("photo"); }
  if (["txt", "md", "lrc", "csv", "json", "css", "js", "nxl", "wr", "html", "htm"].includes(e)) { out.add("texteditor"); out.add("developer"); }
  if (["html", "htm", "pdf", "svg"].includes(e) || k === "image") out.add("browser");
  if (e === "pdf") out.add("pdf");
  if (e === "zip" || e === "wrapp" || e === "nxe") out.add("archive");
  if (e === "wr" || e === "nxl") out.add("runtime");
  return [...out];
}

/** Open a file by association. Unknown types are never executed. */
export async function openFile(path: string, withApp?: string): Promise<void> {
  const name = basename(path);
  try { await fs.stat(path); } catch { await alertBox("Cannot open", `File not found: ${path}`); return; }
  const app = withApp ?? defaultAppFor(name);
  const intent = ["runtime", "installer"].includes(app ?? "") || ["wr", "wrapp", "nxe"].includes(extOf(name)) ? "run" : "view";
  const d = await checkOpen(path, intent === "run" && !withApp ? "run" : "view");
  if (!d.allowed) { await logEvent("blocked-open", path, d.reason ?? ""); openApp("secure", { tab: "inspect", path, blocked: d.reason }); return; }
  if (!app) { openApp("openwith", { path, unknown: true }); return; }
  openApp(app, { path });
  fs.setMeta(path, { lastOpened: Date.now() }).catch(() => {});
}
