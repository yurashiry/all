import { NEUX_VERSION } from "../kernel";
import { getSetting } from "../settings";

export interface UpdateInfo { current: string; latest: string; available: boolean; notes: string; channel: string }
export async function checkForUpdate(): Promise<UpdateInfo> {
  const r = await fetch("./version.json?t=" + Date.now(), { cache: "no-store" });
  if (!r.ok) throw new Error(`version.json: HTTP ${r.status}`);
  const j = (await r.json()) as Record<string, string>;
  const ch = getSetting("channel");
  const latest = j[ch] ?? j.stable;
  return { current: NEUX_VERSION, latest, available: latest !== NEUX_VERSION, notes: j.notes ?? "", channel: ch };
}
/** Web update: drop Neux's own caches (never user data) and reload so the freshly deployed files are fetched.
    The update only counts as installed once the reloaded app reports the new version. */
export async function applyWebUpdate() {
  if ("caches" in window) for (const k of await caches.keys()) if (k.startsWith("neux-")) await caches.delete(k);
  const reg = await navigator.serviceWorker?.getRegistration();
  await reg?.update();
  location.reload();
}
