import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Neux OS — HAORÏK Laboratory",
  description: "Neux OS: a cross-platform desktop environment that runs on top of Web, Android, Windows and macOS.",
  manifest: "./manifest.json",
  icons: { icon: "./icon.svg" },
};
export const viewport: Viewport = { themeColor: "#0b0e16", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" data-theme="dark" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
