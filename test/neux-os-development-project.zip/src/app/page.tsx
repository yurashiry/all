import NeuxClient from "@/shell/NeuxClient";
export default function Page() { return <NeuxClient />; }
