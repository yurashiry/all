export type HostOS = "windows" | "macos" | "android" | "ios" | "linux" | "unknown";
export interface PlatformInfo { edition: "web" | "android" | "windows" | "macos"; host: HostOS; standalone: boolean; native: boolean; ua: string }
interface NativeBridge { edition: "android" | "windows" | "macos"; capabilities?: string[] }
declare global { interface Window { NeuxNative?: NativeBridge } }

export function detectPlatform(): PlatformInfo {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  const host: HostOS = /Android/i.test(ua) ? "android" : /iPhone|iPad/i.test(ua) ? "ios" : /Windows/i.test(ua) ? "windows" : /Mac OS X|Macintosh/i.test(ua) ? "macos" : /Linux/i.test(ua) ? "linux" : "unknown";
  const native = typeof window !== "undefined" && !!window.NeuxNative;
  const standalone = typeof window !== "undefined" && (window.matchMedia?.("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true);
  return { edition: native ? window.NeuxNative!.edition : "web", host, standalone: !!standalone, native, ua };
}
export interface Capability { name: string; available: boolean; detail: string }
export function capabilities(): Capability[] {
  const w = typeof window !== "undefined" ? window : undefined;
  const nav = typeof navigator !== "undefined" ? (navigator as Navigator & Record<string, unknown>) : undefined;
  const c = (name: string, available: boolean, detail: string): Capability => ({ name, available, detail });
  const p = detectPlatform();
  return [
    c("IndexedDB (NeuxFS storage)", !!w && "indexedDB" in w, "Primary Web storage adapter"),
    c("Persistent storage API", !!nav?.storage && "persist" in (nav.storage as object), "Lets Neux ask the browser not to evict NeuxFS"),
    c("Service worker (offline/PWA)", !!nav && "serviceWorker" in nav && !!w?.isSecureContext, w?.isSecureContext ? "Available" : "Requires HTTPS or localhost"),
    c("Web Crypto (hashing, password KDF)", !!w?.crypto?.subtle, "SHA-256, PBKDF2, AES-GCM, HMAC"),
    c("File System Access API (open host files)", !!w && "showOpenFilePicker" in w, "Falls back to <input type=file> where unavailable"),
    c("Media Capabilities API", !!nav && "mediaCapabilities" in nav, "Used for honest 4K / high-FPS decode checks"),
    c("Screen capture", !!nav?.mediaDevices && "getDisplayMedia" in (nav.mediaDevices as object), "Used by Screenshot"),
    c("Web Share API", !!nav && "share" in nav, "Used by Share"),
    c("WebSocket (BEECO bridge)", !!w && "WebSocket" in w, "BEECO/1 TCP frames are carried over a wss bridge on the Web"),
    c("Raw TCP / UDP sockets", p.native, p.native ? "Provided by the native shell bridge" : "Not available to web pages"),
    c("Full-device VPN (TUN)", false, "Web: impossible. Android VpnService / Windows TUN / macOS Network Extension need the native shells"),
    c("Hardware virtualization (hypervisor)", false, "Web: unavailable. Native shells would need platform hypervisor APIs"),
    c("Cross-origin isolation", !!w?.crossOriginIsolated, "Needed for SharedArrayBuffer-based emulators; GitHub Pages cannot set the headers"),
    c("Native shell bridge (window.NeuxNative)", p.native, p.native ? `Edition: ${p.edition}` : "Running as plain Web edition"),
  ];
}
