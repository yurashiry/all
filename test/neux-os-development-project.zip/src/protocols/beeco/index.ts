/* BEECO/1 — Neux logical networking layer. Transport: TCP (framed NDJSON). Message format: JSON.
   Browsers cannot open raw TCP: the Web adapter reaches a BEECO node through a WebSocket (wss) bridge that carries the same frames.
   Nothing in this module simulates a connection: a session exists only after a real hello/auth handshake. */
export const BEECO_VERSION = "BEECO/1";
export const SUPPORTED_VERSIONS = [BEECO_VERSION];
export const MAX_FRAME = 64 * 1024;
export const HEARTBEAT_MS = 15_000;
export const TIMEOUT_MS = 45_000;
export type MsgType = "hello" | "hello_ack" | "challenge" | "auth" | "auth_ok" | "auth_err" | "ping" | "pong" | "msg" | "discover" | "discover_result"
  | "register_server" | "register_ack" | "file_offer" | "file_accept" | "file_chunk" | "file_done" | "error" | "bye";
const TYPES = new Set<string>(["hello", "hello_ack", "challenge", "auth", "auth_ok", "auth_err", "ping", "pong", "msg", "discover", "discover_result", "register_server", "register_ack", "file_offer", "file_accept", "file_chunk", "file_done", "error", "bye"]);
export interface Envelope { beeco: "1"; id: string; type: MsgType; ts: number; seq: number; session?: string; from?: string; to?: string; payload: Record<string, unknown> }
export type ErrorCode = "bad_frame" | "bad_version" | "auth_failed" | "rate_limited" | "unknown_peer" | "not_authenticated" | "too_large" | "timeout";

let counter = 0;
const rid = () => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `id${Date.now()}${counter++}`);
export function makeEnvelope(type: MsgType, payload: Record<string, unknown> = {}, extra: Partial<Envelope> = {}): Envelope {
  return { beeco: "1", id: rid(), type, ts: Date.now(), seq: ++counter, payload, ...extra };
}
export function validateEnvelope(x: unknown): { ok: true; env: Envelope } | { ok: false; error: string } {
  if (!x || typeof x !== "object" || Array.isArray(x)) return { ok: false, error: "envelope must be an object" };
  const e = x as Record<string, unknown>;
  if (e.beeco !== "1") return { ok: false, error: "unsupported protocol major version" };
  if (typeof e.id !== "string" || e.id.length > 64) return { ok: false, error: "id invalid" };
  if (typeof e.type !== "string" || !TYPES.has(e.type)) return { ok: false, error: `unknown type ${String(e.type)}` };
  if (typeof e.ts !== "number" || typeof e.seq !== "number") return { ok: false, error: "ts/seq must be numbers" };
  if (!e.payload || typeof e.payload !== "object" || Array.isArray(e.payload)) return { ok: false, error: "payload must be an object" };
  for (const k of ["session", "from", "to"]) if (e[k] !== undefined && (typeof e[k] !== "string" || (e[k] as string).length > 128)) return { ok: false, error: `${k} invalid` };
  return { ok: true, env: e as unknown as Envelope };
}
export const encodeFrame = (e: Envelope): string => {
  const s = JSON.stringify(e) + "\n";
  if (s.length > MAX_FRAME) throw new Error("frame too large");
  return s;
};
export class FrameDecoder {
  private buf = "";
  push(chunk: string): Envelope[] {
    this.buf += chunk;
    const out: Envelope[] = [];
    let i: number;
    while ((i = this.buf.indexOf("\n")) >= 0) {
      const line = this.buf.slice(0, i); this.buf = this.buf.slice(i + 1);
      if (!line.trim()) continue;
      if (line.length > MAX_FRAME) throw new Error("too_large");
      let j: unknown;
      try { j = JSON.parse(line); } catch { throw new Error("bad_frame"); }
      const v = validateEnvelope(j);
      if (!v.ok) throw new Error("bad_frame: " + v.error);
      out.push(v.env);
    }
    if (this.buf.length > MAX_FRAME) throw new Error("too_large");
    return out;
  }
}
export interface Transport { send(data: string): void; close(): void; onData: (d: string) => void; onClose: () => void }
/** In-process transport pair — for tests and the labelled "BEECO Local (in-page loopback)" mode only. */
export function memoryPair(): [Transport, Transport] {
  const mk = (): Transport => ({ send() {}, close() {}, onData: () => {}, onClose: () => {} });
  const a = mk(), b = mk();
  let closed = false;
  const closeBoth = () => { if (closed) return; closed = true; queueMicrotask(() => { a.onClose(); b.onClose(); }); };
  a.send = (d) => { if (!closed) queueMicrotask(() => b.onData(d)); }; b.send = (d) => { if (!closed) queueMicrotask(() => a.onData(d)); };
  a.close = closeBoth; b.close = closeBoth;
  return [a, b];
}
export function websocketTransport(url: string, timeoutMs = 8000): Promise<Transport> {
  return new Promise((resolve, reject) => {
    if (!/^wss?:\/\//.test(url)) return reject(new Error("BEECO bridge URL must start with ws:// or wss://"));
    let ws: WebSocket;
    try { ws = new WebSocket(url); } catch (e) { return reject(e as Error); }
    const t: Transport = { send: (d) => ws.send(d), close: () => ws.close(), onData: () => {}, onClose: () => {} };
    const timer = setTimeout(() => { ws.close(); reject(new Error("Connection timed out")); }, timeoutMs);
    ws.onopen = () => { clearTimeout(timer); resolve(t); };
    ws.onerror = () => { clearTimeout(timer); reject(new Error("WebSocket connection failed")); };
    ws.onmessage = (m) => t.onData(typeof m.data === "string" ? m.data : "");
    ws.onclose = () => t.onClose();
  });
}
export class RateLimiter {
  private tokens: number; private last: number;
  constructor(private cap = 30, private perSec = 10, private now = () => Date.now()) { this.tokens = cap; this.last = now(); }
  take(): boolean { const n = this.now(); this.tokens = Math.min(this.cap, this.tokens + ((n - this.last) / 1000) * this.perSec); this.last = n; if (this.tokens < 1) return false; this.tokens -= 1; return true; }
}
export async function hmacHex(secret: string, data: string): Promise<string> {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return Array.from(new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(data)))).map((b) => b.toString(16).padStart(2, "0")).join("");
}
const nonce = () => Array.from(crypto.getRandomValues(new Uint8Array(16))).map((b) => b.toString(16).padStart(2, "0")).join("");

interface Peer { t: Transport; dec: FrameDecoder; id?: string; session: string; authed: boolean; challenge: string; rl: RateLimiter; lastSeen: number; name?: string }
export interface ServerOpts { name: string; secrets: Record<string, string>; rate?: { cap: number; perSec: number } }
/** Reference BEECO node (server/relay). Used for BEECO Local loopback and for tests; also implements relay fallback between authenticated peers. */
export class BeecoServer {
  peers = new Map<string, Peer>();
  registry = new Map<string, { name: string; kind: string; owner: string; meta: Record<string, unknown> }>();
  constructor(private o: ServerOpts) {}
  private send(p: Peer, type: MsgType, payload: Record<string, unknown>, extra: Partial<Envelope> = {}) { try { p.t.send(encodeFrame(makeEnvelope(type, payload, { session: p.session, from: "server", ...extra }))); } catch { /* closed */ } }
  private fail(p: Peer, code: ErrorCode, message: string, close = false) { this.send(p, "error", { code, message }); if (close) p.t.close(); }
  accept(t: Transport) {
    const p: Peer = { t, dec: new FrameDecoder(), session: nonce(), authed: false, challenge: "", rl: new RateLimiter(this.o.rate?.cap ?? 30, this.o.rate?.perSec ?? 10), lastSeen: Date.now() };
    t.onData = (d) => {
      let envs: Envelope[];
      try { envs = p.dec.push(d); } catch (e) { this.fail(p, (e as Error).message.startsWith("too_large") ? "too_large" : "bad_frame", (e as Error).message, true); return; }
      for (const e of envs) void this.handle(p, e);
    };
    t.onClose = () => { if (p.id) { this.peers.delete(p.id); for (const [k, v] of this.registry) if (v.owner === p.id) this.registry.delete(k); } };
  }
  private async handle(p: Peer, e: Envelope) {
    p.lastSeen = Date.now();
    if (!p.rl.take()) return this.fail(p, "rate_limited", "Too many messages");
    switch (e.type) {
      case "hello": {
        const vs = (e.payload.versions as string[] | undefined) ?? [];
        const v = SUPPORTED_VERSIONS.find((x) => vs.includes(x));
        if (!v) return this.fail(p, "bad_version", `Supported: ${SUPPORTED_VERSIONS.join(",")}`, true);
        p.challenge = nonce(); p.id = String(e.payload.deviceId ?? "");
        if (!p.id) return this.fail(p, "bad_frame", "deviceId required", true);
        this.send(p, "hello_ack", { version: v, server: this.o.name, heartbeatMs: HEARTBEAT_MS });
        this.send(p, "challenge", { nonce: p.challenge }); break;
      }
      case "auth": {
        const secret = p.id ? this.o.secrets[p.id] : undefined;
        const expect = secret ? await hmacHex(secret, p.challenge + ":" + p.id) : "";
        if (!secret || e.payload.proof !== expect) { this.send(p, "auth_err", { message: "Authentication failed" }); p.t.close(); return; }
        p.authed = true; this.peers.set(p.id!, p); this.send(p, "auth_ok", { session: p.session, id: p.id }); break;
      }
      case "ping": this.send(p, "pong", { echo: e.payload.n ?? null }); break;
      case "bye": p.t.close(); break;
      default: {
        if (!p.authed) return this.fail(p, "not_authenticated", "Authenticate first");
        if (e.type === "msg" || e.type.startsWith("file_")) {
          const target = e.to ? this.peers.get(e.to) : undefined;
          if (!target) return this.fail(p, "unknown_peer", `No such peer: ${e.to}`);
          target.t.send(encodeFrame({ ...e, from: p.id, session: target.session })); // relay
        } else if (e.type === "discover") {
          const kind = e.payload.kind as string | undefined;
          this.send(p, "discover_result", { nodes: [...this.peers.keys()].filter((k) => k !== p.id), servers: [...this.registry.entries()].filter(([, v]) => !kind || v.kind === kind).map(([id, v]) => ({ id, ...v })) });
        } else if (e.type === "register_server") {
          const id = nonce().slice(0, 12);
          this.registry.set(id, { name: String(e.payload.name ?? "server").slice(0, 64), kind: String(e.payload.kind ?? "app"), owner: p.id!, meta: (e.payload.meta as Record<string, unknown>) ?? {} });
          this.send(p, "register_ack", { id });
        }
      }
    }
  }
  sweep(now = Date.now()) { for (const p of this.peers.values()) if (now - p.lastSeen > TIMEOUT_MS) { this.fail(p, "timeout", "Heartbeat timeout", true); } }
}
export class BeecoClient {
  session = ""; connected = false; serverName = ""; private dec = new FrameDecoder(); private waiters = new Map<string, (e: Envelope) => void>();
  private timer: ReturnType<typeof setInterval> | null = null;
  onMessage: (e: Envelope) => void = () => {}; onClosed: () => void = () => {};
  constructor(private t: Transport, private id: string, private secret: string) {}
  private wait(type: MsgType, ms = 8000): Promise<Envelope> {
    return new Promise((res, rej) => { const to = setTimeout(() => rej(new Error(`Timed out waiting for ${type}`)), ms); this.waiters.set(type, (e) => { clearTimeout(to); res(e); }); });
  }
  async connect(): Promise<void> {
    this.t.onData = (d) => {
      try { for (const e of this.dec.push(d)) { const w = this.waiters.get(e.type); if (w) { this.waiters.delete(e.type); w(e); } else this.onMessage(e); const er = this.waiters.get("error"); void er; if (e.type === "error" || e.type === "auth_err") { const x = this.waiters.get("auth_ok"); if (x) { this.waiters.delete("auth_ok"); x(e); } } } } catch { this.t.close(); }
    };
    this.t.onClose = () => { this.connected = false; if (this.timer) clearInterval(this.timer); this.onClosed(); };
    const ack = this.wait("hello_ack"), ch = this.wait("challenge");
    this.t.send(encodeFrame(makeEnvelope("hello", { versions: SUPPORTED_VERSIONS, deviceId: this.id })));
    const a = await ack;
    if (a.type === "error") throw new Error(String(a.payload.message));
    this.serverName = String(a.payload.server);
    const c = await ch;
    const ok = this.wait("auth_ok");
    this.t.send(encodeFrame(makeEnvelope("auth", { proof: await hmacHex(this.secret, String(c.payload.nonce) + ":" + this.id) })));
    const r = await ok;
    if (r.type !== "auth_ok") throw new Error(String(r.payload.message ?? "Authentication failed"));
    this.session = String(r.payload.session); this.connected = true;
    this.timer = setInterval(() => this.t.send(encodeFrame(makeEnvelope("ping", {}, { session: this.session }))), HEARTBEAT_MS);
  }
  send(to: string, payload: Record<string, unknown>, type: MsgType = "msg") { this.t.send(encodeFrame(makeEnvelope(type, payload, { to, from: this.id, session: this.session }))); }
  async discover(kind?: string) { const w = this.wait("discover_result"); this.t.send(encodeFrame(makeEnvelope("discover", { kind }, { session: this.session }))); return (await w).payload; }
  async ping(): Promise<number> { const t0 = performance.now(); const w = this.wait("pong"); this.t.send(encodeFrame(makeEnvelope("ping", { n: 1 }, { session: this.session }))); await w; return performance.now() - t0; }
  close() { try { this.t.send(encodeFrame(makeEnvelope("bye"))); } catch { /* */ } this.t.close(); }
}
