"use client";
import { useEffect, useRef, useState } from "react";
import { os, closeDialog } from "@/core/os";
import { useStore, createStore } from "@/core/store";
import { verifyUser, createUser, listUsers } from "@/core/users";
import { NeuxLogo } from "./icons";
import { REGIONS, LANGUAGES, setSetting, getSetting, applyUkraineSuggestions, flushSettings, useSetting, translatedLanguages } from "@/core/settings";
import { net } from "@/core/networking/status";
import { SHORTCUTS } from "@/core/shortcuts";
import { fs } from "@/core/kernel";

export const setupStore = createStore({ open: false });

export function DialogHost() {
  const d = useStore(os, (s) => s.dialogs[0]);
  const [v, setV] = useState("");
  useEffect(() => { setV(d?.value ?? ""); }, [d?.id, d?.value]);
  if (!d) return null;
  const ok = () => closeDialog(d.id, d.kind === "prompt" ? v : d.kind === "confirm" ? true : undefined);
  const cancel = () => closeDialog(d.id, d.kind === "prompt" ? null : d.kind === "confirm" ? false : undefined);
  return (
    <div className="modal-bg" onKeyDown={(e) => { if (e.key === "Escape") cancel(); }} role="presentation">
      <div className="modal glass col" role="alertdialog" aria-modal="true" aria-label={d.title}>
        <h3 style={{ margin: 0 }}>{d.title}</h3>
        <div className="dim" style={{ whiteSpace: "pre-wrap" }}>{d.message}</div>
        {d.kind === "prompt" && <input className="input" autoFocus value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ok()} aria-label={d.message} />}
        <div className="row" style={{ justifyContent: "flex-end" }}>
          {d.kind !== "alert" && <button className="btn" onClick={cancel}>Cancel</button>}
          <button className={"btn " + (d.danger ? "danger" : "primary")} autoFocus={d.kind !== "prompt"} onClick={ok}>{d.ok ?? "OK"}</button>
        </div>
      </div>
    </div>
  );
}

export function LockScreen() {
  const user = useStore(os, (s) => s.user);
  const [pw, setPw] = useState(""); const [err, setErr] = useState(""); const [hasPw, setHasPw] = useState(true); const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(new Date());
  useEffect(() => { listUsers().then((u) => setHasPw(!!u.find((x) => x.name === user?.name)?.hash)); const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, [user]);
  const unlock = async () => {
    setBusy(true); setErr("");
    const ok = user ? await verifyUser(user.name, pw) : null;
    setBusy(false);
    if (ok) { setPw(""); os.set({ locked: false }); } else setErr("Incorrect password");
  };
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 20000, background: "color-mix(in srgb, var(--bg) 55%, transparent)", backdropFilter: "blur(40px)", display: "grid", placeItems: "center" }} role="dialog" aria-label="Lock screen">
      <div className="col" style={{ alignItems: "center", gap: 14, width: 300 }}>
        <div style={{ fontSize: 64, fontWeight: 200 }}>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
        <NeuxLogo size={72} /><b style={{ fontSize: 18 }}>{user?.name ?? "Neux"}</b>
        {hasPw && <input className="input" type="password" autoFocus placeholder="Password" value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && unlock()} aria-label="Password" />}
        <button className="btn primary" style={{ width: "100%" }} disabled={busy || (hasPw && !pw)} onClick={unlock}>{hasPw ? "Unlock" : "Continue"}</button>
        {err && <div role="alert" style={{ color: "var(--danger)" }}>{err}</div>}
      </div>
    </div>
  );
}

export function SetupWizard({ onDone }: { onDone: () => void }) {
  const lang = useSetting("language"); const n = useStore(net, (s) => s);
  const [step, setStep] = useState(0);
  const [name, setName] = useState(""); const [pw, setPw] = useState(""); const [err, setErr] = useState("");
  const [region, setRegion] = useState(getSetting("region")); const [ua, setUa] = useState(true);
  const [checking, setChecking] = useState(false); const [reach, setReach] = useState<string>("");
  const [existing, setExisting] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { listUsers().then((u) => setExisting(u.length > 0)); }, []);
  useEffect(() => { ref.current?.focus(); }, [step]);
  const steps = ["Welcome", "BEECO Network", "Region", "Primary language", "Secondary language", "Shortcuts & gestures", "VPN (optional)", "Ready"];
  const check = async () => {
    setChecking(true); setReach("");
    try { await fetch("https://www.gstatic.com/generate_204", { mode: "no-cors", cache: "no-store", signal: AbortSignal.timeout(6000) }); setReach("Internet reachable. BEECO can use this connection."); }
    catch { setReach(navigator.onLine ? "The host reports a network, but the internet check failed. You can continue and retry later." : "No internet connection. BEECO will stay disconnected; you can continue offline and retry later."); }
    setChecking(false);
  };
  const finish = async () => {
    try {
      if (!existing) await createUser(name.trim() || "User", "admin", pw || undefined);
      setSetting("setupDone", true); await flushSettings(); setupStore.set({ open: false }); onDone();
    } catch (e) { setErr((e as Error).message); setStep(0); }
  };
  const next = async () => {
    setErr("");
    if (step === 0 && !existing) { if (pw && pw.length < 4) return setErr("Password must be at least 4 characters (or leave empty)."); if (name.trim() && !/^[\p{L}\p{N}_ .-]{1,32}$/u.test(name.trim())) return setErr("Name may contain letters, digits, space, _ . -"); }
    if (step === 2) { setSetting("region", region); if (region === "Ukraine" && ua) applyUkraineSuggestions(); }
    if (step === steps.length - 1) return finish();
    setStep(step + 1);
  };
  const reopen = existing && getSetting("setupDone");
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 15000, display: "grid", placeItems: "center", background: "radial-gradient(60% 60% at 30% 20%, #3b6cff55, transparent), radial-gradient(50% 50% at 80% 70%, #b04bff44, transparent), var(--bg)", padding: 12 }}>
      <div ref={ref} tabIndex={-1} className="glass col" style={{ width: "min(720px, 100%)", maxHeight: "96vh", borderRadius: 20, padding: 24, outline: "none" }} role="dialog" aria-label="Setup Assistant">
        <div className="row"><NeuxLogo size={36} /><div className="grow"><b style={{ fontSize: 18 }}>{steps[step]}</b><div className="dim small">Step {step + 1} of {steps.length} · Neux Setup Assistant</div></div>
          {(step > 0 && step < steps.length - 1 || reopen) && <button className="btn ghost sm" onClick={() => (reopen ? (setupStore.set({ open: false }), onDone()) : setStep(steps.length - 1))}>{reopen ? "Close" : "Skip rest"}</button>}</div>
        <div className="pbar"><div style={{ width: `${((step + 1) / steps.length) * 100}%` }} /></div>
        <div className="scroll col" style={{ minHeight: 280, paddingRight: 4 }}>
          {step === 0 && <>
            <p>Welcome to <b>Neux OS</b> by HAORÏK Laboratory. Neux runs on top of your device&apos;s operating system; it does not replace it. Everything is stored locally in NeuxFS — no cloud account is needed.</p>
            {existing ? <p className="badge ok" style={{ alignSelf: "flex-start" }}>A local account already exists.</p> : <>
              <label className="col" style={{ gap: 4 }}>Create your local account<input className="input" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} maxLength={32} aria-label="Account name" /></label>
              <input className="input" type="password" placeholder="Password (optional)" value={pw} onChange={(e) => setPw(e.target.value)} aria-label="Password" />
              <div className="dim small">Passwords are stored as salted PBKDF2-SHA-256 hashes (210 000 iterations) in NeuxFS. The first account is an administrator.</div></>}
            {err && <div role="alert" style={{ color: "var(--danger)" }}>{err}</div>}</>}
          {step === 1 && <>
            <p><b>BEECO</b> is Neux&apos;s logical networking layer. It is <b>not</b> Wi-Fi, an ISP, a router, a SIM card, a separate internet connection or a VPN. Neux uses your device&apos;s existing connection.</p>
            <div className="card">Host connection: <b>{n.online ? "online" : "offline"}</b> ({n.connection}) · BEECO: <b>{n.beeco.state}</b><div className="dim small">{n.beeco.detail}</div></div>
            <div className="dim small">Nearby Wi-Fi networks: web browsers cannot list Wi-Fi networks. Native editions show them only where the OS API and permissions allow it.</div>
            <div className="row"><button className="btn" onClick={check} disabled={checking}>{checking ? <span className="spinner" /> : null} Check connection</button></div>
            {reach && <div role="status">{reach}</div>}
            <div className="dim small">You can continue offline. BEECO nodes are configured later in the BEECO app; no connection is ever simulated.</div></>}
          {step === 2 && <>
            <p className="dim">Region only affects formats and suggestions. It never implies your identity or citizenship.</p>
            <select className="input" size={10} value={region} onChange={(e) => setRegion(e.target.value)} aria-label="Region">
              <option value="">— Not set —</option>
              <optgroup label="Pinned">{REGIONS.pinned.map((r) => <option key={r}>{r}</option>)}</optgroup>
              <optgroup label="All regions (A–Z)">{REGIONS.others.map((r) => <option key={r}>{r}</option>)}</optgroup>
            </select>
            {region === "Ukraine" && <label className="card row" style={{ alignItems: "flex-start" }}><input type="checkbox" checked={ua} onChange={(e) => setUa(e.target.checked)} /><span>Apply optional Ukrainian suggestions: Ukrainian language, Ukrainian keyboard layout preference, Hryvnia (UAH), local date/number formats, Europe/Kyiv time zone, regional Store collection and regional wallpaper &amp; holidays.</span></label>}</>}
          {(step === 3 || step === 4) && <>
            <p className="dim">{step === 3 ? "Choose the interface language." : "Optional secondary language (used as fallback)."} Fully translated: {translatedLanguages.join(", ")}. Others fall back to English until a language pack is added.</p>
            <div className="col" style={{ gap: 2 }}>{step === 4 && <label className="row"><input type="radio" name="l2" checked={getSetting("secondaryLanguage") === ""} onChange={() => setSetting("secondaryLanguage", "")} />None</label>}
              {LANGUAGES.filter(([c]) => step === 3 || c !== lang).map(([c, l]) => <label key={c} className="row" style={{ padding: "3px 0" }}><input type="radio" name={"l" + step} checked={(step === 3 ? lang : getSetting("secondaryLanguage")) === c} onChange={() => setSetting(step === 3 ? "language" : "secondaryLanguage", c)} />{l}</label>)}</div></>}
          {step === 5 && <>
            <p>Core shortcuts (Ctrl is used on Windows <i>and</i> macOS). You can change them in Settings → Keyboard Shortcuts.</p>
            <table className="tbl"><tbody>{SHORTCUTS.filter((s) => s.category === "Global").map((s) => <tr key={s.id}><td><kbd>{s.keys.replace("ArrowLeft", "←").replace("ArrowRight", "→").replace("Escape", "Esc")}</kbd></td><td>{s.label}</td></tr>)}</tbody></table>
            <p className="dim small"><b>Gestures:</b> drag a title bar to move · drag to the left/right screen edge to snap · drag to the top edge to maximize · double-click a title bar to maximize · right-click anywhere for context menus · on touch screens windows are full-screen.</p>
            <p className="dim small">Alt+Tab and Alt+F4 are reserved by your host OS; Neux provides Alt+Q (switch) and Alt+Shift+W (close) as alternatives in the Web edition.</p></>}
          {step === 6 && <><p>VPN is optional and separate from BEECO. Import subscriptions in <b>VPN Manager</b> at any time. The Web edition cannot create a device-wide VPN; native editions can (Android VpnService, Windows TUN, macOS Network Extension).</p><div className="card dim">Nothing is configured here, nothing is uploaded. Open VPN Manager after setup to import a subscription.</div></>}
          {step === 7 && <><p>Setup complete. Settings were saved to <code>NeuxFS/Configuration/settings.json</code>. You can reopen this assistant from <b>Settings → System → Setup Assistant</b>.</p>
            <div className="card small">Region: {region || "not set"} · Language: {LANGUAGES.find(([c]) => c === getSetting("language"))?.[1]} · Network: {n.online ? "online" : "offline"} · BEECO: {n.beeco.state}</div></>}
        </div>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <button className="btn" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</button>
          <button className="btn primary" onClick={next}>{step === steps.length - 1 ? "Start Neux" : step === 1 || step === 6 ? "Continue" : "Next"}</button>
        </div>
      </div>
    </div>
  );
}

export function BootScreen({ steps, done, error, onRetry, onRepair, onErase }: { steps: { name: string; state: "wait" | "run" | "ok" | "fail" }[]; done: number; error: string | null; onRetry: () => void; onRepair: () => void; onErase: () => void }) {
  return (
    <div style={{ position: "fixed", inset: 0, display: "grid", placeItems: "center", background: "radial-gradient(60% 60% at 30% 20%, #3b6cff44, transparent), var(--bg)" }}>
      <div className="col" style={{ alignItems: "center", width: "min(420px, 92vw)" }}>
        <NeuxLogo size={88} /><h2 style={{ margin: 0, fontWeight: 500 }}>Neux OS</h2><div className="dim small">HAORÏK Laboratory</div>
        <div className="pbar" style={{ width: "100%" }}><div style={{ width: `${(done / steps.length) * 100}%` }} /></div>
        <div className="col small" style={{ width: "100%", gap: 2 }} aria-live="polite">{steps.map((s) => <div key={s.name} className="row dim"><span style={{ width: 14, color: s.state === "ok" ? "var(--ok)" : s.state === "fail" ? "var(--danger)" : undefined }}>{s.state === "ok" ? "✓" : s.state === "fail" ? "✗" : s.state === "run" ? "…" : "·"}</span>{s.name}</div>)}</div>
        {error && <div className="card col" role="alert" style={{ width: "100%", borderColor: "var(--danger)" }}>
          <b>Neux could not start</b><div className="small mono" style={{ wordBreak: "break-word" }}>{error}</div>
          <div className="dim small">Emergency recovery (works without the desktop):</div>
          <div className="row wrap"><button className="btn sm" onClick={onRetry}>Retry</button><button className="btn sm" onClick={onRepair}>Repair system folders</button><button className="btn sm danger" onClick={onErase}>Erase all Neux data…</button></div></div>}
      </div>
    </div>
  );
}
void fs;
