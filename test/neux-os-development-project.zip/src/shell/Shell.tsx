"use client";
import { useEffect, useMemo, useRef, useState, type PointerEvent as RPE } from "react";
import { os, openApp, closeWin, focusWin, minimizeWin, toggleMaximize, toggleWinFullscreen, snapWin, setBounds, toggleStart, closeMenus, showMenu, addDesktop, switchDesktop, cycleWindows, notify, type Win, type MenuItem } from "@/core/os";
import { useStore } from "@/core/store";
import { useSetting, setSetting, getSetting, useT, settingsStore } from "@/core/settings";
import { dispatchShortcut, onShortcut } from "@/core/shortcuts";
import { BUILTIN } from "@/core/applications/registry";
import { installedStore, uninstallApp } from "@/core/applications/wrapp";
import { AppIcon, Glyph } from "./icons";
import { WinContext, useFs, FileGlyph, Switch } from "./ui";
import { wallpaperCss } from "./wallpapers";
import { AppView } from "@/apps";
import { openFile } from "@/core/file-associations";
import { fs } from "@/core/kernel";
import { net } from "@/core/networking/status";
import { formatBytes } from "@/core/util";
import { handleNeuxUri } from "@/core/api";
import { HOLIDAYS } from "./wallpapers";
import { join } from "@/core/filesystem/neuxfs";
import { promptBox } from "@/core/os";
import { setIsolation } from "@/core/security";

const appKey = (w: Win) => (w.appId === "pkg" ? "pkg:" + w.params.pkgId : w.appId);
const keyName = (k: string) => (k.startsWith("pkg:") ? installedStore.get().apps.find((a) => a.manifest.id === k.slice(4))?.manifest.name ?? k.slice(4) : BUILTIN.find((b) => b.id === k)?.name ?? k);
const openKey = (k: string) => (k.startsWith("pkg:") ? openApp("pkg", { pkgId: k.slice(4) }) : openApp(k));
function useIsMobile() {
  const [m, setM] = useState(false);
  useEffect(() => { const f = () => setM(window.innerWidth < 760); f(); window.addEventListener("resize", f); return () => window.removeEventListener("resize", f); }, []);
  return m;
}

function WindowFrame({ w, mobile }: { w: Win; mobile: boolean }) {
  const active = useStore(os, (s) => s.activeId === w.id);
  const curDesk = useStore(os, (s) => s.current);
  const drag = useRef<{ dx: number; dy: number; moved: boolean } | null>(null);
  const [dragging, setDragging] = useState(false);
  const full = w.state === "maximized" || mobile, fs_ = w.state === "fullscreen";
  const hidden = w.state === "minimized" || w.desktop !== curDesk;
  const onBarDown = (e: RPE) => {
    if ((e.target as HTMLElement).closest("button")) return;
    focusWin(w.id);
    if (mobile || w.state === "fullscreen") return;
    let x = w.x, y = w.y;
    if (w.state === "maximized") { const pw = w.prev?.w ?? 800; x = e.clientX - pw * (e.clientX / window.innerWidth); y = 0; toggleMaximize(w.id, true); setBounds(w.id, { x, y }); }
    drag.current = { dx: e.clientX - x, dy: e.clientY - y, moved: false };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); setDragging(true);
  };
  const onBarMove = (e: RPE) => { const d = drag.current; if (!d) return; d.moved = true; setBounds(w.id, { x: e.clientX - d.dx, y: Math.max(0, e.clientY - d.dy) }); };
  const onBarUp = (e: RPE) => {
    if (!drag.current) return; const moved = drag.current.moved; drag.current = null; setDragging(false);
    if (!moved) return;
    if (e.clientY < 6) toggleMaximize(w.id); else if (e.clientX < 6) snapWin(w.id, "left"); else if (e.clientX > window.innerWidth - 6) snapWin(w.id, "right");
  };
  const startResize = (dir: string) => (e: RPE) => {
    if (w.state !== "normal") return; e.stopPropagation(); e.preventDefault(); focusWin(w.id);
    const sx = e.clientX, sy = e.clientY, o = { x: w.x, y: w.y, w: w.w, h: w.h };
    const el = e.currentTarget as HTMLElement; el.setPointerCapture(e.pointerId); setDragging(true);
    const mv = (ev: PointerEvent) => {
      const dx = ev.clientX - sx, dy = ev.clientY - sy; const b = { ...o };
      if (dir.includes("e")) b.w = Math.max(320, o.w + dx); if (dir.includes("s")) b.h = Math.max(200, o.h + dy);
      if (dir.includes("w")) { b.w = Math.max(320, o.w - dx); b.x = o.x + (o.w - b.w); } if (dir.includes("n")) { b.h = Math.max(200, o.h - dy); b.y = Math.max(0, o.y + (o.h - b.h)); }
      setBounds(w.id, b);
    };
    const up = () => { el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); setDragging(false); };
    el.addEventListener("pointermove", mv); el.addEventListener("pointerup", up);
  };
  const style: React.CSSProperties = fs_ ? { left: 0, top: 0, width: "100vw", height: "100vh", zIndex: 9600 }
    : full ? { left: 0, top: 0, width: "100vw", height: mobile ? "calc(100vh - 58px)" : "calc(100vh - 78px)", zIndex: w.z }
    : { left: w.x, top: w.y, width: w.w, height: w.h, zIndex: w.z };
  const menu = (e: React.MouseEvent) => {
    const items: MenuItem[] = [
      { label: w.state === "normal" ? "Maximize" : "Restore", action: () => toggleMaximize(w.id) }, { label: "Minimize", action: () => minimizeWin(w.id) },
      { label: w.state === "fullscreen" ? "Exit fullscreen" : "Fullscreen window", action: () => toggleWinFullscreen(w.id) },
      { label: "Snap left", action: () => snapWin(w.id, "left") }, { label: "Snap right", action: () => snapWin(w.id, "right") }, { label: "", separator: true },
      ...Array.from({ length: os.get().desktops }, (_, i) => ({ label: `Move to desktop ${i + 1}`, disabled: i === w.desktop, action: () => os.set((s) => ({ windows: s.windows.map((x) => (x.id === w.id ? { ...x, desktop: i } : x)) })) })),
      { label: "", separator: true }, { label: "Close", danger: true, action: () => closeWin(w.id) },
    ];
    showMenu(e, items);
  };
  return (
    <div className={`win glass ${active ? "focused" : ""} ${full ? "max" : ""} ${fs_ ? "full" : ""} ${dragging ? "dragging" : ""}`} style={{ ...style, display: w.desktop !== curDesk ? "none" : undefined, visibility: hidden ? "hidden" : "visible", opacity: hidden ? 0 : 1, pointerEvents: hidden ? "none" : "auto" }}
      onPointerDownCapture={() => { if (!active) focusWin(w.id); }} role="dialog" aria-label={w.title}>
      {!fs_ && (
        <div className="win-bar" onPointerDown={onBarDown} onPointerMove={onBarMove} onPointerUp={onBarUp} onDoubleClick={() => !mobile && toggleMaximize(w.id)} onContextMenu={menu}>
          {w.appId === "pkg" ? <AppIcon id={"pkg:" + w.params.pkgId} size={20} /> : <AppIcon id={w.appId} size={20} />}
          <div className="win-title">{w.title}</div>
          <button className="win-btn" aria-label="Minimize" title="Minimize" onClick={() => minimizeWin(w.id)}>⌄</button>
          <button className="win-btn" aria-label={w.state === "maximized" ? "Restore" : "Maximize"} title={w.state === "maximized" ? "Restore" : "Maximize"} onClick={() => toggleMaximize(w.id)}>⌃</button>
          <button className="win-btn close" aria-label="Close" title="Close" onClick={() => closeWin(w.id)}>×</button>
        </div>
      )}
      <div className="win-body" style={{ pointerEvents: dragging ? "none" : undefined }}>
        <WinContext.Provider value={{ id: w.id, params: w.params, rev: w.rev, focused: active }}><AppView appId={w.appId} /></WinContext.Provider>
      </div>
      {w.state === "normal" && !mobile && ["n", "s", "e", "w", "ne", "nw", "se", "sw"].map((d) => (
        <div key={d} className="rz" onPointerDown={startResize(d)} style={{ cursor: `${d}-resize`, ...(d.includes("n") ? { top: -3, height: 8 } : d.includes("s") ? { bottom: -3, height: 8 } : { top: 8, bottom: 8 }), ...(d.includes("w") ? { left: -3, width: 8 } : d.includes("e") ? { right: -3, width: 8 } : { left: 8, right: 8 }), ...(d.length === 2 ? { width: 14, height: 14, top: d.includes("n") ? -4 : undefined, bottom: d.includes("s") ? -4 : undefined } : {}) }} />
      ))}
    </div>
  );
}

function DesktopIcons() {
  const [items] = useFs(() => fs.list("/Users/Default/Desktop"), [], []);
  const [sel, setSel] = useState("");
  return (
    <>
      {items.sort((a, b) => a.name.localeCompare(b.name)).map((n, i) => (
        <div key={n.path} className={"dicon" + (sel === n.path ? " sel" : "")} style={{ left: 12 + Math.floor(i / 6) * 100, top: 12 + (i % 6) * 100 }} tabIndex={0}
          onClick={(e) => { e.stopPropagation(); setSel(n.path); }} onDoubleClick={() => (n.type === "dir" ? openApp("explorer", { path: n.path }) : openFile(n.path))} onKeyDown={(e) => e.key === "Enter" && (n.type === "dir" ? openApp("explorer", { path: n.path }) : openFile(n.path))}
          onContextMenu={(e) => showMenu(e, [{ label: "Open", action: () => (n.type === "dir" ? openApp("explorer", { path: n.path }) : openFile(n.path)) }, { label: "Move to Trash", danger: true, action: () => fs.trash(n.path) }])}>
          <FileGlyph node={n} size={38} /><span style={{ wordBreak: "break-word" }}>{n.name}</span>
        </div>
      ))}
    </>
  );
}

function Widgets() {
  const widgets = useSetting("widgets"); const region = useSetting("region"); const use24 = useSetting("use24h");
  const [now, setNow] = useState(() => new Date());
  const [used, setUsed] = useState(0);
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { const f = () => fs.usage().then(setUsed).catch(() => {}); f(); return fs.subscribe(f); }, []);
  const hol = (HOLIDAYS[region] ?? []).find((h) => h.m === now.getMonth() + 1 && h.d === now.getDate());
  return (
    <div style={{ position: "absolute", right: 16, top: 16, display: "flex", flexDirection: "column", gap: 12, alignItems: "flex-end" }}>
      {widgets.includes("clock") && <div className="widget glass"><div style={{ fontSize: 38, fontWeight: 300, fontVariantNumeric: "tabular-nums" }}>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: !use24 })}</div><div className="dim">{now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}</div>{hol && <div className="badge ok" style={{ marginTop: 6 }}>Today: {hol.name}</div>}</div>}
      {widgets.includes("storage") && <div className="widget glass"><div className="dim small">NeuxFS storage used</div><div style={{ fontSize: 22 }}>{formatBytes(used)}</div></div>}
      {widgets.includes("calendar") && <div className="widget glass"><div className="dim small">{now.toLocaleDateString([], { month: "long", year: "numeric" })}</div><div style={{ fontSize: 40, fontWeight: 300 }}>{now.getDate()}</div></div>}
    </div>
  );
}

function Hotbar() {
  const t = useT();
  const windows = useStore(os, (s) => s.windows); const active = useStore(os, (s) => s.activeId); const desktops = useStore(os, (s) => s.desktops); const cur = useStore(os, (s) => s.current);
  const unread = useStore(os, (s) => s.notifications.filter((n) => !n.read).length);
  const n = useStore(net, (s) => s); const pinned = useSetting("pinned"); const muted = useSetting("muted"); const use24 = useSetting("use24h");
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const x = setInterval(() => setNow(new Date()), 15000); return () => clearInterval(x); }, []);
  const keys = useMemo(() => { const ks = [...pinned]; windows.forEach((w) => { const k = appKey(w); if (!ks.includes(k)) ks.push(k); }); return ks; }, [pinned, windows]);
  const click = (k: string) => {
    const ws = windows.filter((w) => appKey(w) === k);
    if (!ws.length) return void openKey(k);
    const visible = ws.find((w) => w.id === active && w.state !== "minimized" && w.desktop === cur);
    if (visible) minimizeWin(visible.id); else { const w = ws.find((x) => x.desktop === cur) ?? ws[0]; os.set((s) => ({ windows: s.windows.map((x) => (x.id === w.id ? { ...x, desktop: cur } : x)) })); focusWin(w.id); }
  };
  const ctx = (k: string) => (e: React.MouseEvent) => showMenu(e, [
    { label: "Open" + (windows.some((w) => appKey(w) === k) ? " new window" : ""), action: () => openKey(k) },
    { label: pinned.includes(k) ? "Unpin from Hotbar" : "Pin to Hotbar", action: () => setSetting("pinned", pinned.includes(k) ? pinned.filter((x) => x !== k) : [...pinned, k]) },
    ...(windows.some((w) => appKey(w) === k) ? [{ label: "Close all windows", danger: true, action: () => windows.filter((w) => appKey(w) === k).forEach((w) => closeWin(w.id)) }] : []),
  ]);
  const bst = n.beeco.state;
  return (
    <nav className="hotbar glass" aria-label="Hotbar" onPointerDown={(e) => e.stopPropagation()} onContextMenu={(e) => showMenu(e, [{ label: "Hotbar & Start settings", action: () => openApp("settings", { page: "personalization" }) }])}>
      <button className="hb-btn" title={n.online ? `Connected (${n.connection})` : "No internet connection"} aria-label="Connectivity" onClick={() => os.set({ quickOpen: !os.get().quickOpen, startOpen: false, notifOpen: false })}><Glyph name={n.online ? "wifi" : "nowifi"} size={18} /></button>
      <button className="hb-btn" title={`BEECO: ${bst} — ${n.beeco.detail}`} aria-label={`BEECO ${bst}`} onClick={() => openApp("beeco")} style={{ color: bst === "connected" ? "var(--ok)" : bst === "error" ? "var(--danger)" : undefined }}><Glyph name="beeco" size={18} /></button>
      <button className="hb-btn" title={`VPN: ${n.vpn.state} — ${n.vpn.detail}`} aria-label={`VPN ${n.vpn.state}`} onClick={() => openApp("vpn")} style={{ color: n.vpn.state === "on" ? "var(--ok)" : undefined }}><Glyph name="vpn" size={18} /></button>
      <span className="hb-sep" />
      <button className="hb-btn" aria-label={t("start")} title={`${t("start")} (Ctrl+Space)`} onClick={toggleStart}><span style={{ color: "var(--accent)" }}><Glyph name="start" size={24} stroke={2.2} /></span></button>
      {keys.map((k) => {
        const open = windows.some((w) => appKey(w) === k); const focus = windows.some((w) => appKey(w) === k && w.id === active && w.state !== "minimized");
        return <button key={k} className={"hb-btn" + (open ? " active" : "") + (focus ? " focus" : "")} title={keyName(k)} aria-label={keyName(k)} onClick={() => click(k)} onContextMenu={ctx(k)}><AppIcon id={k} size={30} /></button>;
      })}
      <span className="hb-sep" />
      {desktops > 1 && <div className="row" style={{ gap: 2 }}>{Array.from({ length: desktops }, (_, i) => <button key={i} className={"btn sm" + (i === cur ? " primary" : " ghost")} aria-label={`Desktop ${i + 1}`} onClick={() => switchDesktop(i)}>{i + 1}</button>)}</div>}
      <button className="hb-btn" aria-label="Sound and quick settings" title={muted ? "Muted" : "Sound"} onClick={() => os.set({ quickOpen: !os.get().quickOpen, startOpen: false, notifOpen: false })}><Glyph name={muted ? "mute" : "volume"} size={18} /></button>
      <button className="hb-btn" aria-label={`${t("notifications")}${unread ? `, ${unread} unread` : ""}`} onClick={() => os.set({ notifOpen: !os.get().notifOpen, startOpen: false, quickOpen: false })} style={{ position: "relative" }}><Glyph name="bell" size={18} />{unread > 0 && <span style={{ position: "absolute", top: 4, right: 4, background: "var(--danger)", color: "#fff", borderRadius: 8, fontSize: 10, padding: "0 4px" }}>{unread}</span>}</button>
      <button className="hb-btn" aria-label="Clock" style={{ flexDirection: "column", fontSize: 12, lineHeight: 1.1, minWidth: 54 }} onClick={() => openApp("calendar")}><span>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: !use24 })}</span><span className="dim" style={{ fontSize: 10 }}>{now.toLocaleDateString([], { month: "short", day: "numeric" })}</span></button>
    </nav>
  );
}

function StartMenu() {
  const t = useT(); const open = useStore(os, (s) => s.startOpen); const pinned = useSetting("pinned"); const installed = useStore(installedStore, (s) => s.apps);
  const [q, setQ] = useState(""); const ref = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<{ path: string; name: string; type: "file" | "dir" }[]>([]);
  useEffect(() => { if (open) { setQ(""); setTimeout(() => ref.current?.focus(), 30); } }, [open]);
  useEffect(() => { if (q.length < 2 || q.startsWith("open ")) { setFiles([]); return; } let on = true; fs.search(q, "/Users", 8).then((r) => on && setFiles(r)).catch(() => {}); return () => { on = false; }; }, [q]);
  const user = useStore(os, (s) => s.user);
  const all = useMemo(() => [...BUILTIN.filter((b) => !["picker", "openwith", "installer"].includes(b.id)).map((b) => ({ key: b.id, name: b.name })), ...installed.map((a) => ({ key: "pkg:" + a.manifest.id, name: a.manifest.name }))].sort((a, b) => a.name.localeCompare(b.name)), [installed]);
  if (!open) return null;
  const list = q ? all.filter((a) => a.name.toLowerCase().includes(q.toLowerCase())) : all;
  const go = (k: string) => { openKey(k); closeMenus(); };
  const menu = (k: string) => (e: React.MouseEvent) => showMenu(e, [{ label: "Open", action: () => go(k) }, { label: pinned.includes(k) ? "Unpin from Hotbar" : "Pin to Hotbar", action: () => setSetting("pinned", pinned.includes(k) ? pinned.filter((x) => x !== k) : [...pinned, k]) }, ...(k.startsWith("pkg:") ? [{ label: "Uninstall", danger: true, action: () => uninstallApp(k.slice(4)) }] : [])]);
  return (
    <div className="panel glass" style={{ left: "50%", transform: "translateX(-50%)", bottom: 78, width: "min(640px, calc(100vw - 16px))", height: "min(560px, calc(100vh - 100px))", display: "flex", flexDirection: "column", gap: 10 }} onPointerDown={(e) => e.stopPropagation()} role="dialog" aria-label="Start menu">
      <input ref={ref} className="input" placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" onKeyDown={(e) => { if (e.key === "Enter") { if (handleNeuxUri(q)) return closeMenus(); if (list[0]) go(list[0].key); } if (e.key === "Escape") closeMenus(); }} />
      <div className="scroll grow">
        {q && /^open\s+console/i.test(q) && <button className="btn" onClick={() => { handleNeuxUri(q); closeMenus(); }}>Run: {q}</button>}
        {!q && pinned.length > 0 && <><div className="dim small" style={{ margin: "4px 4px" }}>{t("pinned")}</div><div className="grid-apps">{pinned.map((k) => <button key={k} className="tile" onClick={() => go(k)} onContextMenu={menu(k)}><AppIcon id={k} size={44} />{keyName(k)}</button>)}</div></>}
        <div className="dim small" style={{ margin: "10px 4px 4px" }}>{q ? "Apps" : t("allApps")}</div>
        <div className="grid-apps">{list.map((a) => <button key={a.key} className="tile" onClick={() => go(a.key)} onContextMenu={menu(a.key)}><AppIcon id={a.key} size={44} />{a.name}</button>)}</div>
        {q && files.length > 0 && <><div className="dim small" style={{ margin: "10px 4px 4px" }}>Files</div>{files.map((f) => <div key={f.path} className="frow" onClick={() => { f.type === "dir" ? openApp("explorer", { path: f.path }) : openFile(f.path); closeMenus(); }}><FileGlyph node={f} /><span>{f.name}</span><span className="dim small grow" style={{ textAlign: "right" }}>{f.path}</span></div>)}</>}
        {q && !list.length && !files.length && <div className="dim" style={{ padding: 16 }}>No results for “{q}”.</div>}
      </div>
      <div className="row"><span className="dim small grow">{user?.name ?? "Guest"} · {user?.role}</span>
        <button className="btn sm" onClick={() => { closeMenus(); openApp("settings"); }}>{t("settings")}</button>
        <button className="btn sm" onClick={() => { closeMenus(); os.set({ locked: true }); }}>{t("lock")}</button></div>
    </div>
  );
}

function QuickSettings() {
  const open = useStore(os, (s) => s.quickOpen); const s = useStore(settingsStore, (x) => x); const n = useStore(net, (x) => x);
  if (!open) return null;
  const fsToggle = () => { if (document.fullscreenElement) void document.exitFullscreen(); else void document.documentElement.requestFullscreen().catch(() => notify({ title: "Fullscreen unavailable", message: "The browser denied fullscreen." })); };
  return (
    <div className="panel glass col" style={{ right: 10, bottom: 78, width: 330 }} onPointerDown={(e) => e.stopPropagation()} role="dialog" aria-label="Quick settings">
      <div className="row"><Glyph name={s.theme === "light" ? "sun" : "moon"} /><span className="grow">Theme</span>
        {(["dark", "light", "auto"] as const).map((m) => <button key={m} className={"btn sm" + (s.theme === m ? " primary" : "")} onClick={() => setSetting("theme", m)}>{m}</button>)}</div>
      <div className="row"><Glyph name={s.muted ? "mute" : "volume"} /><input className="range" type="range" min={0} max={1} step={0.01} value={s.volume} aria-label="Volume" onChange={(e) => { setSetting("volume", Number(e.target.value)); setSetting("muted", false); }} /><button className="btn sm" onClick={() => setSetting("muted", !s.muted)}>{s.muted ? "Unmute" : "Mute"}</button></div>
      <hr className="sep" />
      <div className="row"><span className="grow">Reduce motion</span><Switch label="Reduce motion" checked={s.reduceMotion} onChange={(v) => setSetting("reduceMotion", v)} /></div>
      <div className="row"><span className="grow">Glass blur</span><Switch label="Glass blur" checked={s.blur} onChange={(v) => setSetting("blur", v)} /></div>
      <div className="row"><span className="grow">High contrast</span><Switch label="High contrast" checked={s.highContrast} onChange={(v) => setSetting("highContrast", v)} /></div>
      <div className="row"><span className="grow">File isolation protection</span><Switch label="File isolation protection" checked={s.isolation} onChange={(v) => setIsolation(v)} /></div>
      <hr className="sep" />
      <div className="small dim">Internet: {n.online ? `connected (${n.connection})` : "offline"}<br />BEECO: {n.beeco.state} — {n.beeco.detail}<br />VPN: {n.vpn.state}</div>
      <div className="row wrap"><button className="btn sm" onClick={fsToggle}>Fullscreen</button><button className="btn sm" onClick={() => { closeMenus(); openApp("settings"); }}>All settings</button><button className="btn sm" onClick={() => { closeMenus(); os.set({ locked: true }); }}>Lock</button><button className="btn sm" onClick={addDesktop}>New desktop</button></div>
    </div>
  );
}

function NotificationCenter() {
  const open = useStore(os, (s) => s.notifOpen); const list = useStore(os, (s) => s.notifications); const t = useT();
  useEffect(() => { if (open) os.set((s) => ({ notifications: s.notifications.map((n) => ({ ...n, read: true })) })); }, [open]);
  if (!open) return null;
  return (
    <div className="panel glass col" style={{ right: 10, bottom: 78, width: 340, maxHeight: "60vh" }} onPointerDown={(e) => e.stopPropagation()} role="dialog" aria-label={t("notifications")}>
      <div className="row"><b className="grow">{t("notifications")}</b><button className="btn sm" onClick={() => os.set({ notifications: [] })} disabled={!list.length}>Clear all</button></div>
      <div className="scroll col">{list.length === 0 ? <div className="dim" style={{ padding: 16, textAlign: "center" }}>{t("noNotifs")}</div> : list.map((n) => <div key={n.id} className="card" style={{ cursor: n.appId ? "pointer" : undefined }} onClick={() => n.appId && (openApp(n.appId), closeMenus())}><b>{n.title}</b><div className="small">{n.message}</div><div className="dim small">{new Date(n.ts).toLocaleTimeString()}</div></div>)}</div>
    </div>
  );
}

function ContextMenuHost() {
  const m = useStore(os, (s) => s.menu);
  if (!m) return null;
  const x = Math.min(m.x, window.innerWidth - 210), y = Math.min(m.y, window.innerHeight - m.items.length * 32 - 16);
  return (
    <div className="menu glass" role="menu" style={{ left: x, top: Math.max(4, y) }} onPointerDown={(e) => e.stopPropagation()} onContextMenu={(e) => e.preventDefault()}>
      {m.items.map((it, i) => it.separator ? <hr key={i} /> : <button key={i} role="menuitem" disabled={it.disabled} className={it.danger ? "danger" : ""} onClick={() => { closeMenus(); it.action?.(); }}>{it.label}</button>)}
    </div>
  );
}

function Toasts() {
  const toasts = useStore(os, (s) => s.toasts);
  return <div style={{ position: "fixed", top: 12, right: 12, zIndex: 9700, display: "flex", flexDirection: "column", gap: 8 }} aria-live="polite">{toasts.map((t) => <div key={t.id} className="toast glass"><b>{t.title}</b><div className="small">{t.message}</div></div>)}</div>;
}
function Switcher() {
  const open = useStore(os, (s) => s.switcherOpen); const allWs = useStore(os, (s) => s.windows); const curD = useStore(os, (s) => s.current); const ws = allWs.filter((w) => w.desktop === curD); const active = useStore(os, (s) => s.activeId);
  if (!open) return null;
  return <div className="modal-bg" style={{ background: "transparent", pointerEvents: "none" }}><div className="glass row" style={{ padding: 14, borderRadius: 16, gap: 14 }}>{ws.map((w) => <div key={w.id} className="col" style={{ alignItems: "center", width: 90, padding: 6, borderRadius: 10, outline: w.id === active ? "2px solid var(--accent)" : "none" }}><AppIcon id={w.appId === "pkg" ? "pkg:" + w.params.pkgId : w.appId} size={44} /><span className="small" style={{ textAlign: "center" }}>{w.title}</span></div>)}</div></div>;
}

export default function Shell() {
  const windows = useStore(os, (s) => s.windows); const cur = useStore(os, (s) => s.current); const wall = useSetting("wallpaper"); const mobile = useIsMobile();
  const [wallUrl, setWallUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!wall.startsWith("fs:")) { setWallUrl(null); return; }
    let url: string | null = null; let on = true;
    fs.readBlob(wall.slice(3)).then((b) => { if (on) { url = URL.createObjectURL(b); setWallUrl(url); } }).catch(() => setWallUrl(null));
    return () => { on = false; if (url) URL.revokeObjectURL(url); };
  }, [wall]);

  useEffect(() => {
    const exit = () => { const w = os.get().windows.find((x) => x.id === os.get().activeId); return w; };
    const offs = [
      onShortcut("sys.fullscreen", () => { if (document.fullscreenElement) void document.exitFullscreen(); else void document.documentElement.requestFullscreen().catch(() => notify({ title: "Fullscreen unavailable", message: "Browser denied fullscreen." })); }),
      onShortcut("sys.start", () => toggleStart()), onShortcut("sys.search", () => { closeMenus(); os.set({ startOpen: true }); }),
      onShortcut("sys.explorer", () => void openApp("explorer")), onShortcut("sys.settings", () => void openApp("settings")), onShortcut("sys.console", () => void openApp("console")), onShortcut("sys.taskmgr", () => void openApp("taskmanager")),
      onShortcut("sys.newDesktop", () => addDesktop()), onShortcut("sys.prevDesktop", () => switchDesktop(os.get().current - 1)), onShortcut("sys.nextDesktop", () => switchDesktop(os.get().current + 1)),
      onShortcut("sys.lock", () => os.set({ locked: true, startOpen: false, quickOpen: false, notifOpen: false })),
      onShortcut("win.switch", () => { cycleWindows(1); os.set({ switcherOpen: true }); setTimeout(() => os.set({ switcherOpen: false }), 900); }),
      onShortcut("win.close", () => { const w = exit(); if (w) closeWin(w.id); }),
      onShortcut("win.new", () => { const w = exit(); if (w) openApp(w.appId, { ...w.params, new: Date.now() }); }),
      onShortcut("win.snapLeft", () => { const w = exit(); if (w) snapWin(w.id, "left"); }), onShortcut("win.snapRight", () => { const w = exit(); if (w) snapWin(w.id, "right"); }),
      onShortcut("win.maximize", () => { const w = exit(); if (w && w.state !== "maximized") toggleMaximize(w.id); }),
      onShortcut("win.restore", () => { const w = exit(); if (!w) return; if (w.state === "maximized" || w.snap) toggleMaximize(w.id, true); else minimizeWin(w.id); }),
    ];
    const onKey = (e: KeyboardEvent) => { const s = os.get(); if (s.locked) return; const a = s.windows.find((w) => w.id === s.activeId && w.state !== "minimized"); dispatchShortcut(e, a ? (a.appId === "pkg" ? "pkg:" + a.params.pkgId : a.appId) : null, a?.id ?? null); if (e.key === "Escape") closeMenus(); };
    window.addEventListener("keydown", onKey, true);
    return () => { window.removeEventListener("keydown", onKey, true); offs.forEach((o) => o()); };
  }, []);

  const deskMenu = (e: React.MouseEvent) => showMenu(e, [
    { label: "New folder", action: async () => { const n = await promptBox("New folder", "Folder name", "New folder"); if (n) await fs.mkdir(join("/Users/Default/Desktop", n)); } },
    { label: "New text file", action: async () => { const n = await promptBox("New text file", "File name", "Untitled.txt"); if (n) await fs.writeFile(join("/Users/Default/Desktop", n), ""); } },
    { label: "", separator: true }, { label: "Open Explorer", action: () => openApp("explorer") }, { label: "Themes & wallpaper", action: () => openApp("themes") }, { label: "Widgets", action: () => openApp("widgets") }, { label: "New virtual desktop", action: addDesktop }, { label: "Settings", action: () => openApp("settings") },
  ]);
  const bg = wallUrl ? { backgroundImage: `url(${wallUrl})` } : { backgroundImage: wallpaperCss(wall.startsWith("fs:") ? "aurora" : wall) };
  return (
    <div className="desktop" style={bg} onPointerDown={() => { closeMenus(); }} onContextMenu={deskMenu}>
      {cur >= 0 && <DesktopIcons />}
      <Widgets />
      {windows.map((w) => <WindowFrame key={w.id} w={w} mobile={mobile} />)}
      <Hotbar /><StartMenu /><QuickSettings /><NotificationCenter /><ContextMenuHost /><Toasts /><Switcher />
    </div>
  );
}
