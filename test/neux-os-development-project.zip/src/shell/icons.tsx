"use client";
import { svgDataUrl, installedStore } from "@/core/applications/wrapp";
import { useStore } from "@/core/store";

export const G: Record<string, string> = {
  explorer: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  browser: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
  store: "M4 8l1.5-4h13L20 8M4 8h16v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1zM9 12a3 3 0 0 0 6 0",
  settings: "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19 12l2-1-2-3-2 .5-1.5-1L15 5h-4l-.5 2.5-1.5 1L7 8l-2 3 2 1v2l-2 1 2 3 2-.5 1.5 1L11 21h4l.5-2.5 1.5-1 2 .5 2-3-2-1z",
  developer: "M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16",
  console: "M4 5h16v14H4zM7 10l3 2-3 2M12 15h5",
  media: "M9 18V6l11-2v12M9 18a3 3 0 1 1-3-3 3 3 0 0 1 3 3zM20 16a3 3 0 1 1-3-3 3 3 0 0 1 3 3z",
  calculator: "M6 3h12v18H6zM9 7h6M9 12h1M12 12h1M15 12h0M9 16h1M12 16h1M15 16h0",
  calendar: "M4 6h16v14H4zM4 10h16M8 3v4M16 3v4",
  notes: "M6 3h9l4 4v14H6zM15 3v4h4M9 12h7M9 16h7",
  gallery: "M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M15 9a1 1 0 1 0 0 .1",
  texteditor: "M5 4h14M5 9h14M5 14h9M5 19h6",
  screenshot: "M4 8V5h3M17 5h3v3M20 16v3h-3M7 19H4v-3M9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0",
  sysmonitor: "M3 12h4l2-6 4 12 2-6h6",
  archive: "M4 4h16v5H4zM5 9h14v11H5zM10 13h4",
  share: "M18 8a3 3 0 1 0-3-3M6 15a3 3 0 1 0 0-.1M18 21a3 3 0 1 0 0-.1M8.6 13.5l6.8 4M15.4 6.5l-6.8 4",
  backup: "M12 4v11M7 10l5 5 5-5M4 20h16",
  diagnostics: "M3 12h3l2-5 4 10 2-5h7M12 3v2M12 19v2",
  themes: "M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.5-2.5H17a4 4 0 0 0 4-4A9 9 0 0 0 12 3zM8 11h.1M12 7.5h.1M16 11h.1",
  widgets: "M4 4h7v7H4zM13 4h7v4h-7zM13 11h7v9h-7zM4 14h7v6H4z",
  appbuilder: "M12 3l9 5v8l-9 5-9-5V8zM12 12l9-4M12 12v9M12 12L3 8",
  taskmanager: "M4 5h16v14H4zM4 9h16M8 13h3M8 16h6",
  photo: "M4 7h3l2-3h6l2 3h3v13H4zM12 10a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
  secure: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4",
  recovery: "M4 12a8 8 0 1 0 3-6.2M4 4v4h4M12 8v4l3 2",
  pdf: "M6 3h9l4 4v14H6zM15 3v4h4M9 14h2a1.5 1.5 0 0 0 0-3H9v6M14 17v-6h1.5a2.5 3 0 0 1 0 6z",
  vpn: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM12 8v5M10 13h4",
  beeco: "M12 3l7 4v8l-7 4-7-4V7zM12 8l3.5 2v4L12 16l-3.5-2v-4z",
  installer: "M12 3v12M7 10l5 5 5-5M5 20h14M8 17v3M16 17v3",
  runtime: "M7 4l13 8-13 8zM3 4v16",
  picker: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  openwith: "M4 4h7v7H4zM13 13h7v7h-7zM13 4h7v7M4 13h7v7",
  wifi: "M2 9a15 15 0 0 1 20 0M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.1",
  nowifi: "M2 9a15 15 0 0 1 20 0M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.1M3 3l18 18",
  volume: "M4 9h4l5-4v14l-5-4H4zM16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11",
  mute: "M4 9h4l5-4v14l-5-4H4zM17 9l5 6M22 9l-5 6",
  bell: "M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21h4",
  start: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM16 16l5 5",
  folder: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  file: "M6 3h9l4 4v14H6zM15 3v4h4",
  lock: "M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3",
  plus: "M12 5v14M5 12h14",
  desktops: "M3 5h18v11H3zM8 20h8M12 16v4",
  sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5",
  moon: "M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z",
  star: "M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z",
  play: "M7 4l13 8-13 8z", pause: "M7 4h4v16H7zM13 4h4v16h-4z", next: "M5 4l11 8-11 8zM19 4v16", prev: "M19 4L8 12l11 8zM5 4v16",
  shuffle: "M3 7h4l10 10h4M3 17h4l3-3M14 10l3-3h4M18 4l3 3-3 3M18 14l3 3-3 3", repeat: "M4 11V9a3 3 0 0 1 3-3h13M17 3l3 3-3 3M20 13v2a3 3 0 0 1-3 3H4M7 21l-3-3 3-3",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13",
  download: "M12 4v11M7 10l5 5 5-5M5 20h14",
};
const TILE: Record<string, [string, string]> = {
  explorer: ["#ffb347", "#ff8c42"], browser: ["#4facfe", "#1b6ef3"], store: ["#43e97b", "#1fa890"], settings: ["#8d99ae", "#4a5568"], developer: ["#a18cd1", "#5b4bd4"],
  console: ["#2b2f3a", "#0e1118"], media: ["#fa709a", "#e03a7c"], calculator: ["#f7971e", "#d9591f"], calendar: ["#ff6b6b", "#d62e4a"], notes: ["#ffe259", "#e8a317"],
  gallery: ["#38f9d7", "#1b9aa6"], texteditor: ["#74ebd5", "#3a8fb7"], screenshot: ["#c471f5", "#7e3be0"], sysmonitor: ["#30cfd0", "#2a6fa8"], archive: ["#d4a373", "#8c5a32"],
  share: ["#5ee7df", "#3b8bd6"], backup: ["#7f7fd5", "#3f4fa3"], diagnostics: ["#52c234", "#1f8a4c"], themes: ["#ff9a9e", "#c25aa8"], widgets: ["#84fab0", "#3aa6a0"],
  appbuilder: ["#667eea", "#7a3fc9"], taskmanager: ["#6a85b6", "#3c4f78"], photo: ["#f093fb", "#d6407e"], secure: ["#11998e", "#0b5e6b"], recovery: ["#f5576c", "#a62d44"],
  pdf: ["#ff5f6d", "#c4202f"], vpn: ["#396afc", "#2a3fa8"], beeco: ["#f9d423", "#e07a1f"], installer: ["#43cea2", "#185a9d"], runtime: ["#5f72bd", "#2b3a7a"], picker: ["#ffb347", "#ff8c42"], openwith: ["#8d99ae", "#4a5568"],
};
export function Glyph({ name, size = 20, stroke = 1.8 }: { name: string; size?: number; stroke?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={G[name] ?? G.file} /></svg>;
}
export function AppIcon({ id, size = 40 }: { id: string; size?: number }) {
  const installed = useStore(installedStore, (s) => s.apps);
  if (id.startsWith("pkg:")) {
    const a = installed.find((x) => x.manifest.id === id.slice(4));
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={svgDataUrl(a?.iconSvg ?? "")} alt="" width={size} height={size} style={{ borderRadius: size * 0.24 }} draggable={false} />;
  }
  const [a, b] = TILE[id] ?? ["#667", "#445"];
  return (
    <span style={{ width: size, height: size, borderRadius: size * 0.26, background: `linear-gradient(145deg, ${a}, ${b})`, display: "grid", placeItems: "center", color: "#fff", boxShadow: "inset 0 1px 0 rgba(255,255,255,.35), 0 2px 6px rgba(0,0,0,.3)", flexShrink: 0 }}>
      <Glyph name={id} size={size * 0.55} />
    </span>
  );
}
export function NeuxLogo({ size = 64 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 512 512" aria-label="Neux OS">
      <defs><linearGradient id="nl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#7aa2ff" /><stop offset="1" stopColor="#8a5bff" /></linearGradient></defs>
      <rect width="512" height="512" rx="112" fill="#0b0e16" /><path d="M150 380V132l212 248V132" fill="none" stroke="url(#nl)" strokeWidth="40" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
