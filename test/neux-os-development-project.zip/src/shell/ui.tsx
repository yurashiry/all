"use client";
import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import { fs } from "@/core/kernel";
import type { FsNode } from "@/core/filesystem/neuxfs";
import { Glyph } from "./icons";
import { kindOf } from "@/core/util";
import { onShortcut } from "@/core/shortcuts";
import { os } from "@/core/os";

export interface WinCtx { id: string; params: Record<string, unknown>; rev: number; focused: boolean }
export const WinContext = createContext<WinCtx>({ id: "", params: {}, rev: 0, focused: false });
export const useWin = () => useContext(WinContext);

/** Register a keyboard shortcut handler that only fires while this window is focused. */
export function useShortcut(id: string, handler: () => unknown, deps: unknown[] = []) {
  const { id: winId } = useWin();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => onShortcut(id, () => (os.get().activeId === winId ? handler() !== false : false)), [id, winId, ...deps]);
}
export function useFs<T>(load: () => Promise<T>, deps: unknown[], initial: T): [T, () => void, boolean, string | null] {
  const [v, setV] = useState<T>(initial);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const reload = useCallback(() => setTick((t) => t + 1), []);
  useEffect(() => fs.subscribe(reload), [reload]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { let on = true; load().then((r) => { if (on) { setV(r); setErr(null); setLoading(false); } }).catch((e) => { if (on) { setErr((e as Error).message); setLoading(false); } }); return () => { on = false; }; }, [tick, ...deps]);
  return [v, reload, loading, err];
}
export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return <button role="switch" aria-checked={checked} aria-label={label} className="switch" disabled={disabled} onClick={() => onChange(!checked)} />;
}
export function Setting({ title, desc, children }: { title: string; desc?: ReactNode; children: ReactNode }) {
  return <div className="row" style={{ padding: "10px 0", borderBottom: "1px solid var(--surface-2)", alignItems: "center" }}><div className="grow"><div>{title}</div>{desc && <div className="dim small" style={{ marginTop: 2 }}>{desc}</div>}</div><div className="row">{children}</div></div>;
}
export function Ring({ percent, size = 56, label }: { percent: number | null; size?: number; label?: string }) {
  const r = (size - 8) / 2, c = 2 * Math.PI * r, p = percent === null ? 0 : Math.max(0, Math.min(100, percent));
  return (
    <span style={{ position: "relative", width: size, height: size, display: "inline-grid", placeItems: "center" }} role="progressbar" aria-valuenow={Math.round(p)} aria-valuemin={0} aria-valuemax={100}>
      <svg className="ring" width={size} height={size}><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth={5} /><circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--accent)" strokeWidth={5} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - p / 100)} /></svg>
      <span style={{ position: "absolute", fontSize: size / 4.4, fontVariantNumeric: "tabular-nums" }}>{label ?? (percent === null ? "…" : `${Math.round(p)}%`)}</span>
    </span>
  );
}
export function FileGlyph({ node, size = 20 }: { node: Pick<FsNode, "type" | "name">; size?: number }) {
  if (node.type === "dir") return <span style={{ color: "#ffb347" }}><Glyph name="folder" size={size} /></span>;
  const k = kindOf(node.name);
  const col: Record<string, string> = { audio: "#fa709a", video: "#c471f5", image: "#38f9d7", document: "#74b9ff", archive: "#d4a373", app: "#43e97b", code: "#a18cd1", other: "var(--text-dim)" };
  return <span style={{ color: col[k] }}><Glyph name={k === "audio" ? "media" : k === "image" ? "gallery" : k === "archive" ? "archive" : k === "app" ? "installer" : k === "code" ? "developer" : k === "video" ? "play" : "file"} size={size} /></span>;
}
export function Empty({ children }: { children: ReactNode }) { return <div className="dim" style={{ padding: 24, textAlign: "center" }}>{children}</div>; }
export function Tabs({ tabs, value, onChange }: { tabs: [string, string][]; value: string; onChange: (v: string) => void }) {
  return <div className="tabbar" role="tablist">{tabs.map(([id, l]) => <button key={id} role="tab" aria-selected={value === id} className={"tab" + (value === id ? " active" : "")} onClick={() => onChange(id)}>{l}</button>)}</div>;
}
export function useObjectUrl(blob: Blob | null | undefined): string | null {
  const [u, setU] = useState<string | null>(null);
  useEffect(() => { if (!blob) { setU(null); return; } const x = URL.createObjectURL(blob); setU(x); return () => URL.revokeObjectURL(x); }, [blob]);
  return u;
}
export function downloadBlob(blob: Blob, name: string) {
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
/** Pick files from the HOST device. Returns File objects; nothing is copied anywhere until the caller decides. */
export function pickHostFiles(accept = "", multiple = false): Promise<File[]> {
  return new Promise((resolve) => {
    const i = document.createElement("input"); i.type = "file"; i.accept = accept; i.multiple = multiple;
    i.onchange = () => resolve(Array.from(i.files ?? [])); i.oncancel = () => resolve([]); i.click();
  });
}
