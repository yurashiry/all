"use client";
import { useCallback, useEffect, useState } from "react";
import { fs } from "@/core/kernel";
import { loadSettings, settingsStore, getSetting } from "@/core/settings";
import { loadDownloadHistory } from "@/core/networking/downloads";
import { refreshInstalled } from "@/core/applications/wrapp";
import { loadCatalog } from "@/core/applications/store-service";
import { startNetworkMonitor } from "@/core/networking/status";
import { listUsers } from "@/core/users";
import { os } from "@/core/os";
import { installCommands } from "@/core/runtime/console";
import { installNeuxApi } from "@/core/api";
import { resumeInterruptedReset, wipeOwnedStorage } from "@/core/reset";
import { runIntegrityCheck } from "@/core/recovery";
import { applyExtensions } from "@/core/extensions";
import { useStore } from "@/core/store";
import Shell from "./Shell";
import { BootScreen, DialogHost, LockScreen, SetupWizard, setupStore } from "./Overlays";

type Step = { name: string; state: "wait" | "run" | "ok" | "fail" };
const NAMES = ["Resume interrupted reset (if any)", "Mount NeuxFS", "Load configuration", "Load local accounts", "Register applications", "Start services"];

export default function NeuxClient() {
  const [steps, setSteps] = useState<Step[]>(NAMES.map((name) => ({ name, state: "wait" })));
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [needSetup, setNeedSetup] = useState(false);
  const wizardOpen = useStore(setupStore, (s) => s.open);
  const locked = useStore(os, (s) => s.locked);

  const boot = useCallback(async () => {
    setError(null); setReady(false);
    setSteps(NAMES.map((name) => ({ name, state: "wait" })));
    const mark = (i: number, state: Step["state"]) => setSteps((p) => p.map((s, j) => (j === i ? { ...s, state } : s)));
    let i = 0;
    try {
      const run = async (f: () => Promise<unknown>) => { mark(i, "run"); await f(); mark(i, "ok"); i++; };
      await run(() => resumeInterruptedReset());
      await run(() => fs.init());
      await run(async () => { await loadSettings(); });
      let firstUser = null as Awaited<ReturnType<typeof listUsers>>[number] | null;
      await run(async () => { firstUser = (await listUsers())[0] ?? null; });
      await run(async () => { await refreshInstalled(); await loadDownloadHistory(); await applyExtensions().catch(() => {}); });
      await run(async () => { installCommands(); installNeuxApi(); startNetworkMonitor(); void loadCatalog(); });
      const u = firstUser as { name: string; role: "user" | "admin" | "root"; hash?: string; created: number } | null;
      os.set({ user: u ? { name: u.name, role: u.role, created: u.created } : null, booted: true, locked: !!u?.hash });
      setNeedSetup(!getSetting("setupDone"));
      setReady(true);
    } catch (e) { mark(i, "fail"); setError((e as Error).message || String(e)); }
  }, []);
  useEffect(() => { void boot(); }, [boot]);

  useEffect(() => {
    const apply = () => {
      const s = settingsStore.get(); const r = document.documentElement;
      const dark = typeof matchMedia !== "undefined" && matchMedia("(prefers-color-scheme: dark)").matches;
      r.dataset.theme = s.theme === "auto" ? (dark ? "dark" : "light") : s.theme;
      r.style.setProperty("--accent", s.accent); r.style.setProperty("--fs", String(s.fontScale));
      r.dataset.motion = s.reduceMotion ? "reduced" : "full"; r.dataset.contrast = s.highContrast ? "high" : "normal"; r.dataset.blur = s.blur ? "on" : "off";
      r.lang = s.language.split("-")[0];
    };
    apply(); const un = settingsStore.subscribe(apply);
    const mq = matchMedia("(prefers-color-scheme: dark)"); mq.addEventListener("change", apply);
    return () => { un(); mq.removeEventListener("change", apply); };
  }, []);
  useEffect(() => {
    if (process.env.NODE_ENV === "production" && "serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("./service-worker.js").catch(() => {});
  }, []);

  if (!ready) return <BootScreen steps={steps} done={steps.filter((s) => s.state === "ok").length} error={error}
    onRetry={boot} onRepair={async () => { try { await fs.init(); await runIntegrityCheck(true); await boot(); } catch (e) { setError("Repair failed: " + (e as Error).message); } }}
    onErase={async () => { if (confirm("Erase ALL Neux data (files, apps, accounts, settings)? Your device and files outside Neux are not affected. This cannot be undone.")) { await wipeOwnedStorage(); location.reload(); } }} />;
  return (
    <>
      <Shell />
      <DialogHost />
      {(needSetup || wizardOpen) && <SetupWizard onDone={() => { setNeedSetup(false); void listUsers().then((u) => u[0] && os.set({ user: { name: u[0].name, role: u[0].role, created: u[0].created } })); }} />}
      {locked && !needSetup && <LockScreen />}
    </>
  );
}
