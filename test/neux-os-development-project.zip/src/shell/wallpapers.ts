export const WALLPAPERS: { id: string; name: string; css: string; region?: string }[] = [
  { id: "aurora", name: "Aurora", css: "radial-gradient(60% 60% at 20% 20%, #3b6cff88, transparent), radial-gradient(50% 50% at 80% 30%, #b04bff77, transparent), radial-gradient(70% 70% at 60% 90%, #00d4aa55, transparent), linear-gradient(160deg,#0a1024,#161033)" },
  { id: "dusk", name: "Dusk", css: "radial-gradient(70% 60% at 70% 20%, #ff7a5c99, transparent), radial-gradient(60% 60% at 15% 80%, #6b3bff88, transparent), linear-gradient(180deg,#1b1740,#42223a)" },
  { id: "ocean", name: "Ocean", css: "radial-gradient(60% 50% at 30% 30%, #00b4ff88, transparent), radial-gradient(60% 60% at 80% 80%, #0066ff66, transparent), linear-gradient(170deg,#021a33,#04386b)" },
  { id: "forest", name: "Forest", css: "radial-gradient(60% 50% at 70% 30%, #4cd69477, transparent), radial-gradient(50% 60% at 20% 80%, #1f8a4c88, transparent), linear-gradient(170deg,#06201a,#0d3b2c)" },
  { id: "ember", name: "Ember", css: "radial-gradient(60% 50% at 20% 70%, #ff4d4d88, transparent), radial-gradient(60% 60% at 80% 20%, #ffb34777, transparent), linear-gradient(170deg,#220c0c,#4a1a12)" },
  { id: "mono", name: "Monochrome", css: "radial-gradient(60% 60% at 50% 30%, #ffffff22, transparent), linear-gradient(170deg,#111,#2a2a2e)" },
  { id: "paper", name: "Paper (light)", css: "radial-gradient(60% 60% at 30% 20%, #ffffffcc, transparent), radial-gradient(60% 60% at 80% 80%, #9bbcff88, transparent), linear-gradient(170deg,#dfe7f7,#c3d2ee)" },
  { id: "ua-sky", name: "Blue & Yellow (Ukraine collection)", css: "linear-gradient(180deg,#0057b7 0%,#1a6fd0 48%,#ffd700 52%,#f2c500 100%)", region: "Ukraine" },
];
export const wallpaperCss = (id: string) => (WALLPAPERS.find((w) => w.id === id) ?? WALLPAPERS[0]).css;
/** Regional holidays shown as optional wallpaper/greeting hints (fixed-date only; moveable holidays are not computed). */
export const HOLIDAYS: Record<string, { m: number; d: number; name: string }[]> = {
  Ukraine: [{ m: 1, d: 1, name: "New Year" }, { m: 6, d: 28, name: "Constitution Day" }, { m: 8, d: 24, name: "Independence Day" }, { m: 12, d: 25, name: "Christmas" }],
  "United States": [{ m: 1, d: 1, name: "New Year's Day" }, { m: 7, d: 4, name: "Independence Day" }, { m: 12, d: 25, name: "Christmas Day" }],
};
