export type TokType = "num" | "str" | "id" | "kw" | "op" | "nl" | "eof";
export interface Token { t: TokType; v: string; line: number; col: number }
export class NxlError extends Error {
  constructor(public phase: "lex" | "parse" | "type" | "compile" | "runtime", msg: string, public line = 0, public col = 0) { super(`[${phase}] line ${line}: ${msg}`); }
}
export const KEYWORDS = new Set(["let", "const", "fn", "if", "else", "while", "for", "in", "return", "true", "false", "null", "struct", "import", "try", "catch", "throw", "break", "continue", "and", "or", "not", "async", "await", "spawn"]);
const OPS = ["==", "!=", "<=", ">=", "->", "..", "+=", "-=", "*=", "/=", "+", "-", "*", "/", "%", "<", ">", "=", "(", ")", "{", "}", "[", "]", ",", ":", ".", ";", "!", "&&", "||"];

export function lex(src: string): Token[] {
  const out: Token[] = [];
  let i = 0, line = 1, col = 1;
  const adv = (n = 1) => { for (let k = 0; k < n; k++) { if (src[i] === "\n") { line++; col = 1; } else col++; i++; } };
  while (i < src.length) {
    const c = src[i];
    if (c === "\n") { out.push({ t: "nl", v: "\n", line, col }); adv(); continue; }
    if (c === " " || c === "\t" || c === "\r") { adv(); continue; }
    if (c === "/" && src[i + 1] === "/") { while (i < src.length && src[i] !== "\n") adv(); continue; }
    if (c === "#" && col === 1 && src[i + 1] === "!") { while (i < src.length && src[i] !== "\n") adv(); continue; }
    const L = line, C = col;
    if (/[0-9]/.test(c)) {
      let s = "";
      while (i < src.length && /[0-9_]/.test(src[i])) { s += src[i]; adv(); }
      if (src[i] === "." && /[0-9]/.test(src[i + 1] ?? "")) { s += "."; adv(); while (i < src.length && /[0-9_]/.test(src[i])) { s += src[i]; adv(); } }
      out.push({ t: "num", v: s.replace(/_/g, ""), line: L, col: C }); continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let s = "";
      while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) { s += src[i]; adv(); }
      out.push({ t: KEYWORDS.has(s) ? "kw" : "id", v: s, line: L, col: C }); continue;
    }
    if (c === '"') {
      let s = ""; adv();
      while (i < src.length && src[i] !== '"') {
        if (src[i] === "\n") throw new NxlError("lex", "Unterminated string", L, C);
        if (src[i] === "\\") { adv(); const e = src[i]; s += e === "n" ? "\n" : e === "t" ? "\t" : e === '"' ? '"' : e === "\\" ? "\\" : e === "{" ? "\\{" : (() => { throw new NxlError("lex", `Bad escape \\${e}`, line, col); })(); adv(); }
        else { s += src[i]; adv(); }
      }
      if (src[i] !== '"') throw new NxlError("lex", "Unterminated string", L, C);
      adv(); out.push({ t: "str", v: s, line: L, col: C }); continue;
    }
    const op = OPS.filter((o) => src.startsWith(o, i)).sort((a, b) => b.length - a.length)[0];
    if (!op) throw new NxlError("lex", `Unexpected character '${c}'`, L, C);
    adv(op.length); out.push({ t: "op", v: op, line: L, col: C });
  }
  out.push({ t: "eof", v: "", line, col });
  return out;
}
