import { lex, NxlError, type Token } from "./lexer";

export type TypeName = string; // int float str bool null any [T] fn
export type Expr =
  | { k: "num"; v: number; float: boolean; line: number } | { k: "str"; parts: (string | Expr)[]; line: number } | { k: "bool"; v: boolean; line: number } | { k: "null"; line: number }
  | { k: "id"; name: string; line: number } | { k: "arr"; items: Expr[]; line: number } | { k: "obj"; fields: [string, Expr][]; line: number }
  | { k: "un"; op: string; e: Expr; line: number } | { k: "bin"; op: string; l: Expr; r: Expr; line: number }
  | { k: "call"; f: Expr; args: Expr[]; line: number } | { k: "idx"; o: Expr; i: Expr; line: number } | { k: "mem"; o: Expr; name: string; line: number }
  | { k: "assign"; target: Expr; op: string; v: Expr; line: number } | { k: "fn"; params: Param[]; ret?: TypeName; body: Stmt[]; name?: string; line: number }
  | { k: "range"; a: Expr; b: Expr; line: number } | { k: "await"; e: Expr; line: number };
export interface Param { name: string; type?: TypeName }
export type Stmt =
  | { k: "let"; name: string; type?: TypeName; init: Expr; mut: boolean; line: number } | { k: "expr"; e: Expr; line: number }
  | { k: "if"; c: Expr; then: Stmt[]; else_?: Stmt[]; line: number } | { k: "while"; c: Expr; body: Stmt[]; line: number }
  | { k: "for"; v: string; iter: Expr; body: Stmt[]; line: number } | { k: "return"; e?: Expr; line: number }
  | { k: "fn"; name: string; params: Param[]; ret?: TypeName; body: Stmt[]; async: boolean; line: number } | { k: "struct"; name: string; fields: Param[]; line: number }
  | { k: "try"; body: Stmt[]; v: string; handler: Stmt[]; line: number } | { k: "throw"; e: Expr; line: number }
  | { k: "break"; line: number } | { k: "continue"; line: number } | { k: "import"; mod: string; line: number };

export function parse(src: string): Stmt[] {
  const toks = lex(src);
  let p = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => peek().t === "op" && peek().v === v;
  const isKw = (v: string) => peek().t === "kw" && peek().v === v;
  const err = (m: string, t: Token = peek()): never => { throw new NxlError("parse", m, t.line, t.col); };
  const nls = () => { while (peek().t === "nl" || isOp(";")) p++; };
  const expectOp = (v: string) => { if (!isOp(v)) err(`Expected '${v}' but found '${peek().v || peek().t}'`); return toks[p++]; };
  const ident = () => { if (peek().t !== "id") err(`Expected identifier but found '${peek().v || peek().t}'`); return toks[p++].v; };
  const typeName = (): string => {
    if (isOp("[")) { p++; const t = typeName(); expectOp("]"); return `[${t}]`; }
    return peek().t === "id" || peek().t === "kw" ? toks[p++].v : err("Expected type");
  };
  const block = (): Stmt[] => {
    expectOp("{"); const out: Stmt[] = []; nls();
    while (!isOp("}")) { if (peek().t === "eof") err("Unterminated block"); out.push(stmt()); nls(); }
    p++; return out;
  };
  const params = (): Param[] => {
    expectOp("("); const ps: Param[] = [];
    while (!isOp(")")) { const name = ident(); let type: string | undefined; if (isOp(":")) { p++; type = typeName(); } ps.push({ name, type }); if (!isOp(")")) expectOp(","); }
    p++; return ps;
  };
  function stmt(): Stmt {
    const t = peek(), line = t.line;
    if (t.t === "kw") {
      switch (t.v) {
        case "import": { p++; let m = ident(); while (isOp(".")) { p++; m += "." + ident(); } return { k: "import", mod: m, line }; }
        case "let": case "const": {
          p++; const name = ident(); let type: string | undefined; if (isOp(":")) { p++; type = typeName(); }
          expectOp("="); return { k: "let", name, type, init: expr(), mut: t.v === "let", line };
        }
        case "async": case "fn": {
          const isAsync = t.v === "async"; if (isAsync) p++;
          if (!isKw("fn")) err("Expected 'fn' after async");
          if (toks[p + 1].t === "id") {
            p++; const name = ident(); const ps = params(); let ret: string | undefined; if (isOp("->")) { p++; ret = typeName(); }
            return { k: "fn", name, params: ps, ret, body: block(), async: isAsync, line };
          }
          break;
        }
        case "struct": { p++; const name = ident(); expectOp("{"); nls(); const fields: Param[] = [];
          while (!isOp("}")) { const n = ident(); expectOp(":"); fields.push({ name: n, type: typeName() }); if (isOp(",")) p++; nls(); }
          p++; return { k: "struct", name, fields, line }; }
        case "if": { p++; const c = expr(); const then = block(); let else_: Stmt[] | undefined;
          nls(); if (isKw("else")) { p++; else_ = isKw("if") ? [stmt()] : block(); } else { /* nothing */ } return { k: "if", c, then, else_, line }; }
        case "while": { p++; const c = expr(); return { k: "while", c, body: block(), line }; }
        case "for": { p++; const v = ident(); if (!isKw("in")) err("Expected 'in'"); p++; const iter = expr(); return { k: "for", v, iter, body: block(), line }; }
        case "return": { p++; if (peek().t === "nl" || isOp("}") || peek().t === "eof") return { k: "return", line }; return { k: "return", e: expr(), line }; }
        case "break": p++; return { k: "break", line };
        case "continue": p++; return { k: "continue", line };
        case "throw": p++; return { k: "throw", e: expr(), line };
        case "try": { p++; const body = block(); nls(); if (!isKw("catch")) err("Expected 'catch'"); p++; const v = ident(); return { k: "try", body, v, handler: block(), line }; }
      }
    }
    return { k: "expr", e: expr(), line };
  }
  const BIN: string[][] = [["or", "||"], ["and", "&&"], ["==", "!="], ["<", ">", "<=", ">="], [".."], ["+", "-"], ["*", "/", "%"]];
  function expr(): Expr { return assign(); }
  function assign(): Expr {
    const l = binary(0);
    if (peek().t === "op" && ["=", "+=", "-=", "*=", "/="].includes(peek().v)) {
      const t = toks[p++];
      if (!["id", "idx", "mem"].includes(l.k)) err("Invalid assignment target", t);
      return { k: "assign", target: l, op: t.v, v: assign(), line: t.line };
    }
    return l;
  }
  function binary(lv: number): Expr {
    if (lv >= BIN.length) return unary();
    let l = binary(lv + 1);
    for (;;) {
      const t = peek();
      if ((t.t === "op" || t.t === "kw") && BIN[lv].includes(t.v)) {
        p++; const r = binary(lv + 1);
        const op = t.v === "and" ? "&&" : t.v === "or" ? "||" : t.v;
        l = op === ".." ? { k: "range", a: l, b: r, line: t.line } : { k: "bin", op, l, r, line: t.line };
      } else return l;
    }
  }
  function unary(): Expr {
    const t = peek();
    if ((t.t === "op" && (t.v === "-" || t.v === "!")) || (t.t === "kw" && t.v === "not")) { p++; return { k: "un", op: t.v === "not" ? "!" : t.v, e: unary(), line: t.line }; }
    if (t.t === "kw" && t.v === "await") { p++; return { k: "await", e: unary(), line: t.line }; }
    return postfix();
  }
  function postfix(): Expr {
    let e = primary();
    for (;;) {
      const t = peek();
      if (isOp("(")) { p++; const args: Expr[] = []; nls(); while (!isOp(")")) { args.push(expr()); nls(); if (!isOp(")")) { expectOp(","); nls(); } } p++; e = { k: "call", f: e, args, line: t.line }; }
      else if (isOp("[")) { p++; const i = expr(); expectOp("]"); e = { k: "idx", o: e, i, line: t.line }; }
      else if (isOp(".")) { p++; e = { k: "mem", o: e, name: ident(), line: t.line }; }
      else return e;
    }
  }
  function interp(s: string, line: number): (string | Expr)[] {
    const parts: (string | Expr)[] = []; let cur = "";
    for (let i = 0; i < s.length; i++) {
      if (s[i] === "\\" && s[i + 1] === "{") { cur += "{"; i++; }
      else if (s[i] === "{") {
        let d = 1, j = i + 1;
        while (j < s.length && d) { if (s[j] === "{") d++; else if (s[j] === "}") d--; j++; }
        if (d) throw new NxlError("parse", "Unterminated interpolation", line);
        if (cur) parts.push(cur); cur = "";
        const sub = parse(s.slice(i + 1, j - 1));
        if (sub.length !== 1 || sub[0].k !== "expr") throw new NxlError("parse", "Interpolation must be one expression", line);
        parts.push(sub[0].e); i = j - 1;
      } else cur += s[i];
    }
    if (cur || !parts.length) parts.push(cur);
    return parts;
  }
  function primary(): Expr {
    const t = toks[p], line = t.line;
    if (t.t === "num") { p++; return { k: "num", v: Number(t.v), float: t.v.includes("."), line }; }
    if (t.t === "str") { p++; return { k: "str", parts: interp(t.v, line), line }; }
    if (t.t === "id") { p++; return { k: "id", name: t.v, line }; }
    if (t.t === "kw") {
      if (t.v === "true" || t.v === "false") { p++; return { k: "bool", v: t.v === "true", line }; }
      if (t.v === "null") { p++; return { k: "null", line }; }
      if (t.v === "fn") { p++; const ps = params(); let ret: string | undefined; if (isOp("->")) { p++; ret = typeName(); } return { k: "fn", params: ps, ret, body: block(), line }; }
    }
    if (isOp("(")) { p++; const e = expr(); expectOp(")"); return e; }
    if (isOp("[")) { p++; const items: Expr[] = []; nls(); while (!isOp("]")) { items.push(expr()); nls(); if (!isOp("]")) { expectOp(","); nls(); } } p++; return { k: "arr", items, line }; }
    if (isOp("{")) { p++; const fields: [string, Expr][] = []; nls(); while (!isOp("}")) { const n = peek().t === "str" ? toks[p++].v : ident(); expectOp(":"); fields.push([n, expr()]); nls(); if (!isOp("}")) { expectOp(","); nls(); } } p++; return { k: "obj", fields, line }; }
    return err(`Unexpected '${t.v || t.t}'`, t);
  }
  const prog: Stmt[] = []; nls();
  while (peek().t !== "eof") { prog.push(stmt()); if (peek().t !== "eof" && peek().t !== "nl" && !isOp(";") && !isOp("}")) err(`Unexpected '${peek().v}' after statement`); nls(); }
  return prog;
}
