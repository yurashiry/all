import { NxlError } from "./lexer";
import type { Expr, Stmt, Param } from "./parser";

interface Sig { params: (string | undefined)[]; ret: string }
interface Sym { type: string; mut: boolean; sig?: Sig; struct?: Param[] }
class Scope { vars = new Map<string, Sym>(); constructor(public parent?: Scope) {} find(n: string): Sym | undefined { return this.vars.get(n) ?? this.parent?.find(n); } }
export const MODULES: Record<string, string[]> = { "Neux.Std": [], "Neux.Fs": ["fs"], "Neux.Net": ["net"] };
export const BUILTIN_NAMES = ["print", "println", "len", "str", "int", "float", "push", "pop", "keys", "range", "typeof", "abs", "floor", "ceil", "round", "sqrt", "min", "max", "upper", "lower", "split", "join", "contains", "slice", "now", "sleep", "console", "Math", "trim", "replace", "startsWith", "pow", "sort", "random", "parseInt"];
const numeric = (t: string) => t === "int" || t === "float";
const ok = (want: string | undefined, got: string): boolean =>
  !want || want === "any" || got === "any" || want === got || (want === "float" && got === "int") || (want.startsWith("[") && got === "[any]") || (got.startsWith("[") && want === "[any]");

export function check(prog: Stmt[]): void {
  const root = new Scope();
  for (const b of BUILTIN_NAMES) root.vars.set(b, { type: "any", mut: false });
  let retStack: (string | undefined)[] = [];
  const E = (m: string, line: number): never => { throw new NxlError("type", m, line); };
  // hoist function and struct declarations so they can be used before definition
  const hoist = (stmts: Stmt[], sc: Scope) => {
    for (const s of stmts) {
      if (s.k === "fn") sc.vars.set(s.name, { type: "fn", mut: false, sig: { params: s.params.map((p) => p.type), ret: s.ret ?? "any" } });
      if (s.k === "struct") sc.vars.set(s.name, { type: "struct", mut: false, struct: s.fields, sig: { params: s.fields.map((f) => f.type), ret: s.name } });
    }
  };
  const ex = (e: Expr, sc: Scope): string => {
    const t = ex_(e, sc);
    (e as Expr & { t?: string }).t = t;
    return t;
  };
  const ex_ = (e: Expr, sc: Scope): string => {
    switch (e.k) {
      case "num": return e.float ? "float" : "int";
      case "str": e.parts.forEach((p) => typeof p !== "string" && ex(p, sc)); return "str";
      case "bool": return "bool";
      case "null": return "null";
      case "id": { const s = sc.find(e.name); if (!s) E(`Undefined name '${e.name}'`, e.line); return s!.type; }
      case "arr": { const ts = e.items.map((i) => ex(i, sc)); const u = [...new Set(ts)]; return u.length === 1 ? `[${u[0]}]` : "[any]"; }
      case "obj": e.fields.forEach(([, v]) => ex(v, sc)); return "obj";
      case "range": { const a = ex(e.a, sc), b = ex(e.b, sc); if (!ok("int", a) || !ok("int", b)) E("Range bounds must be int", e.line); return "[int]"; }
      case "await": ex(e.e, sc); return "any";
      case "un": { const t = ex(e.e, sc); if (e.op === "-") { if (t !== "any" && !numeric(t)) E(`Cannot negate ${t}`, e.line); return t; } if (t !== "any" && t !== "bool") E(`'not' needs bool, got ${t}`, e.line); return "bool"; }
      case "bin": {
        const l = ex(e.l, sc), r = ex(e.r, sc), any = l === "any" || r === "any";
        if (["&&", "||"].includes(e.op)) { if (!any && (l !== "bool" || r !== "bool")) E(`'${e.op === "&&" ? "and" : "or"}' needs bool operands, got ${l}, ${r}`, e.line); return "bool"; }
        if (["==", "!="].includes(e.op)) return "bool";
        if (["<", ">", "<=", ">="].includes(e.op)) { if (!any && !(numeric(l) && numeric(r)) && !(l === "str" && r === "str")) E(`Cannot compare ${l} with ${r}`, e.line); return "bool"; }
        if (e.op === "+" && (l === "str" || r === "str")) { if (!any && (l !== "str" || r !== "str")) E("Cannot add str and " + (l === "str" ? r : l) + " — use str(x) or interpolation", e.line); return "str"; }
        if (any) return "any";
        if (!numeric(l) || !numeric(r)) E(`Operator '${e.op}' not defined for ${l} and ${r}`, e.line);
        return l === "float" || r === "float" ? "float" : "int";
      }
      case "assign": {
        const vt = ex(e.v, sc);
        if (e.target.k === "id") {
          const s = sc.find(e.target.name);
          if (!s) E(`Undefined name '${e.target.name}'`, e.line);
          if (!s!.mut) E(`Cannot assign to const '${e.target.name}'`, e.line);
          if (!ok(s!.type, vt)) E(`Cannot assign ${vt} to ${s!.type} '${e.target.name}'`, e.line);
          if (e.op !== "=" && !numeric(s!.type) && !(s!.type === "str" && e.op === "+=") && s!.type !== "any") E(`Operator ${e.op} not defined for ${s!.type}`, e.line);
        } else ex(e.target, sc);
        return vt;
      }
      case "idx": { const o = ex(e.o, sc), i = ex(e.i, sc); if (o.startsWith("[")) { if (!ok("int", i)) E("Array index must be int", e.line); return o.slice(1, -1); } if (o === "str") return "str"; return "any"; }
      case "mem": { const o = ex(e.o, sc); if (e.name === "length") return "int"; void o; return "any"; }
      case "call": {
        const argT = e.args.map((a) => ex(a, sc));
        if (e.f.k === "id") {
          const s = sc.find(e.f.name);
          if (!s) E(`Undefined name '${e.f.name}'`, e.line);
          if (s!.sig) {
            if (s!.sig.params.length !== argT.length) E(`'${e.f.name}' expects ${s!.sig.params.length} argument(s), got ${argT.length}`, e.line);
            s!.sig.params.forEach((p, i) => { if (!ok(p, argT[i])) E(`Argument ${i + 1} of '${e.f.k === "id" ? e.f.name : ""}': expected ${p}, got ${argT[i]}`, e.line); });
            return s!.sig.ret;
          }
          if (["len", "int", "parseInt"].includes(e.f.name)) return "int";
          if (["str", "upper", "lower", "join", "trim", "replace", "typeof"].includes(e.f.name)) return "str";
          if (["float", "sqrt", "random"].includes(e.f.name)) return "float";
          return "any";
        }
        ex(e.f, sc); return "any";
      }
      case "fn": return fnBody(e.params, e.ret, e.body, sc, e.line);
    }
  };
  const fnBody = (params: Param[], ret: string | undefined, body: Stmt[], sc: Scope, line: number): string => {
    const inner = new Scope(sc);
    params.forEach((p) => inner.vars.set(p.name, { type: p.type ?? "any", mut: true }));
    retStack.push(ret);
    block(body, inner);
    retStack.pop();
    void line;
    return "fn";
  };
  const block = (stmts: Stmt[], sc: Scope) => { hoist(stmts, sc); stmts.forEach((s) => st(s, sc)); };
  const st = (s: Stmt, sc: Scope) => {
    switch (s.k) {
      case "let": {
        const t = ex(s.init, sc);
        if (s.type && !ok(s.type, t)) E(`Cannot initialize ${s.type} '${s.name}' with ${t}`, s.line);
        if (sc.vars.has(s.name) && !sc.vars.get(s.name)!.sig) E(`'${s.name}' is already declared in this scope`, s.line);
        sc.vars.set(s.name, { type: s.type ?? (t === "null" ? "any" : t), mut: s.mut }); break;
      }
      case "expr": ex(s.e, sc); break;
      case "if": { const c = ex(s.c, sc); if (c !== "bool" && c !== "any") E(`Condition must be bool, got ${c}`, s.line); block(s.then, new Scope(sc)); if (s.else_) block(s.else_, new Scope(sc)); break; }
      case "while": { const c = ex(s.c, sc); if (c !== "bool" && c !== "any") E(`Condition must be bool, got ${c}`, s.line); block(s.body, new Scope(sc)); break; }
      case "for": { const it = ex(s.iter, sc); if (it !== "any" && it !== "str" && !it.startsWith("[")) E(`Cannot iterate over ${it}`, s.line); const inner = new Scope(sc); inner.vars.set(s.v, { type: it.startsWith("[") ? it.slice(1, -1) : "any", mut: false }); block(s.body, inner); break; }
      case "return": { const want = retStack[retStack.length - 1]; if (!retStack.length) E("'return' outside function", s.line); const t = s.e ? ex(s.e, sc) : "null"; if (want && want !== "null" && !ok(want, t)) E(`Function returns ${want} but this returns ${t}`, s.line); break; }
      case "fn": fnBody(s.params, s.ret, s.body, sc, s.line); break;
      case "struct": break;
      case "try": block(s.body, new Scope(sc)); { const i = new Scope(sc); i.vars.set(s.v, { type: "any", mut: false }); block(s.handler, i); } break;
      case "throw": ex(s.e, sc); break;
      case "import": if (!(s.mod in MODULES)) E(`Module '${s.mod}' is not available (known: ${Object.keys(MODULES).join(", ")})`, s.line);
        for (const n of MODULES[s.mod]) sc.vars.set(n, { type: "any", mut: false }); break;
      case "break": case "continue": break;
    }
  };
  hoist(prog, root);
  retStack = [];
  prog.forEach((s) => st(s, root));
}
