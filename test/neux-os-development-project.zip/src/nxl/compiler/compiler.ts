import { NxlError } from "./lexer";
import type { Expr, Stmt } from "./parser";

export type Op = string;
export interface Instr { op: Op; a?: number | string; b?: number | string; line: number }
export interface FnProto { name: string; params: string[]; code: Instr[]; async: boolean }
export interface Bytecode { magic: "NXB1"; consts: (number | string)[]; funcs: FnProto[]; main: number; modules: string[] }

export function compile(prog: Stmt[]): Bytecode {
  const consts: (number | string)[] = [];
  const funcs: FnProto[] = [];
  const modules: string[] = [];
  const cidx = (v: number | string) => { const i = consts.findIndex((c) => c === v && typeof c === typeof v); if (i >= 0) return i; consts.push(v); return consts.length - 1; };

  function fn(name: string, params: string[], body: Stmt[], isAsync: boolean, top = false): number {
    const code: Instr[] = [];
    let depth = 0;
    const loops: { depth: number; brk: number[]; cont: number[]; iter: boolean }[] = [];
    const emit = (op: Op, line: number, a?: number | string, b?: number | string) => { code.push({ op, a, b, line }); return code.length - 1; };
    const here = () => code.length;
    const patch = (at: number, to = here()) => { code[at].a = to; };
    const blockS = (stmts: Stmt[], line: number, scope = true) => {
      if (scope) { emit("PUSHSCOPE", line); depth++; }
      hoistFns(stmts);
      stmts.forEach(stmt);
      if (scope) { emit("POPSCOPE", line); depth--; }
    };
    const hoistFns = (stmts: Stmt[]) => {
      for (const s of stmts) if (s.k === "fn") { const idx = fn(s.name, s.params.map((p) => p.name), s.body, s.async); emit("CLOSURE", s.line, idx); emit("DECL", s.line, s.name, 0); }
      for (const s of stmts) if (s.k === "struct") { emit("STRUCT", s.line, s.name, s.fields.map((f) => f.name).join(",")); }
    };
    function expr(e: Expr): void {
      switch (e.k) {
        case "num": emit("CONST", e.line, cidx(e.v)); break;
        case "str": if (e.parts.length === 1 && typeof e.parts[0] === "string") emit("CONST", e.line, cidx(e.parts[0])); else { e.parts.forEach((p) => (typeof p === "string" ? emit("CONST", e.line, cidx(p)) : expr(p))); emit("CONCAT", e.line, e.parts.length); } break;
        case "bool": emit(e.v ? "TRUE" : "FALSE", e.line); break;
        case "null": emit("NULL", e.line); break;
        case "id": emit("LOAD", e.line, e.name); break;
        case "arr": e.items.forEach(expr); emit("MKARR", e.line, e.items.length); break;
        case "obj": e.fields.forEach(([k, v]) => { emit("CONST", e.line, cidx(k)); expr(v); }); emit("MKOBJ", e.line, e.fields.length); break;
        case "range": expr(e.a); expr(e.b); emit("RANGE", e.line); break;
        case "await": expr(e.e); emit("AWAIT", e.line); break;
        case "un": expr(e.e); emit(e.op === "-" ? "NEG" : "NOT", e.line); break;
        case "bin": {
          if (e.op === "&&" || e.op === "||") { expr(e.l); const j = emit(e.op === "&&" ? "JF" : "JT", e.line, 0); emit("POP", e.line); expr(e.r); patch(j); break; }
          expr(e.l); expr(e.r);
          const t = (x: Expr) => (x as Expr & { t?: string }).t;
          const m: Record<string, string> = { "+": "ADD", "-": "SUB", "*": "MUL", "/": t(e.l) === "int" && t(e.r) === "int" ? "IDIV" : "DIV", "%": "MOD", "==": "EQ", "!=": "NE", "<": "LT", ">": "GT", "<=": "LE", ">=": "GE" };
          emit(m[e.op], e.line); break;
        }
        case "assign": {
          const compound = e.op !== "=" ? ({ "+=": "ADD", "-=": "SUB", "*=": "MUL", "/=": "DIV" } as Record<string, string>)[e.op] : null;
          const T = e.target;
          if (T.k === "id") { if (compound) { emit("LOAD", e.line, T.name); expr(e.v); emit(compound, e.line); } else expr(e.v); emit("DUP", e.line); emit("STORE", e.line, T.name); }
          else if (T.k === "idx") { expr(T.o); expr(T.i); if (compound) { expr(T.o); expr(T.i); emit("IDX", e.line); expr(e.v); emit(compound, e.line); } else expr(e.v); emit("SETIDX", e.line); }
          else if (T.k === "mem") { expr(T.o); if (compound) { expr(T.o); emit("MEM", e.line, T.name); expr(e.v); emit(compound, e.line); } else expr(e.v); emit("SETMEM", e.line, T.name); }
          break;
        }
        case "idx": expr(e.o); expr(e.i); emit("IDX", e.line); break;
        case "mem": expr(e.o); emit("MEM", e.line, e.name); break;
        case "call": expr(e.f); e.args.forEach(expr); emit("CALL", e.line, e.args.length); break;
        case "fn": { const idx = fn(e.name ?? "<fn>", e.params.map((p) => p.name), e.body, false); emit("CLOSURE", e.line, idx); break; }
      }
    }
    function stmt(s: Stmt): void {
      switch (s.k) {
        case "fn": case "struct": break; // hoisted
        case "import": modules.push(s.mod); emit("IMPORT", s.line, s.mod); break;
        case "let": expr(s.init); emit("DECL", s.line, s.name, s.mut ? 1 : 0); break;
        case "expr": expr(s.e); emit("POP", s.line); break;
        case "if": { expr(s.c); const jf = emit("JF", s.line, 0); emit("POP", s.line); blockS(s.then, s.line); const jend = emit("JMP", s.line, 0); patch(jf); emit("POP", s.line); if (s.else_) blockS(s.else_, s.line); patch(jend); break; }
        case "while": {
          const top = here(); const L = { depth, brk: [] as number[], cont: [] as number[], iter: false }; loops.push(L);
          expr(s.c); const jf = emit("JF", s.line, 0); emit("POP", s.line); blockS(s.body, s.line); emit("JMP", s.line, top);
          patch(jf); emit("POP", s.line); L.brk.forEach((b) => patch(b)); L.cont.forEach((c) => patch(c, top)); loops.pop(); break;
        }
        case "for": {
          expr(s.iter); emit("ITERINIT", s.line);
          const top = here(); const L = { depth, brk: [] as number[], cont: [] as number[], iter: true }; loops.push(L);
          const nx = emit("ITERNEXT", s.line, 0);
          emit("PUSHSCOPE", s.line); depth++; emit("DECL", s.line, s.v, 0); blockS(s.body, s.line); emit("POPSCOPE", s.line); depth--; emit("JMP", s.line, top);
          const brk = here(); emit("POP", s.line); L.brk.forEach((b) => patch(b, brk)); patch(nx); L.cont.forEach((c) => patch(c, top)); loops.pop(); break;
        }
        case "return": if (top) throw new NxlError("compile", "'return' outside function", s.line); if (s.e) expr(s.e); else emit("NULL", s.line); emit("RET", s.line); break;
        case "break": case "continue": {
          const L = loops[loops.length - 1]; if (!L) throw new NxlError("compile", `'${s.k}' outside loop`, s.line);
          for (let i = depth; i > L.depth; i--) emit("POPSCOPE", s.line);
          (s.k === "break" ? L.brk : L.cont).push(emit("JMP", s.line, 0)); break;
        }
        case "throw": expr(s.e); emit("THROW", s.line); break;
        case "try": {
          const t = emit("TRY", s.line, 0); blockS(s.body, s.line); emit("ENDTRY", s.line); const j = emit("JMP", s.line, 0);
          patch(t); emit("PUSHSCOPE", s.line); depth++; emit("DECL", s.line, s.v, 0); blockS(s.handler, s.line); emit("POPSCOPE", s.line); depth--; patch(j); break;
        }
      }
    }
    blockS(body, 0, false);
    emit("NULL", 0); emit("RET", 0);
    funcs.push({ name, params, code, async: isAsync });
    return funcs.length - 1;
  }
  const main = fn("<main>", [], prog, false, true);
  return { magic: "NXB1", consts, funcs, main, modules };
}
