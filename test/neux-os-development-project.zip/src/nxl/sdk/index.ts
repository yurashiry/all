import { fs } from "@/core/kernel";
import { join, norm } from "@/core/filesystem/neuxfs";
import type { Host } from "../standard-library";

/** NXL SDK host binding for Neux: sandboxed to NeuxFS (cwd-relative), no host access. */
export function neuxHost(print: (s: string) => void, cwd = "/Users/Default"): Host {
  const p = (x: string) => (x.startsWith("/") ? norm(x) : join(cwd, x));
  return {
    print,
    fs: { read: (x) => fs.readText(p(x)), write: async (x, d) => void (await fs.writeFile(p(x), d)), list: async (x) => (await fs.list(p(x))).map((n) => n.name) },
    fetchText: async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); },
  };
}
