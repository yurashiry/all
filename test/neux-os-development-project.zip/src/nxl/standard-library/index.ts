export interface Host {
  print(s: string): void;
  fs?: { read(path: string): Promise<string>; write(path: string, data: string): Promise<void>; list(path: string): Promise<string[]> };
  fetchText?: (url: string) => Promise<string>;
}
export const show = (v: unknown, top = true): string => {
  if (v === null || v === undefined) return "null";
  if (typeof v === "string") return top ? v : JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map((x) => show(x, false)).join(", ") + "]";
  if (typeof v === "function" || (typeof v === "object" && "proto" in (v as object) && "env" in (v as object))) return "<fn>";
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    const sn = o.__struct as string | undefined;
    const body = Object.entries(o).filter(([k]) => k !== "__struct").map(([k, x]) => `${k}: ${show(x, false)}`).join(", ");
    return sn ? `${sn}(${body})` : `{${body}}`;
  }
  return String(v);
};
export function stdGlobals(host: Host): Record<string, unknown> {
  const num = (v: unknown, n = "value") => { if (typeof v !== "number") throw new Error(`${n} must be a number`); return v; };
  const arr = (v: unknown) => { if (!Array.isArray(v)) throw new Error("expected an array"); return v; };
  const g: Record<string, unknown> = {
    print: (...a: unknown[]) => { host.print(a.map((x) => show(x)).join(" ")); return null; },
    println: (...a: unknown[]) => { host.print(a.map((x) => show(x)).join(" ")); return null; },
    len: (v: unknown) => (typeof v === "string" || Array.isArray(v) ? v.length : v && typeof v === "object" ? Object.keys(v).length : (() => { throw new Error("len() needs str, array or object"); })()),
    str: (v: unknown) => show(v),
    int: (v: unknown) => { const n = typeof v === "string" ? Number(v) : num(v); if (!isFinite(n)) throw new Error(`Cannot convert ${show(v)} to int`); return Math.trunc(n); },
    parseInt: (v: unknown) => { const n = parseInt(String(v), 10); return isNaN(n) ? null : n; },
    float: (v: unknown) => { const n = typeof v === "string" ? Number(v) : num(v); if (isNaN(n)) throw new Error(`Cannot convert ${show(v)} to float`); return n; },
    push: (a: unknown, v: unknown) => { arr(a).push(v); return a; },
    pop: (a: unknown) => arr(a).pop() ?? null,
    keys: (o: unknown) => Object.keys(o as object).filter((k) => k !== "__struct"),
    range: (a: unknown, b?: unknown) => { const [s, e] = b === undefined ? [0, num(a)] : [num(a), num(b)]; const out: number[] = []; for (let i = s; i < e; i++) out.push(i); return out; },
    typeof: (v: unknown) => (v === null ? "null" : Array.isArray(v) ? "array" : typeof v === "number" ? (Number.isInteger(v) ? "int" : "float") : typeof v === "object" ? ((v as { __struct?: string }).__struct ?? "object") : typeof v === "boolean" ? "bool" : typeof v === "string" ? "str" : "fn"),
    abs: (v: unknown) => Math.abs(num(v)), floor: (v: unknown) => Math.floor(num(v)), ceil: (v: unknown) => Math.ceil(num(v)), round: (v: unknown) => Math.round(num(v)),
    sqrt: (v: unknown) => { if (num(v) < 0) throw new Error("sqrt of negative number"); return Math.sqrt(num(v)); }, pow: (a: unknown, b: unknown) => Math.pow(num(a), num(b)),
    min: (...a: unknown[]) => Math.min(...a.map((x) => num(x))), max: (...a: unknown[]) => Math.max(...a.map((x) => num(x))),
    random: () => Math.random(),
    upper: (s: unknown) => String(s).toUpperCase(), lower: (s: unknown) => String(s).toLowerCase(), trim: (s: unknown) => String(s).trim(),
    split: (s: unknown, sep: unknown) => String(s).split(String(sep)), join: (a: unknown, sep: unknown) => arr(a).map((x) => show(x)).join(String(sep ?? "")),
    contains: (h: unknown, n: unknown) => (typeof h === "string" ? h.includes(String(n)) : arr(h).includes(n)),
    replace: (s: unknown, a: unknown, b: unknown) => String(s).split(String(a)).join(String(b)), startsWith: (s: unknown, p: unknown) => String(s).startsWith(String(p)),
    slice: (v: unknown, a: unknown, b?: unknown) => (typeof v === "string" ? v.slice(num(a), b === undefined ? undefined : num(b)) : arr(v).slice(num(a), b === undefined ? undefined : num(b))),
    sort: (a: unknown) => arr(a).slice().sort((x, y) => (typeof x === "number" && typeof y === "number" ? x - y : show(x).localeCompare(show(y)))),
    now: () => Date.now(),
    sleep: (ms: unknown) => new Promise((r) => setTimeout(() => r(null), Math.min(num(ms), 10000))),
    console: { log: (...a: unknown[]) => { host.print(a.map((x) => show(x)).join(" ")); return null; }, error: (...a: unknown[]) => { host.print("error: " + a.map((x) => show(x)).join(" ")); return null; } },
    Math: { PI: Math.PI, E: Math.E },
  };
  return g;
}
export function moduleGlobals(mod: string, host: Host): Record<string, unknown> {
  if (mod === "Neux.Fs") {
    if (!host.fs) throw new Error("Neux.Fs is not available in this host");
    const f = host.fs;
    return { fs: { read: (p: unknown) => f.read(String(p)), write: (p: unknown, d: unknown) => f.write(String(p), String(d)).then(() => null), list: (p: unknown) => f.list(String(p)) } };
  }
  if (mod === "Neux.Net") {
    if (!host.fetchText) throw new Error("Neux.Net is not available in this host");
    const f = host.fetchText;
    return { net: { fetch: (u: unknown) => f(String(u)) } };
  }
  return {};
}
