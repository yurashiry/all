import { parse } from "./compiler/parser";
import { check } from "./compiler/checker";
import { compile, type Bytecode } from "./compiler/compiler";
import { VM, type RunOptions } from "./runtime/vm";
import type { Host } from "./standard-library";
export { NxlError } from "./compiler/lexer";
export type { Bytecode, Host };

/** Full pipeline: lex → parse → type-check → bytecode. */
export function compileNxl(src: string): Bytecode { const ast = parse(src); check(ast); return compile(ast); }
export async function runNxl(src: string, host: Host, opts?: RunOptions) { const vm = new VM(compileNxl(src), host, opts); const result = await vm.run(); return { result, steps: vm.steps }; }
export const serializeBytecode = (b: Bytecode) => new TextEncoder().encode(JSON.stringify(b));
export function loadBytecode(bytes: Uint8Array): Bytecode {
  const b = JSON.parse(new TextDecoder().decode(bytes)) as Bytecode;
  if (b.magic !== "NXB1") throw new Error("Not an NXL bytecode file (bad magic)");
  return b;
}
export async function runBytecode(b: Bytecode, host: Host, opts?: RunOptions) { const vm = new VM(b, host, opts); return { result: await vm.run(), steps: vm.steps }; }
export function disassemble(b: Bytecode): string {
  return b.funcs.map((f, i) => `fn#${i} ${f.name}(${f.params.join(", ")})${i === b.main ? " [main]" : ""}\n` + f.code.map((x, j) => `  ${String(j).padStart(4)}  L${String(x.line).padEnd(3)} ${x.op}${x.a !== undefined ? " " + (x.op === "CONST" ? JSON.stringify(b.consts[x.a as number]) : x.a) : ""}${x.b !== undefined ? " " + x.b : ""}`).join("\n")).join("\n\n");
}
export const NXL_VERSION = "0.1.0";
