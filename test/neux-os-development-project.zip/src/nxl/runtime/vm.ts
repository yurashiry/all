import { NxlError } from "../compiler/lexer";
import type { Bytecode, FnProto } from "../compiler/compiler";
import { stdGlobals, moduleGlobals, show, type Host } from "../standard-library";

class Env {
  vars = new Map<string, { v: unknown; mut: boolean }>();
  constructor(public parent?: Env) {}
  find(n: string): Env | undefined { return this.vars.has(n) ? this : this.parent?.find(n); }
}
interface Closure { proto: number; env: Env; name: string }
interface Frame { fn: FnProto; pc: number; env: Env; base: number; handlers: { addr: number; sp: number; env: Env }[] }
const isClosure = (v: unknown): v is Closure => typeof v === "object" && v !== null && "proto" in v && "env" in v;
class Throw { constructor(public value: unknown) {} }

export interface DebugHooks { breakpoints: Set<number>; step?: boolean; onBreak(line: number, fn: string, locals: Record<string, string>): Promise<"continue" | "step" | "stop"> }
export interface RunOptions { maxSteps?: number; maxDepth?: number; debug?: DebugHooks }

export class VM {
  stack: unknown[] = [];
  frames: Frame[] = [];
  globals = new Env();
  stopped = false;
  steps = 0;
  structs = new Map<string, string[]>();
  constructor(private bc: Bytecode, private host: Host, private opts: RunOptions = {}) {
    for (const [k, v] of Object.entries(stdGlobals(host))) this.globals.vars.set(k, { v, mut: false });
  }
  stop() { this.stopped = true; }

  private rerr(msg: string, line: number): never { throw new NxlError("runtime", msg, line); }
  private truthy(v: unknown) { return v !== null && v !== false && v !== undefined; }
  private traceStr(): string { return this.frames.map((f) => `  at ${f.fn.name} (line ${f.fn.code[Math.max(0, f.pc - 1)]?.line ?? "?"})`).reverse().join("\n"); }

  async run(): Promise<unknown> {
    const main = this.bc.funcs[this.bc.main];
    this.frames = [{ fn: main, pc: 0, env: this.globals, base: 0, handlers: [] }];
    const maxSteps = this.opts.maxSteps ?? 50_000_000, maxDepth = this.opts.maxDepth ?? 1500;
    let stepping = this.opts.debug?.step ?? false, lastLine = -1;
    const S = this.stack;
    const pop = () => S.pop();
    for (;;) {
      if (this.stopped) throw new NxlError("runtime", "Program stopped", 0);
      if (++this.steps > maxSteps) throw new NxlError("runtime", `Instruction budget exceeded (${maxSteps})`, 0);
      if (this.steps % 20000 === 0) await new Promise((r) => setTimeout(r, 0));
      const f = this.frames[this.frames.length - 1];
      const ins = f.fn.code[f.pc++];
      const line = ins.line;
      const dbg = this.opts.debug;
      if (dbg && line !== lastLine && line > 0 && (stepping || dbg.breakpoints.has(line))) {
        lastLine = line;
        const locals: Record<string, string> = {};
        for (let e: Env | undefined = f.env; e && e !== this.globals; e = e.parent) for (const [k, x] of e.vars) if (!(k in locals)) locals[k] = show(x.v, false);
        const a = await dbg.onBreak(line, f.fn.name, locals);
        if (a === "stop") { this.stopped = true; continue; }
        stepping = a === "step";
      } else if (line > 0) lastLine = line;
      try {
        switch (ins.op) {
          case "CONST": S.push(this.bc.consts[ins.a as number]); break;
          case "TRUE": S.push(true); break; case "FALSE": S.push(false); break; case "NULL": S.push(null); break;
          case "POP": pop(); break;
          case "DUP": S.push(S[S.length - 1]); break;
          case "LOAD": { const e = f.env.find(ins.a as string); if (!e) this.rerr(`Undefined name '${ins.a}'`, line); S.push(e!.vars.get(ins.a as string)!.v); break; }
          case "DECL": { f.env.vars.set(ins.a as string, { v: pop(), mut: ins.b === 1 }); break; }
          case "STORE": { const e = f.env.find(ins.a as string); if (!e) this.rerr(`Undefined name '${ins.a}'`, line); const slot = e!.vars.get(ins.a as string)!; if (!slot.mut) this.rerr(`Cannot assign to const '${ins.a}'`, line); slot.v = pop(); break; }
          case "PUSHSCOPE": f.env = new Env(f.env); break;
          case "POPSCOPE": f.env = f.env.parent!; break;
          case "ADD": { const b = pop(), a = pop(); if (typeof a === "string" || typeof b === "string") S.push(show(a) + show(b)); else if (typeof a === "number" && typeof b === "number") S.push(a + b); else this.rerr(`Cannot add ${show(a)} and ${show(b)}`, line); break; }
          case "SUB": case "MUL": case "DIV": case "IDIV": case "MOD": {
            const b = pop(), a = pop();
            if (typeof a !== "number" || typeof b !== "number") this.rerr(`Operator ${ins.op} needs numbers`, line);
            const x = a as number, y = b as number;
            if ((ins.op === "DIV" || ins.op === "IDIV" || ins.op === "MOD") && y === 0) this.rerr("Division by zero", line);
            S.push(ins.op === "SUB" ? x - y : ins.op === "MUL" ? x * y : ins.op === "DIV" ? x / y : ins.op === "IDIV" ? Math.trunc(x / y) : x % y); break;
          }
          case "NEG": { const a = pop(); if (typeof a !== "number") this.rerr("Cannot negate non-number", line); S.push(-(a as number)); break; }
          case "NOT": S.push(!this.truthy(pop())); break;
          case "EQ": { const b = pop(), a = pop(); S.push(JSON.stringify(a) === JSON.stringify(b) && typeof a === typeof b || a === b); break; }
          case "NE": { const b = pop(), a = pop(); S.push(!(JSON.stringify(a) === JSON.stringify(b) && typeof a === typeof b || a === b)); break; }
          case "LT": case "GT": case "LE": case "GE": {
            const b = pop() as number | string, a = pop() as number | string;
            if (typeof a !== typeof b || (typeof a !== "number" && typeof a !== "string")) this.rerr("Cannot compare these values", line);
            S.push(ins.op === "LT" ? a < b : ins.op === "GT" ? a > b : ins.op === "LE" ? a <= b : a >= b); break;
          }
          case "JMP": f.pc = ins.a as number; break;
          case "JF": if (!this.truthy(S[S.length - 1])) f.pc = ins.a as number; break;
          case "JT": if (this.truthy(S[S.length - 1])) f.pc = ins.a as number; break;
          case "CONCAT": { const n = ins.a as number; const parts = S.splice(S.length - n, n); S.push(parts.map((p) => show(p)).join("")); break; }
          case "MKARR": { const n = ins.a as number; S.push(S.splice(S.length - n, n)); break; }
          case "MKOBJ": { const n = ins.a as number; const kv = S.splice(S.length - n * 2, n * 2); const o: Record<string, unknown> = {}; for (let i = 0; i < kv.length; i += 2) o[kv[i] as string] = kv[i + 1]; S.push(o); break; }
          case "RANGE": { const b = pop() as number, a = pop() as number; if (b - a > 10_000_000) this.rerr("Range too large", line); const r: number[] = []; for (let i = a; i < b; i++) r.push(i); S.push(r); break; }
          case "IDX": {
            const i = pop(), o = pop();
            if (Array.isArray(o) || typeof o === "string") { if (typeof i !== "number" || i < 0 || i >= o.length) this.rerr(`Index ${show(i)} out of range (length ${o.length})`, line); S.push(o[i as number]); }
            else if (o && typeof o === "object") S.push((o as Record<string, unknown>)[String(i)] ?? null); else this.rerr("Cannot index this value", line); break;
          }
          case "SETIDX": { const v = pop(), i = pop(), o = pop(); if (Array.isArray(o)) { if (typeof i !== "number" || i < 0 || i >= o.length) this.rerr(`Index ${show(i)} out of range`, line); o[i] = v; } else if (o && typeof o === "object") (o as Record<string, unknown>)[String(i)] = v; else this.rerr("Cannot index-assign", line); S.push(v); break; }
          case "MEM": { const o = pop(); if (o === null || o === undefined) this.rerr(`Cannot read '${ins.a}' of null`, line); if (ins.a === "length" && (Array.isArray(o) || typeof o === "string")) S.push((o as string).length); else if (typeof o === "object") S.push((o as Record<string, unknown>)[ins.a as string] ?? null); else this.rerr(`No member '${ins.a}'`, line); break; }
          case "SETMEM": { const v = pop(), o = pop(); if (!o || typeof o !== "object") this.rerr("Cannot set member of non-object", line); const so = o as Record<string, unknown>; if (so.__struct && !(ins.a as string in so)) this.rerr(`Struct ${so.__struct} has no field '${ins.a}'`, line); so[ins.a as string] = v; S.push(v); break; }
          case "CLOSURE": S.push({ proto: ins.a as number, env: f.env, name: this.bc.funcs[ins.a as number].name } as Closure); break;
          case "STRUCT": { const fields = (ins.b as string).split(",").filter(Boolean); this.structs.set(ins.a as string, fields); const name = ins.a as string; f.env.vars.set(name, { mut: false, v: (...args: unknown[]) => { if (args.length !== fields.length) throw new Error(`${name} expects ${fields.length} field(s)`); const o: Record<string, unknown> = { __struct: name }; fields.forEach((k, i) => (o[k] = args[i])); return o; } }); break; }
          case "IMPORT": for (const [k, v] of Object.entries(moduleGlobals(ins.a as string, this.host))) this.globals.vars.set(k, { v, mut: false }); break;
          case "ITERINIT": { const v = pop(); if (typeof v === "string") S.push({ it: [...v], i: 0 }); else if (Array.isArray(v)) S.push({ it: v, i: 0 }); else this.rerr("Cannot iterate this value", line); break; }
          case "ITERNEXT": { const it = S[S.length - 1] as { it: unknown[]; i: number }; if (it.i >= it.it.length) { pop(); f.pc = ins.a as number; } else S.push(it.it[it.i++]); break; }
          case "TRY": f.handlers.push({ addr: ins.a as number, sp: S.length, env: f.env }); break;
          case "ENDTRY": f.handlers.pop(); break;
          case "THROW": throw new Throw(pop());
          case "AWAIT": { const v = pop(); S.push(v instanceof Promise ? await v : v); break; }
          case "CALL": {
            const n = ins.a as number;
            const args = S.splice(S.length - n, n);
            const callee = pop();
            if (typeof callee === "function") { S.push((callee as (...a: unknown[]) => unknown)(...args) ?? null); break; }
            if (!isClosure(callee)) this.rerr(`'${show(callee)}' is not callable`, line);
            const c = callee as Closure, proto = this.bc.funcs[c.proto];
            if (args.length !== proto.params.length) this.rerr(`${proto.name} expects ${proto.params.length} argument(s), got ${args.length}`, line);
            if (this.frames.length >= maxDepth) this.rerr("Stack overflow (call depth limit)", line);
            const env = new Env(c.env);
            proto.params.forEach((p, i) => env.vars.set(p, { v: args[i], mut: true }));
            this.frames.push({ fn: proto, pc: 0, env, base: S.length, handlers: [] });
            break;
          }
          case "RET": {
            const v = pop();
            const fr = this.frames.pop()!;
            S.length = fr.base;
            if (!this.frames.length) return v;
            S.push(v); break;
          }
          default: this.rerr(`Unknown opcode ${ins.op}`, line);
        }
      } catch (e) {
        // unwind to nearest handler
        let handled = false;
        const value = e instanceof Throw ? e.value : e instanceof NxlError ? e.message.replace(/^\[\w+\] line \d+: /, "") : (e as Error).message;
        if (!(e instanceof NxlError && /Program stopped|budget/.test(e.message))) {
          while (this.frames.length) {
            const fr = this.frames[this.frames.length - 1];
            const h = fr.handlers.pop();
            if (h) { S.length = h.sp; fr.env = h.env; fr.pc = h.addr; S.push(value); handled = true; break; }
            if (this.frames.length === 1) break;
            this.frames.pop();
          }
        }
        if (!handled) {
          if (e instanceof Throw) throw new NxlError("runtime", `Uncaught: ${show(e.value)}\n${this.traceStr()}`, line);
          if (e instanceof NxlError) throw new NxlError("runtime", e.message.replace(/^\[runtime\] line \d+: /, "") + "\n" + this.traceStr(), line);
          throw new NxlError("runtime", (e as Error).message + "\n" + this.traceStr(), line);
        }
      }
    }
  }
}
