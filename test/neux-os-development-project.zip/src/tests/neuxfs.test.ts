import { describe, it, expect } from "vitest";
import { NeuxFS, MemoryBackend, FsError } from "../core/filesystem/neuxfs";
import { archivePaths, unarchive, backupAll, restoreBackup } from "../core/filesystem/archive";

const mk = async () => { const fs = new NeuxFS(new MemoryBackend()); await fs.init(); return fs; };
describe("NeuxFS", () => {
  it("creates the standard tree", async () => {
    const fs = await mk();
    for (const p of ["/System/Core", "/Users/Default/Downloads", "/Users/Default/Pictures/Exports", "/Trash", "/Configuration"]) expect(await fs.exists(p)).toBe(true);
  });
  it("write/read/rename/copy/move", async () => {
    const fs = await mk();
    await fs.writeFile("/Users/Default/Documents/a.txt", "hello");
    expect(await fs.readText("/Users/Default/Documents/a.txt")).toBe("hello");
    await fs.rename("/Users/Default/Documents/a.txt", "b.txt");
    await fs.copy("/Users/Default/Documents/b.txt", "/Users/Default/Desktop/b.txt");
    await fs.move("/Users/Default/Documents/b.txt", "/Users/Default/Music/b.txt");
    expect((await fs.list("/Users/Default/Documents")).length).toBe(0);
    expect(await fs.readText("/Users/Default/Desktop/b.txt")).toBe("hello");
    await expect(fs.copy("/Users/Default", "/Users/Default/Documents/x")).rejects.toThrow(FsError);
  });
  it("trash and restore", async () => {
    const fs = await mk();
    await fs.writeFile("/Users/Default/Documents/a.txt", "x");
    const t = await fs.trash("/Users/Default/Documents/a.txt");
    expect(await fs.exists("/Users/Default/Documents/a.txt")).toBe(false);
    await fs.restore(t);
    expect(await fs.readText("/Users/Default/Documents/a.txt")).toBe("x");
  });
  it("enforces protected paths at the service boundary", async () => {
    const fs = await mk();
    await expect(fs.writeFile("/System/Core/x", "1")).rejects.toThrow(/protected/);
    await expect(fs.remove("/System/Core")).rejects.toThrow(/protected/);
    await fs.writeFile("/System/Core/x", "1", { role: "root" });
    expect(await fs.exists("/System/Core/x")).toBe(true);
  });
  it("search", async () => {
    const fs = await mk();
    await fs.writeFile("/Users/Default/Music/Song One.mp3", "x");
    expect((await fs.search("song")).map((n) => n.name)).toEqual(["Song One.mp3"]);
  });
  it("archive round trip with zip-slip protection", async () => {
    const fs = await mk();
    await fs.writeFile("/Users/Default/Documents/d/a.txt", "A");
    await archivePaths(fs, ["/Users/Default/Documents/d"], "/Users/Default/Documents/d.zip");
    const n = await unarchive(fs, "/Users/Default/Documents/d.zip", "/Users/Default/Desktop/out");
    expect(n).toBe(1);
    expect(await fs.readText("/Users/Default/Desktop/out/d/a.txt")).toBe("A");
  });
  it("backup and restore", async () => {
    const fs = await mk();
    await fs.writeFile("/Users/Default/Documents/keep.txt", "K");
    const bk = await backupAll(fs);
    await fs.wipe(); await fs.init();
    expect(await fs.exists("/Users/Default/Documents/keep.txt")).toBe(false);
    await restoreBackup(fs, bk);
    expect(await fs.readText("/Users/Default/Documents/keep.txt")).toBe("K");
  });
  it("complete wipe erases Neux data only (isolated backend) and leaves host data untouched", async () => {
    const fs = await mk();
    const hostFiles = new Map([["/host/secret.txt", "untouched"]]); // stands in for the host filesystem: never reachable by NeuxFS
    await fs.writeFile("/Users/Default/Documents/a.txt", "x");
    await fs.writeFile("/Users/Default/Downloads/song.mp3", "y");
    await fs.wipe();
    expect(await fs.all()).toHaveLength(0);
    await fs.init();
    expect((await fs.all()).filter((n) => n.type === "file")).toHaveLength(0);
    expect(hostFiles.get("/host/secret.txt")).toBe("untouched");
  });
});
