import { describe, it, expect } from "vitest";
import { BeecoClient, BeecoServer, FrameDecoder, makeEnvelope, encodeFrame, memoryPair, RateLimiter, validateEnvelope } from "../protocols/beeco";

const link = (srv: BeecoServer, id: string, secret: string) => { const [a, b] = memoryPair(); srv.accept(b); return new BeecoClient(a, id, secret); };
describe("BEECO/1", () => {
  it("validates envelopes", () => {
    expect(validateEnvelope(makeEnvelope("ping")).ok).toBe(true);
    expect(validateEnvelope({ beeco: "2" }).ok).toBe(false);
    expect(validateEnvelope({ ...makeEnvelope("ping"), type: "nope" }).ok).toBe(false);
  });
  it("decodes fragmented frames and rejects garbage", () => {
    const d = new FrameDecoder(); const f = encodeFrame(makeEnvelope("ping"));
    expect(d.push(f.slice(0, 10))).toHaveLength(0);
    expect(d.push(f.slice(10) + f)).toHaveLength(2);
    expect(() => new FrameDecoder().push("not json\n")).toThrow();
  });
  it("completes handshake + auth, ping and discovery", async () => {
    const s = new BeecoServer({ name: "test", secrets: { a: "k1", b: "k2" } });
    const a = link(s, "a", "k1"); await a.connect(); expect(a.connected).toBe(true); expect(a.serverName).toBe("test");
    expect(await a.ping()).toBeGreaterThanOrEqual(0);
    const b = link(s, "b", "k2"); await b.connect();
    expect(((await a.discover()).nodes as string[])).toContain("b");
  });
  it("rejects wrong secret", async () => {
    const s = new BeecoServer({ name: "t", secrets: { a: "right" } });
    await expect(link(s, "a", "wrong").connect()).rejects.toThrow(/Authentication failed/);
  });
  it("relays messages between authenticated peers", async () => {
    const s = new BeecoServer({ name: "t", secrets: { a: "1", b: "2" } });
    const a = link(s, "a", "1"), b = link(s, "b", "2"); await a.connect(); await b.connect();
    const got = new Promise<string>((r) => (b.onMessage = (e) => r(String(e.payload.text))));
    a.send("b", { text: "hello" }); expect(await got).toBe("hello");
  });
  it("rate limiter throttles", () => {
    let t = 0; const r = new RateLimiter(2, 1, () => t);
    expect([r.take(), r.take(), r.take()]).toEqual([true, true, false]); t = 2000; expect(r.take()).toBe(true);
  });
});
