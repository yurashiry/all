import { describe, it, expect } from "vitest";
import { parseLRC, activeLine } from "../apps/media/lyrics";
import { readTags } from "../apps/media/tags";

describe("lyrics", () => {
  const l = parseLRC("[ti:x]\n[00:01.00]one\n[00:05.50]two\n[01:00.00]three")!;
  it("parses synced LRC", () => { expect(l.synced).toBe(true); expect(l.lines.map((x) => x.t)).toEqual([1, 5.5, 60]); });
  it("finds active line (seek-safe)", () => { expect([activeLine(l, 0), activeLine(l, 1), activeLine(l, 5.4), activeLine(l, 5.5), activeLine(l, 999)]).toEqual([-1, 0, 0, 1, 2]); });
  it("never invents timestamps for plain lyrics", () => { const p = parseLRC("hello\nworld")!; expect(p.synced).toBe(false); expect(p.lines.every((x) => x.t === null)).toBe(true); });
  it("offset tag", () => { expect(parseLRC("[offset:500]\n[00:02.00]a")!.lines[0].t).toBeCloseTo(1.5); });
});
describe("tags", () => {
  it("reads WAV format info", () => {
    const b = new Uint8Array(44); const dv = new DataView(b.buffer);
    b.set([82, 73, 70, 70], 0); b.set([87, 65, 86, 69], 8); b.set([102, 109, 116, 32], 12); dv.setUint32(16, 16, true);
    dv.setUint16(22, 2, true); dv.setUint32(24, 96000, true); dv.setUint16(34, 24, true);
    const t = readTags(b, "a.wav").tech; expect([t.sampleRate, t.bitDepth, t.channels, t.lossless]).toEqual([96000, 24, 2, true]);
  });
});
