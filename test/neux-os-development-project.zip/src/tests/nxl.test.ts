import { describe, it, expect } from "vitest";
import { runNxl, compileNxl, serializeBytecode, loadBytecode, runBytecode, NxlError } from "../nxl";

const run = async (src: string) => { const out: string[] = []; await runNxl(src, { print: (s) => out.push(s) }); return out; };

describe("NXL", () => {
  it("runs arithmetic, functions and recursion", async () => {
    expect(await run(`fn fib(n: int) -> int {\n if n < 2 { return n }\n return fib(n - 1) + fib(n - 2)\n}\nprint(fib(15))`)).toEqual(["610"]);
  });
  it("integer vs float division", async () => { expect(await run(`print(7 / 2)\nprint(7.0 / 2)`)).toEqual(["3", "3.5"]); });
  it("closures, arrays, for loops, interpolation", async () => {
    const o = await run(`fn counter() {\n let c = 0\n return fn() { c += 1\n return c }\n}\nlet n = counter()\nn()\nlet t = 0\nfor x in [1,2,3] { t += x }\nprint("{n()} {t}")`);
    expect(o).toEqual(["2 6"]);
  });
  it("break/continue and structs", async () => {
    expect(await run(`struct P { x: int, y: int }\nlet p = P(1, 2)\np.x = 5\nlet s = 0\nfor i in 0..10 { if i == 3 { continue }\n if i == 6 { break }\n s += i }\nprint(p.x, s)`)).toEqual(["5 12"]);
  });
  it("try/catch handles runtime errors and throw", async () => {
    expect(await run(`try { let a = [1]\n print(a[5]) } catch e { print("caught: {e}") }\ntry { throw "boom" } catch e { print(e) }`)).toEqual(["caught: Index 5 out of range (length 1)", "boom"]);
  });
  it("type checker rejects bad programs", () => {
    expect(() => compileNxl(`let x: int = "a"`)).toThrow(NxlError);
    expect(() => compileNxl(`const c = 1\nc = 2`)).toThrow(/const/);
    expect(() => compileNxl(`print(y)`)).toThrow(/Undefined/);
    expect(() => compileNxl(`fn f(a: int) -> int { return a }\nf("x")`)).toThrow(/expected int/);
    expect(() => compileNxl(`import Neux.UI`)).toThrow(/not available/);
  });
  it("bytecode round-trips (.nxb)", async () => {
    const bc = loadBytecode(serializeBytecode(compileNxl(`print(1 + 2)`)));
    const out: string[] = []; await runBytecode(bc, { print: (s) => out.push(s) }); expect(out).toEqual(["3"]);
  });
  it("enforces instruction budget", async () => {
    await expect(runNxl(`while true { }`, { print() {} }, { maxSteps: 10000 })).rejects.toThrow(/budget/);
  });
  it("fs module only after import", async () => {
    expect(() => compileNxl(`fs.read("/x")`)).toThrow(/Undefined/);
  });
});
