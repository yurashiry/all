import { describe, it, expect } from "vitest";
import { applyParams, defaultParams, encodeTiff, histogram, type Img } from "../apps/photo/engine";
const mk = (r: number, g: number, b: number, n = 4): Img => ({ width: n, height: 1, data: new Uint8ClampedArray(Array.from({ length: n }, () => [r, g, b, 255]).flat()) });
describe("Neux Photo engine", () => {
  it("default params are the identity", () => { const i = mk(120, 60, 200); applyParams(i, defaultParams()); expect(Array.from(i.data.slice(0, 3))).toEqual([120, 60, 200]); });
  it("exposure +1 stop doubles linear values", () => { const i = mk(50, 50, 50); applyParams(i, { ...defaultParams(), exposure: 1 }); expect(i.data[0]).toBe(100); });
  it("black & white filter equalizes channels", () => { const i = mk(255, 0, 0); applyParams(i, { ...defaultParams(), filter: "bw" }); expect(i.data[0]).toBe(i.data[1]); expect(i.data[1]).toBe(i.data[2]); });
  it("saturation -1 removes colour", () => { const i = mk(200, 40, 40); applyParams(i, { ...defaultParams(), saturation: -1 }); expect(Math.abs(i.data[0] - i.data[1])).toBeLessThan(3); });
  it("histogram counts pixels", () => { const h = histogram(mk(10, 20, 30, 5)); expect(h.r[10]).toBe(5); expect(h.g[20]).toBe(5); });
  it("TIFF header is valid", () => { const t = encodeTiff(mk(1, 2, 3, 2)); expect([t[0], t[1], t[2]]).toEqual([0x49, 0x49, 42]); expect(t.length).toBeGreaterThan(8 + 8); });
});
