import { describe, it, expect } from "vitest";
import { normalizeCombo, SHORTCUTS, conflictsFor } from "../core/shortcuts";

describe("shortcuts", () => {
  it("normalizes combos", () => { expect(normalizeCombo("shift+ctrl+N")).toBe("Ctrl+Shift+n"); expect(normalizeCombo("Cmd+Left")).toBe("Meta+Left"); });
  it("contains every required global shortcut", () => {
    const need = ["Ctrl+F", "Ctrl+Space", "Ctrl+E", "Ctrl+,", "Ctrl+Alt+T", "Ctrl+Shift+Escape", "Ctrl+Shift+N", "Ctrl+Alt+ArrowLeft", "Ctrl+Alt+ArrowRight", "Ctrl+Shift+Q"].map(normalizeCombo);
    const have = SHORTCUTS.filter((s) => s.scope === "system").map((s) => normalizeCombo(s.keys));
    for (const n of need) expect(have).toContain(n);
  });
  it("detects conflicts", () => {
    expect(conflictsFor("sys.explorer", "Ctrl+F", {}).map((s) => s.id)).toContain("sys.fullscreen");
    expect(conflictsFor("sys.explorer", "Ctrl+Q", {})).toHaveLength(0);
  });
});
