/* Neux OS service worker — offline support for the Web edition. Caches only Neux's own files (cache names start with "neux-"). */
const CACHE = "neux-shell-v1";
self.addEventListener("install", (e) => { self.skipWaiting(); });
self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith("neux-") && k !== CACHE) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return;
  if (req.url.includes("version.json")) return; // always network for update checks
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const res = await fetch(req);
      if (res.ok) cache.put(req, res.clone());
      return res;
    } catch {
      const hit = await cache.match(req, { ignoreSearch: true });
      if (hit) return hit;
      if (req.mode === "navigate") { const idx = await cache.match(self.registration.scope) || await cache.match(self.registration.scope + "index.html"); if (idx) return idx; }
      return new Response("Offline and not cached", { status: 503 });
    }
  })());
});
