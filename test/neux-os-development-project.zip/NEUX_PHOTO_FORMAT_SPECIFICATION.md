# `.wrphoto` format

**Status:** version wrphoto/1

JSON document: `{format:"wrphoto/1", name, savedAt, size:[w,h], params:{…adjustment parameters…}, base:"data:image/png;base64,…" (committed pixels), originalMime, original:"<base64 of the untouched source file>"}`. The original is preserved inside the project until you export or overwrite. Pictures folder: `Pictures/Neux Photo Projects/` (projects, `presets.json`, `.autosave.wrphoto`); exports default to `Pictures/Exports/`. Unknown future versions are rejected.
