# Keyboard shortcuts

**Status:** implemented

Central registry in `src/core/shortcuts.ts` (all shortcuts of the brief for Global, Window, General, Browser, Photo, Developer), dispatcher in the Shell, per-window `useShortcut`. Scopes: system, app (focused app wins), editor, input (never intercepted: Ctrl+C/X/V/A/Z/Y stay native). Remapping, search, categories, conflict warning, restore defaults and platform notes live in Settings → Keyboard Shortcuts. Ctrl is used on both Windows and macOS. Browsers/hosts reserve Alt+Tab, Alt+F4, Win+arrows, Ctrl+W/N/T/Tab etc.: Neux binds them best-effort and offers alternatives (Alt+Q, Alt+Shift+W, Alt+Shift+arrows, Alt+T…). Win+arrow shortcuts require a native shell to be reliable.
