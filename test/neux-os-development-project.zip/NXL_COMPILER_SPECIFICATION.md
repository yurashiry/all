# NXL compiler

**Status:** bytecode back end only

Pipeline (`src/nxl`): lexer → recursive-descent parser (AST) → type checker → bytecode compiler → stack VM. Bytecode: `{magic:"NXB1", consts, funcs:[{name,params,code:[{op,a,b,line}]}], main, modules}`; ops include CONST LOAD DECL STORE ADD…IDIV JMP/JF/JT CALL RET CLOSURE MKARR MKOBJ IDX MEM ITERINIT/ITERNEXT TRY/ENDTRY THROW AWAIT STRUCT IMPORT. `disassemble()` prints it.
Runtime: environments with lexical scope chains, call-depth limit (1500), instruction budget (50 M), cooperative yielding every 20 000 steps, `stop()`, line-level debugger hooks (breakpoints, step, locals) used by the Runtime app.
Execution does not use JavaScript `eval`/`Function`; the VM is TypeScript code (so NXL *execution* still depends on the JS host in the Web edition — a native VM is future work).
**Not implemented:** native machine-code back end, LLVM, WASM target, optimizer, intermediate representation separate from bytecode, `.nxlpkg` packaging. Tests: `src/tests/nxl.test.ts` (9 passing).
