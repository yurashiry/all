# UI — Neux Liquid Glass 26

**Status:** implemented (visual quality not reviewed on real devices)

Tokens (dark/light, high contrast, blur off), glass surfaces and animation are sections of `src/app/globals.css` (themes, glass, animations — inlined because Tailwind v4 logged resolver errors for split `@import`s) with `prefers-reduced-motion` and a manual Reduce-motion setting. Moderate radii (8/12/16 px), SVG glyph icons (`src/shell/icons.tsx`), 8 gradient wallpapers (+ Ukraine collection) or a picture from NeuxFS.
Window controls use the exact symbols ⌄ minimize, ⌃ maximize/restore, × close. Windows: drag, 8-direction resize, edge snap, fullscreen (context menu), focus, virtual desktops, mobile (<760 px) full-screen layout with bottom Hotbar. Accessibility: labelled controls, focus rings, dialog roles, Escape closes menus, text scale, high contrast.
Not done: screen-reader audit, touch gesture set beyond native touch, tablet-specific layouts.
