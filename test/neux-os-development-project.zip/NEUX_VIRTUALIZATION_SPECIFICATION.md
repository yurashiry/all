# Virtualization permission

**Status:** permission and enforcement implemented; no hypervisor exists

`Settings → VPN → Allow adding VM` (default OFF). ON permits `vm register`; OFF blocks registering and starting VMs (`startVm`/console) while preserving VM data. `vmSupport()` reports truthfully: Web has no hardware virtualization access; native shells have no adapter yet. Planned adapters: Android (none — AVF is not generally available to apps), Windows (Hyper-V/WHP), macOS (Virtualization.framework/Hypervisor.framework). Virtual disks/memory/CPU/network/shared-folder permissions are specified but not implemented. Virtualization is not part of the VPN subsystem; only the setting's location is under VPN as requested.
