# Neux API

**Status:** partially implemented

**Host API** (`window.Neux`, installed at boot, used by Console and URIs): `Neux.console.open() / type(text) / execute(cmd)`, `Neux.notifications.show({title,message})`, `Neux.files.open(path) / read(path) / list(path)`, `Neux.settings.get(key)`, `Neux.apps.open(id)`.
URI: `open console(neuxos):command=help`, `open console(neuxos):command=null`, `open console(neuxos):runcommand=system info` (type into Start search and press Enter).

**Package API** (sandboxed `.wrapp` HTML apps, via postMessage bridge, permission-checked at the host): `Neux.notifications.show` (perm `notifications`), `Neux.settings.get('theme'|'accent'|'language')`, `Neux.storage.get/set/remove/list` (perm `storage`, private to `/Applications/<id>/data`, 1 MB per value), `Neux.window.setTitle`, `Neux.files.pickText()` (perm `files.read`, opens the user-controlled picker). Permissions: notifications, storage, clipboard, network, files.read, files.write, media, camera, microphone; camera/microphone/clipboard are never auto-granted and are denied while File Isolation is ON.
Not implemented as package APIs: windows, users, networking/BEECO, media, keyboard, themes, localization, developer tools, downloads, security, virtualization (core services exist but are not exposed to packages).
