# Networking

**Status:** partial

Connectivity: `navigator.onLine` + Network Information API. BEECO state is only `connected` after a real authenticated handshake (or the explicitly labelled in-page loopback). VPN state is `off` on Web. Downloads: streaming `fetch` with byte counters, Range-based pause/resume (falls back to restart if the server ignores Range), cancel/retry, history in `/Configuration/downloads.json`; files land in `/Users/Default/Downloads`. Browser CORS applies: cross-origin servers without CORS headers fail with a clear error and a host-browser fallback.
Wi-Fi scanning, raw sockets, `localhost` servers: impossible on Web (documented in UI).
