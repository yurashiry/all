# Testing

**Status:** 37 unit tests executed and passing; no E2E/browser tests were run

Runner: Vitest (`npx vitest run`). Files: `neuxfs.test.ts` (tree, CRUD, trash/restore, protected paths, search, zip round trip + zip-slip, backup/restore, **complete wipe on an isolated backend leaving a stand-in host file untouched**), `nxl.test.ts` (language, type errors, bytecode round trip, budget), `beeco.test.ts` (envelope, framing, handshake, auth failure, relay, rate limit), `media.test.ts` (LRC parsing/sync, WAV header), `photo.test.ts` (engine identity/exposure/filters/histogram/TIFF), `shortcuts.test.ts` (normalization, required shortcuts, conflicts).
Not covered by automated tests (honest list): boot sequence UI, setup wizard, window manager interactions, file picker UI, file associations flow, downloads, store install UI, media playback, lyrics scrolling, Photo UI, Secure Center UI, console UI, responsive layout, accessibility audit, native adapters. These were implemented but **not exercised in a browser** by the author; a Playwright suite is the recommended next step.
