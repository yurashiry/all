# WR Security Centre (Secure Center)

**Status:** implemented; not an antivirus

Prominent **File Isolation Protection** toggle. ON means: `security.checkOpen` blocks `.wr/.wrapp/.html/.js/.nxl/.nxb/.nxe` from running unless the exact SHA-256 is a trusted exception; unverified packages cannot launch; app iframes lose clipboard/camera/microphone. Always: host executables (`exe msi bat cmd com scr ps1 apk dmg pkg sh app jar vbs lnk`) are never launched; quarantined files are blocked. Tools: file inspection (type vs magic bytes, disguised executables, zip contents/manifest/permissions, SHA-256), quarantine (moves to `/System/Quarantine` with metadata) and restore/delete, trusted exceptions, history, dashboard listing which protections exist and which do not (process isolation, per-app network limits, signatures, malware detection are shown as unavailable). Passing inspection never means "safe".
