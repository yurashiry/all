# NXL language

**Status:** working interpreter-grade implementation (v0.1) — not a production language

Files: `.nxl` source, `.wr` (Neux Runtime scripts are NXL), `.nxb` bytecode (JSON container, magic `NXB1`). `.nxlmod/.nxlpkg/.nxlib` are reserved, not implemented.
Syntax: `let`/`const` with optional types (`int float str bool [T]`), `fn name(a: int) -> int { }`, closures `fn(x) { }`, `if/else`, `while`, `for x in range(n)` / `for x in 0..10` / arrays / strings, `break/continue`, `struct P { x: int, y: int }` + `P(1,2)`, arrays/objects, string interpolation `"{expr}"`, `try { } catch e { }`, `throw`, `async fn` + `await` (cooperative: `await` resolves promises from native functions such as `sleep` and `net.fetch`; there is no parallelism), `import Neux.Std|Neux.Fs|Neux.Net` (module gates: `fs` and `net` exist only after import).
Type checker: static inference for literals/operators/calls, const-assignment, undefined names, return types, argument counts and types for user functions, struct field arity. Dynamic `any` for untyped values.
Standard library: print, len, str, int, float, push, pop, keys, range, typeof, math helpers, string helpers, sort, now, sleep, console.log, `fs.read/write/list` (NeuxFS only), `net.fetch(url)` (CORS rules apply).
**Not implemented:** the `application { window { … } }` GUI toolkit and `import Neux.UI` (rejected with an error), FFI, native bindings/ABI, threads, package manager, module files, LLVM/WASM/native back ends.
Example: see Developer → New project → "NXL program".
