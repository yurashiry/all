# Neux Photo platform notes

**Status:** Web only

Canvas 2D + `createImageBitmap` + typed-array pixel code (preview ≤1500 px, full-resolution export). Export formats depend on `canvas.toBlob` encoders (AVIF often unavailable; Neux reports it). Memory: history stores full canvases (limit 25). Native editions would reuse this engine; GPU acceleration and ICC colour management are not implemented (sRGB assumed, EXIF stripped on export).
