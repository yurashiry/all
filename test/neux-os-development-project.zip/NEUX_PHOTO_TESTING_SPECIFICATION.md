# Neux Photo testing

**Status:** engine unit tests only

Executed: `src/tests/photo.test.ts` (identity, exposure, B&W, saturation, histogram, TIFF header). Not executed: pointer-tool behaviour, history/undo, autosave recovery, export in each browser, large-image performance. Planned: Playwright flows with golden-image comparison.
